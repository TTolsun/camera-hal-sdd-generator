from pathlib import Path
import json


root = Path(__file__).resolve().parent
records = Path('docs/libcamera/records/issue297')
selected = ['Q1-reader-complete','Q2-reader','Q3-reader-complete']
summary = json.loads((root/'summary.json').read_bytes())
verdicts = {row['call']:row for row in summary['verdicts']}
table = []
for name in selected:
    reader = root/'calls'/name
    judge = root/'calls'/f'{name}-judge'
    data = json.loads((reader/'delivery-proof.json').read_bytes())
    reader_receipt = json.loads((reader/'receipt.json').read_bytes())
    judge_receipt = json.loads((judge/'receipt.json').read_bytes())
    verdict = verdicts[f'{name}-judge']
    question = data['reader'].split('-')[0]
    count = verdict['ratings'].count('충족')
    result = ('통과' if verdict['pass'] else '미통과')+f' {count}/6'
    table.append(f"| {question} | {data['pages']} | {len(data['opened_code'])} | {result} | {reader_receipt['wall_seconds']:.3f}초 | {judge_receipt['wall_seconds']:.3f}초 |")
passed = sum(verdicts[f'{name}-judge']['pass'] for name in selected)
budget = ('사전 점검선 250만 토큰을 넘었습니다.' if summary['measured_total_tokens'] > 2500000
          else '사전 점검선 250만 토큰 안에서 종료했습니다.')
lines = '\n'.join(table)
notes = '\n\n'.join('### '+name.split('-')[0]+'\n\n'+'\n'.join('- '+row for row in verdicts[f'{name}-judge']['findings']) for name in selected)
content = f'''# #297 질문별 독립 읽기 재검증

실제 Pages build `48c4f23e4b9c3246b3d365d07ddbf032944450cf5a133e3dcec1824b248055d3`에서 한글 HTML 31개와 시각화 감사 파일의 해시를 다시 확인했습니다. manifest와 소스 `da6a6ed33ed0ab305f10b6f8b44736150d39cef4`가 이전 평가와 일치해 Q1~Q3의 문서 근거 판정 6/6을 재사용했습니다. [이전 평가](pages-followup.md) · [실제 manifest](https://ttolsun.github.io/libcamera-sdd/site-manifest.json)

이전에는 세 질문의 문서와 코드를 한 번의 도구 응답에 담아 보냈습니다. CLI 로그에 기록된 응답과 모델이 받았다고 확인한 내용에 차이가 있었습니다. 이번에는 질문마다 독립 Codex CLI를 실행하고 도구 응답을 최대 약 8.5KB로 나눴습니다. 모델 답변에서 각 응답 끝의 확인값이 모두 일치하는지 검사했습니다. 각 도구 응답의 소스 행과 GitHub 원문 파일 해시는 공식 저장소의 고정 커밋과 대조했습니다.

| 질문 | 끝값 확인 | 코드 창 | 독립 읽기 | 독해 | 별도 판정 |
| --- | ---: | ---: | --- | ---: | ---: |
{lines}

질문별로 별도 `gpt-6.1-terra` / `high` 프로세스에서 읽고, 독해에 참여하지 않은 별도 프로세스에서 원래 여섯 기준으로 판정했습니다. Q1과 Q3의 재시도에는 최초 판정에서 확인한 질문 범위와 실제 코드 창을 보강했습니다. 각 독해에는 해당 질문, 확인할 범위, 실제 문서와 링크된 코드만 제공했습니다. 독해의 정답 기준과 검토용 넓은 소스 창은 별도 판정에 사용했습니다.

독립 읽기 완전 통과는 **{passed}/3**입니다. 초기 미통과와 재시도를 포함한 CLI {summary['calls']}회의 측정 입력·출력은 {summary['measured_total_tokens']:,}토큰입니다. {budget} 위 표는 질문별 최종 독해와 판정의 개별 경과 시간입니다. 실기기, 실제 사람의 독해 효과와 사내 HAL은 평가하지 않았습니다. 문서·배포 입력은 동일하므로 추가 Pages 배포는 필요하지 않았습니다. [질문·실행 기록과 원본 판정](split-reader-evidence.zip)

## 최종 판정 근거

{notes}
'''
(records/'split-reader.md').write_text(content,encoding='utf-8',newline='\n')
print(f'{passed}/3', *table, sep='\n')
