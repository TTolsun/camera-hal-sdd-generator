from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time

root = Path(__file__).parent.resolve()
name = sys.argv[1]
folder = root / 'calls' / name
folder.mkdir(parents=True)
prompt = root / 'prompts' / (name + '.txt')
isolated = root / 'cli'
isolated.mkdir(exist_ok=True)
argv = [shutil.which('codex'), 'exec', '--ignore-user-config', '--ignore-rules',
        '--ephemeral', '--skip-git-repo-check', '--sandbox', 'read-only', '-C', str(isolated),
        '--disable', 'shell_tool', '--disable', 'multi_agent', '--disable', 'plugins',
        '--disable', 'apps', '--disable', 'shell_snapshot', '--disable', 'skill_search',
        '-c', 'project_doc_max_bytes=0', '-c', 'approval_policy="never"', '-c', 'web_search="disabled"',
        '--json', '--model', 'gpt-6.1-terra', '-c', 'model_reasoning_effort="high"']
using_reader = len(sys.argv) >= 3
if using_reader:
    argv.extend(['-c', 'mcp_servers.public_sdd.command=' + json.dumps(sys.executable),
                 '-c', 'mcp_servers.public_sdd.args=' + json.dumps([
                     str(root / 'reader.py'), str(Path(sys.argv[2]).resolve()),
                     str(folder / 'navigation.jsonl'), name.split('-')[0]]),
                 '-c', 'mcp_servers.public_sdd.required=true',
                 '-c', 'mcp_servers.public_sdd.default_tools_approval_mode="approve"',
                 '-c', 'mcp_servers.public_sdd.startup_timeout_sec=75',
                 '-c', 'mcp_servers.public_sdd.tool_timeout_sec=85',
                 '-c', 'mcp_servers.public_sdd.enabled_tools=["question_route"]',
                 '-c', 'mcp_servers.public_sdd.tools.question_route.output_token_limit=65536'])
argv.append('-')
started = time.monotonic()
record = {'call': name, 'started_utc': datetime.now(timezone.utc).isoformat(),
          'prompt_sha256': hashlib.sha256(prompt.read_bytes()).hexdigest(),
          'argv': argv, 'timeout_seconds': 360}
with prompt.open('rb') as stdin, (folder / 'stdout.jsonl').open('wb') as out, (folder / 'stderr.log').open('wb') as err:
    try:
        proc = subprocess.run(argv, cwd=isolated, stdin=stdin, stdout=out, stderr=err,
                              timeout=record['timeout_seconds'])
        record['exit_code'] = proc.returncode
    except (OSError, subprocess.TimeoutExpired) as exc:
        record['failure'] = str(exc)
record['wall_seconds'] = round(time.monotonic() - started, 3)
record['finished_utc'] = datetime.now(timezone.utc).isoformat()
events = [json.loads(line) for line in (folder / 'stdout.jsonl').read_text(encoding='utf-8-sig').splitlines() if line.strip()]
turns = [event for event in events if event.get('type') == 'turn.completed']
items = [event.get('item', {}) for event in events if event.get('type') == 'item.completed']
answers = [item['text'] for item in items if item.get('type') == 'agent_message']
record['usage'] = turns[0].get('usage') if len(turns) == 1 else None
record['tools'] = [item.get('type') for item in items if item.get('type') not in {'agent_message','reasoning'}]
record['completed'] = record.get('exit_code') == 0 and len(turns) == 1 and bool(answers)
if answers:
    (folder / 'answer.md').write_text(answers[-1] + '\n', encoding='utf-8')
navigation = folder / 'navigation.jsonl'
if using_reader and navigation.exists():
    trace = [json.loads(line) for line in navigation.read_text(encoding='utf-8').splitlines()]
    record['navigation'] = {event: sum(item['event'] == event for item in trace)
                            for event in ('search','read','follow','error')}
(record_path := folder / 'receipt.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
print(json.dumps({key: value for key, value in record.items() if key != 'argv'}))
raise SystemExit(0 if record['completed'] else 1)
