from pathlib import Path
from zipfile import ZipFile


root = Path(__file__).resolve().parent
out = root/'prompts'
out.mkdir(exist_ok=True)
scope = {
    'Q1': '제출 접수에서 버퍼별·요청별 완료와 반환까지, 각 상태와 실패·취소에서 읽을 수 있는 데이터, 앱과 핸들러의 책임 및 직접·지연 수신자의 객체 수명, 기본 재사용과 옵션·펜스의 분기를 설명하세요.',
    'Q2': '같은 제출 건을 앱의 API 진입에서 파이프라인 수신까지 어떻게 추적하는지부터 시작하세요. 준비·장치 전달·장치 반환·공통 완료·앱 수신을 조사 순서대로 다루고, 각 경계의 관측값과 정상·실패·취소 시 다음 확인 위치를 제시하세요.',
    'Q3': '공개 API 계약, 상태와 접근 조건, 공통 핸들러 정지와 UVC 실패 분기, 완료·앱 반환·개별 콜백 순서 및 객체 수명에 미치는 영향을 다루세요. 바꾼 뒤 확인할 항목은 조건, 관측값, 판정 방법까지 적으세요.',
}
with ZipFile('docs/libcamera/records/issue297/evidence.zip') as archive:
    for question, focus in scope.items():
        old = archive.read(f'prompts/{question}-baseline-bundle-reader.txt').decode('utf-8-sig')
        line, = [item for item in old.splitlines() if item.startswith(f'질문 {question}. ')]
        prompt = f'''당신은 공개 libcamera SDD를 처음 읽는 개발자입니다. 다음 한 질문에 답하세요.

공개 Pages https://ttolsun.github.io/libcamera-sdd/
{line}

public_sdd.question_route 도구에서 page=1을 연 뒤, 응답에 나온 pages까지 모든 페이지를 번호순으로 각각 여세요. 도구가 제공하는 자료는 실제 Pages 문서와 그 문서에서 연 고정 소스입니다. 각 응답 맨 끝의 tail 값을 읽어 답변의 마지막 줄에 `TAILS: 1=..., 2=..., ...` 형식으로 남기세요. 값을 읽지 못했다면 해당 페이지를 다시 열어 보세요. 작성 맥락이나 외부 지식은 사용하지 마세요.

{focus}

중요한 각 판단과 예외에는 실제로 읽은 문서 앵커와 코드 파일·행을 연결하세요. 그림에서 판단에 사용한 분기를 적으세요. 문서의 계약과 구현, 검증 계획과 실제 장치 관측을 구분하고, 소스에서 확인하지 못한 범위를 밝히세요. 누락 없이 설명할 만큼 충분히 길게 한국어로 답하세요.
'''
        (out/f'{question}-reader.txt').write_text(prompt,encoding='utf-8')
