from hashlib import sha256
import json
from pathlib import Path
import re
import subprocess
import sys
from zipfile import ZipFile


root = Path(__file__).resolve().parent
source = root.parent/'issue303/source'
commit = 'da6a6ed33ed0ab305f10b6f8b44736150d39cef4'
old_commit = 'c19d05128f3ae1f0ebe63acb4deaca9fbb1dde78'
question = sys.argv[1]
name = sys.argv[2] if len(sys.argv) > 2 else f'{question}-reader'
run = root/'calls'/name
answer = (run/'answer.md').read_text(encoding='utf-8')
receipt = json.loads((run/'receipt.json').read_bytes())
assert receipt['completed']
trace = [json.loads(line) for line in (run/'navigation.jsonl').read_bytes().splitlines()]
assert not any(event['event'] == 'error' for event in trace)

pages = {}
for line in (run/'stdout.jsonl').read_bytes().splitlines():
    event = json.loads(line)
    item = event.get('item', {})
    if event['type'] != 'item.completed' or item.get('tool') != 'question_route':
        continue
    raw, = item['result']['content']
    data = json.loads(raw['text'])
    assert len(raw['text'].encode()) <= 8500
    assert any(row['event'] == 'delivered' and row['page'] == data['page'] and row['tail'] == data['tail']
               for row in trace)
    pages[data['page']] = data
count = next(iter(pages.values()))['pages']
assert set(pages) == set(range(1,count+1)), sorted(pages)
tails = dict(re.findall(r'(\d+)\s*=\s*([0-9a-f]{7})', answer.rsplit('TAILS:',1)[-1]))
expected = {str(num): data['tail'] for num,data in pages.items()}
assert expected == tails, (expected,tails)
files = {}


def official(path):
    if path not in files:
        raw = subprocess.check_output(['git','-C',str(source),'show',f'{commit}:{path}'])
        files[path] = sha256(raw).hexdigest(), raw.decode('utf-8').splitlines()
    return files[path]


opened, docs = [], {}
for number in sorted(pages):
    for row in pages[number]['content']:
        if 'url' in row:
            chunks = docs.setdefault(row['url'], {})
            assert row['chunk'] not in chunks or chunks[row['chunk']] == row['text']
            chunks[row['chunk']] = row['text']
            continue
        path, first, last = row['path'], row['start'], row['end']
        digest, lines = official(path)
        assert digest == row['raw_sha256']
        assert row['code'] == '\n'.join(f'{n}: {lines[n-1]}' for n in range(first,last+1))
        assert any(event['event'] == 'follow' and event['github_http'] == 200
                   and all(event[key] == row[key] for key in ('path','start','end','href','raw_sha256'))
                   for event in trace)
        opened.append({key:row[key] for key in ('href','path','start','end','raw_sha256')})
docs = {url: ''.join(chunks[k] for k in sorted(chunks)) for url,chunks in docs.items()}

with ZipFile('docs/libcamera/records/issue297/evidence.zip') as bundle:
    key = bundle.read(('Q1' if question == 'Q1' else 'Q2-Q3')+'-source-key.md').decode('utf-8-sig')
    if question != 'Q1':
        key = key.partition('\n## Q3')[0] if question == 'Q2' else '## Q3'+key.partition('## Q3')[2]
    spans = json.loads(bundle.read(f'{question}-review-windows.json'))
    if question != 'Q1':
        for path,ranges in json.loads(bundle.read(f'{question}-supplement-windows.json')).items():
            spans.setdefault(path,[]).extend(ranges)
windows = {}
for path,ranges in spans.items():
    digest, lines = official(path)
    original = subprocess.check_output(['git','-C',str(source),'show',f'{old_commit}:{path}'])
    assert digest == sha256(original).hexdigest(), path
    for first,last in sorted(set(map(tuple,ranges))):
        last = min(last, len(lines))
        windows[f'{path}:{first}-{last}'] = '\n'.join(f'{n}: {lines[n-1]}' for n in range(first,last+1))

report = {'reader':name,'pages':count,'tails':expected,'documents':len(docs),'opened_code':opened,
          'source_commit':commit,'build_id':json.loads((root/'verified-pages.json').read_bytes())['build_id']}
(run/'delivery-proof.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
prompt = f'''당신은 작성·독해에 참여하지 않은 별도 소스 근거 검토자입니다. 아래 {question}의 독립 독해 답변만 원래 여섯 기준으로 판정하세요. 기존 실제 문서 판정은 같은 manifest로 확인하여 재사용했으므로 여기서 바꾸지 않습니다.

판정 순서 ① 직접 답변과 조건 ② 정상·실패·취소·예외 ③ 책임·소유권·수명·순서·동시성 ④ 실제 코드와 다음 행동·검증 ⑤ API 계약·구현·해석·미확인 구별 ⑥ 근거 접근과 충분성·그림 일치입니다. 충족, 부분 충족, 미충족, 해당 없음 중 하나를 각 기준에 사용하세요. 필수 오답, 중요한 조건·분기 누락, 필수 근거 접근 실패가 있으면 전체 미통과입니다. 같은 의미의 표현과 실제 확인한 소스 파일·행 범위는 인정하세요. 도구 응답의 끝값 전부를 모델이 답변에서 정확히 제시했으며, 실제 코드 창의 내용과 파일 해시를 공식 소스와 비교했습니다. 답변에 없는 내용을 코드·문서에서 대신 채우지 마세요. 열람은 아래 독해 제공 창에서만 인정하며, 별도 판정용 소스 창은 그 판단을 검증하는 자료입니다.

JSON으로만 출력하세요. {{"question":"{question}","ratings":["..."],"pass":true,"findings":["..."],"unchecked":"..."}}. 각 기준의 이유를 순서대로 findings에 적고, 필수 미충족이 있다면 구체적 분기 또는 실제 코드 행을 밝혀 주세요.

{key}

[독해 질문과 응답]
{(root/'prompts'/f'{name}.txt').read_text(encoding='utf-8')}
{answer}

[독해가 받은 실제 Pages 문서와 그림]
{json.dumps(docs,ensure_ascii=False,separators=(',',':'))}

[독해가 받은 검증된 소스 창]
{json.dumps(opened,ensure_ascii=False,separators=(',',':'))}

[판정용 공식 소스 창]
'''+ '\n\n'.join(f'{label}\n{text}' for label,text in windows.items())
(root/'prompts'/f'{name}-judge.txt').write_text(prompt,encoding='utf-8')
print(question, 'pages',count,'code windows',len(opened),'judge input chars',len(prompt))
