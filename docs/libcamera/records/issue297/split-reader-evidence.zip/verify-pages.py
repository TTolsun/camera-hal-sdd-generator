from concurrent.futures import ThreadPoolExecutor
from hashlib import sha256
from pathlib import Path
from urllib.parse import quote
from urllib.request import Request,urlopen
import json
import sys

root=Path(__file__).parent.resolve()
final = sys.argv[1:] == ['--final']
expected=(root/('site/site-manifest.json' if final else 'expected-manifest.json')).read_bytes()
base='https://ttolsun.github.io/libcamera-sdd/'
def get(name):
    req=Request(base+quote(name,safe='/'),headers={'Cache-Control':'no-cache','User-Agent':'SDD-Q1-Prompt-Comparison/1.0'})
    with urlopen(req,timeout=20) as response:
        assert response.status==200
        return response.read()

assert get('site-manifest.json')==expected,'Pages no longer serves the baseline manifest'
manifest=json.loads(expected)
live=root/('pages-final' if final else 'pages-live')
live.mkdir(exist_ok=False)
outputs={key:sha for key,sha in manifest['outputs'].items() if key.endswith('.html') and not key.startswith('en/')}
def check(item):
    name,digest=item
    data=get(name)
    assert sha256(data).hexdigest()==digest,name
    path=live/name
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_bytes(data)
with ThreadPoolExecutor(max_workers=8) as pool:
    list(pool.map(check,outputs.items()))
(live/'site-manifest.json').write_bytes(expected)
name = 'item-visual-audit.json'
data = get(name)
assert sha256(data).hexdigest() == manifest['outputs'][name]
(live/name).write_bytes(data)
assert get('site-manifest.json') == expected
proof=dict(url=base,build_id=manifest['build_id'],manifest_sha256=sha256(expected).hexdigest(),
           verified_reader_html=len(outputs))
(root/('verified-pages-final.json' if final else 'verified-pages.json')).write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8')
print(json.dumps(proof))
