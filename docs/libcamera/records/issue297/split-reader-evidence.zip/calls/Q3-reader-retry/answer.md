정지·취소 경로에서 가장 큰 위험은 **장치의 버퍼 반환, 요청의 내부 완료, 애플리케이션에 대한 반환, 개별 콜백 실행을 같은 사건으로 취급하는 것**입니다. 이들은 서로 다른 단계입니다. 특히 `Camera::stop()`이 반환했더라도 별도 스레드에 게시된 콜백의 마지막 포인터 사용까지 끝났다고 판단할 수 없습니다.

아래 내용은 공개 SDD와 도구가 제공한 고정 소스에 근거한 분석과 검증 계획입니다. 실제 장치에서 시험한 결과는 아닙니다.

## 공개 계약과 정지 진입 조건

공개 API 계약상 실행 중인 카메라의 `Camera::stop()`은 캡처와 요청 처리를 즉시 중단하고, 미완료 요청을 취소하여 오류 상태로 동기 완료해야 합니다. 호출자는 카메라 상태에 영향을 주는 다른 함수와 이 호출을 동기화해야 합니다. 모든 상태에서 호출할 수 있으며, 실행 중이 아니면 아무 작업 없이 0을 반환합니다. [정지 경로 그림](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#camerastop의-미실행오류정상-경로)과 [camera.cpp:1431](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/camera.cpp#L1434)이 계약을 보여 줍니다.

실제 구현의 그림 분기는 다음과 같습니다.

- `!isRunning()`이면 바로 0을 반환하며 파이프라인 정지를 호출하지 않습니다.
- 실행 중이지만 `isAccessAllowed(CameraRunning)`이 음수이면 그 오류를 반환합니다.
- 접근을 통과하면 `CameraStopping`으로 바꾸고 `PipelineHandler::stop`을 Blocking으로 호출합니다. 호출이 돌아온 뒤 pending 요청이 없다는 ASSERT, `CameraConfigured` 설정, 0 반환이 이어집니다. [camera.cpp:1453](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/camera.cpp#L1434)

Blocking의 범위도 구분해야 합니다. 호출자와 수신 객체가 같은 스레드이면 Direct로 바뀌어 즉시 동기 호출됩니다. 다른 스레드이면 해당 호출의 `InvokeMessage`를 게시하고 그 호출의 세마포어를 기다립니다. 이는 **별도로 게시된 모든 Queued 콜백의 완료를 기다리는 계약이 아닙니다**. [stop 반환과 마지막 사용 그림](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#stop-반환과-별도-수신의-마지막-사용-확인), [bound_method.cpp:68](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/base/bound_method.cpp#L68). 제공된 코드 조각은 Blocking 메시지 게시 행까지 보여 주며, 세마포어 대기 자체는 해당 SDD 설명에서 확인했습니다.

연결 해제는 별도 경계입니다. SDD에 따르면 Running 중 연결 해제는 내부 상태를 Configured로 바꾸고 연결 해제 플래그를 설정합니다. 그 뒤 `stop()`의 `!isRunning()` 분기는 0을 반환하고 공통 정지를 호출하지 않을 수 있습니다. 잔여 요청이 이후 `Camera::requestComplete()`에 들어오면 `allowDisconnected=true`는 연결 해제 검사만 건너뛰며, 허용 상태 범위 밖이면 Fatal 분기에 들어갑니다. Running 중 연결 해제 시 대기 요청 처리는 문서에 TODO로 남아 있습니다. [UVC 실패 경계 그림](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#uvc-정지의-정상-경로와-실패-경계-그림), [camera.cpp:1481](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/camera.cpp#L1475).

## 공통 정지와 UVC 실패 분기

공통 `PipelineHandler::stop()`은 먼저 `waitingRequests_`를 로컬 큐로 옮깁니다. 그림에서 **큐 분리 → `stopDevice()` 정상 복귀 → 로컬 요청 반복**을 선택한 이유는, 장치 정지 중 `completeRequest()`가 호출되더라도 준비 대기 요청이 다시 장치에 투입되는 것을 막고 순서를 유지하기 위해서입니다. 각 로컬 요청은 `cancel()` 후 `doQueueRequest()`로 들어가 순번을 받고 제출 큐에 잠시 등록됩니다. 이미 취소된 분기에서는 `queueRequestDevice()` 대신 `completeRequest()`로 갑니다. 마지막에는 두 큐가 비었는지 각각 ASSERT하고 순번을 0으로 초기화합니다. ASSERT는 빌드에 따라 제외될 수 있으므로 그 행의 존재만으로 실행 시 큐가 비었다고 증명되지는 않습니다. [파이프라인 정지 그림](https://ttolsun.github.io/libcamera-sdd/scenarios/camera_stop.html#파이프라인-정지와-대기-요청-취소), [pipeline_handler.cpp:368](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/pipeline_handler.cpp#L359), [pipeline_handler.cpp:398](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/pipeline_handler.cpp#L398), [pipeline_handler.cpp:483](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/pipeline_handler.cpp#L483).

UVC에서는 `stopDevice()`가 `streamOff()`와 `releaseBuffers()`를 차례로 호출하면서 두 반환값을 확인하지 않습니다. [uvcvideo.cpp:320](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/pipeline/uvcvideo/uvcvideo.cpp#L320). [UVC 정지 그림](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#uvc-정지의-정상-경로와-실패-경계-그림)에서 중요한 분기는 다음과 같습니다.

- 스트리밍 중이 아니고 `queuedBuffers_`도 비었다면 `streamOff()`는 즉시 0을 반환합니다.
- 그 외에는 `VIDIOC_STREAMOFF`를 호출합니다. **음수 반환**이면 오류를 반환하므로 `State::Stopping`, 대기 버퍼 취소·알림, 큐 비우기, notifier 비활성화에 도달하지 않습니다.
- 성공하면 각 대기 버퍼를 캐시에 돌리고 취소한 뒤 `bufferReady`를 발생시킵니다. 이후 ASSERT, 큐 비우기, notifier 비활성화, `State::Stopped`가 이어집니다. 버퍼를 꺼내는 순서는 계약상 정해져 있지 않습니다. [v4l2_videodevice.cpp:2010](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/v4l2_videodevice.cpp#L2023), [v4l2_videodevice.cpp:2023](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/v4l2_videodevice.cpp#L2023).

실패 후에도 UVC가 `releaseBuffers()`로 진행한다는 점이 위험합니다. SDD에 따르면 캐시가 있으면 이 함수는 캐시를 먼저 reset한 다음 실패할 수 있는 `requestBuffers(0, memoryType_)`를 호출합니다. 그 후 남은 이벤트에서 `VIDIOC_DQBUF`가 실제 성공하고 반환 인덱스가 `queuedBuffers_`에 있는 경우에만 뒤따르는 `cache_->put()`의 null 접근 가능성을 조사해야 합니다. 이는 **조건부 위험이지 실제 장애 관측 결과는 아닙니다**. 또한 공통 stop은 `void`이고 UVC가 오류를 검사하지 않으므로, 정상 경로의 `Camera::stop()` 반환값 0만으로 장치 정지 성공을 판정할 수 없습니다. [UVC 정지 그림](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#uvc-정지의-정상-경로와-실패-경계-그림).

## 버퍼 완료부터 요청 반환과 콜백까지

선택한 UVC 경로에서 성공적인 `streamOff()`는 각 버퍼의 `bufferReady`를 발생시키고, SDD가 연결한 `UVCCameraData::imageBufferReady()`는 버퍼에서 요청을 얻어 timestamp를 복사한 뒤 `completeBuffer()`와 `completeRequest()`를 순서대로 호출합니다. 취소된 버퍼의 메타데이터는 status 외 필드가 유효하지 않으므로, 그 timestamp 복사를 유효한 촬영 시각으로 해석하면 안 됩니다. [uvcvideo.cpp:893](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/pipeline/uvcvideo/uvcvideo.cpp#L893), [UVC 정지 그림](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#uvc-정지의-정상-경로와-실패-경계-그림). 제공된 코드 조각에는 `bufferReady`와 이 슬롯의 연결 설정 행 자체는 포함되지 않았으며, 그 연결 경로는 SDD의 설명에 근거합니다.

공통 `completeBuffer()`는 먼저 `bufferCompleted.emit(request, buffer)`를 호출하고 **emit이 반환한 뒤** 요청 내부의 버퍼 추적을 갱신합니다. 반환값 `true`는 모든 버퍼가 완료됐다는 뜻이지 요청이 자동 완료됐다는 뜻은 아닙니다. 핸들러는 `completeRequest()`를 명시적으로 호출해야 합니다. 두 함수의 호출 문맥은 CameraManager 스레드입니다. [버퍼 완료 경계 그림](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#버퍼-완료와-명시적-요청-완료의-경계), [pipeline_handler.cpp:553](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/pipeline_handler.cpp#L556).

대기 요청의 직접 취소는 별도 경로입니다. `doCancelRequest()`는 당시 `pending_`의 각 버퍼를 취소하고 각 버퍼의 `bufferCompleted`를 emit한 다음, `cancelled_` 설정과 `pending_`, notifier, timer 정리를 수행합니다. 정상적인 내부 `completeBuffer()`와 달리 이 취소 함수에는 같은 버퍼 요청 연결 해제 호출이 없습니다. 그렇다고 취소 후 남아 보이는 `FrameBuffer::request()` 포인터를 유효한 소유권이나 수명 연장으로 해석해서는 안 됩니다. [버퍼별 취소 그림](https://ttolsun.github.io/libcamera-sdd/scenarios/camera_stop.html#버퍼별-취소-통지와-내부-정리), [request.cpp:139](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/request.cpp#L139), [내부 경계 그림](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#버퍼-알림과-요청-반환의-내부-경계-그림).

`completeRequest()` 호출 순서는 자유롭지만 앱으로의 요청 반환은 제출 순서입니다. 그림에서 **선두가 `RequestPending`이면 중단**, 아니면 pending 버퍼가 없다는 ASSERT 후 pop하고 `Camera::requestComplete()`를 호출하는 분기가 이를 만듭니다. 따라서 뒤 요청이 내부적으로 먼저 완료돼도 앞 요청 때문에 앱 반환이 지연될 수 있습니다. `completeRequest()`가 반환된 뒤 호출자는 해당 요청에 접근하면 안 됩니다. [제출 큐 그림](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#제출-큐의-선두-상태와-반환-순서), [pipeline_handler.cpp:584](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/pipeline_handler.cpp#L588), [camera.cpp:1481](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/camera.cpp#L1475).

개별 수신 함수의 실행 순서는 신호 발생 순서보다 더 조심해야 합니다.

- **Direct** 수신은 발신 스레드에서 중첩해 실행되고 복귀한 뒤 emit이 진행합니다. 따라서 버퍼 콜백에서 같은 버퍼를 다른 요청에 즉시 연결하면, 원래 요청의 emit 뒤 내부 정리가 새 연결을 지울 위험이 SDD에 설명돼 있습니다. 별도 허용이 없는 같은 함수의 중첩 재진입도 가정하면 안 됩니다.
- **Auto**는 같은 스레드에서 Direct, 다른 스레드에서 Queued입니다. **Queued**는 게시 후 기다리지 않습니다. 다른 스레드의 수신은 emit 반환 전에도 시작할 수 있고, 반대로 지연되거나 수신 객체 소멸·메시지 미소비로 실행되지 않을 수도 있습니다. 필터를 사용하는 명시적·재귀적 메시지 dispatch도 실제 전달 순서에 영향을 줄 수 있습니다. [직접·Queued 경계 그림](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#직접-중첩-호출과-별도-queued-수신의-경계), [마지막 사용 확인 그림](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#stop-반환과-별도-수신의-마지막-사용-확인), [bound_method.cpp:68](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/base/bound_method.cpp#L68).

`addBuffer()`는 버퍼 참조를 저장하므로 호출자는 적어도 요청 완료 콜백까지 버퍼를 유효하게 유지해야 합니다. 별도 Queued 수신에 전달한 포인터는 그대로 전달되므로 그 수신자의 실제 마지막 사용까지 대상 수명을 추가로 보장하고 동기화해야 합니다. `stop()` 반환이나 큐가 비었다는 사실만으로 이를 대체할 수 없습니다. 펜스 타임아웃 뒤 재사용하는 경우에는 SDD가 요구하는 `releaseFence()`와 `addBuffer()` 결과도 확인해야 합니다. [request.cpp:442](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/request.cpp#L103), [내부 경계 그림](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#버퍼-알림과-요청-반환의-내부-경계-그림).

## 변경 후 검증 계획

다음은 **조건·관측값·판정 방법**을 갖춘 계획이며, 실제 관측을 수행했다는 뜻은 아닙니다.

1. **진입과 스레드 분기.** 실행 중이 아닌 경우, 실행 중 접근 실패, 접근 성공을 각각 마련합니다. `isRunning`, 접근 결과, 상태, stop 진입·복귀, 호출자와 수신 스레드 ID를 기록합니다. 각각 조기 0, 해당 음수, 또는 Stopping → Blocking 호출 → ASSERT 위치 → Configured → 0의 소스 분기와 대조합니다. 같은 스레드와 다른 스레드를 각각 시험하여 Direct 호출과 해당 Blocking 호출의 대기를 확인합니다. 카메라 상태 변경 호출 간 동기화 여부도 기록합니다. [정지 그림](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#camerastop의-미실행오류정상-경로), [bound_method.cpp:68](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/base/bound_method.cpp#L68).

2. **혼합된 미완료 요청.** 준비 대기와 장치 대기 요청을 함께 둔 뒤 정지합니다. 큐 분리 전후, `stopDevice()` 진입·복귀, 각 취소와 `doQueueRequest()`, 두 큐, 순번, 정지 후 재투입 여부를 기록합니다. 분리한 대기 요청이 장치에 재투입되지 않고 각각 취소·완료 경로를 거치는지, 종료 시 두 큐가 비었는지 실제 값으로 판정합니다. `stopDevice()` 호출 직전 표식만으로 장치가 정지했다고 판정하지 않습니다. [파이프라인 정지 그림](https://ttolsun.github.io/libcamera-sdd/scenarios/camera_stop.html#파이프라인-정지와-대기-요청-취소), [pipeline_handler.cpp:368](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/pipeline_handler.cpp#L359).

3. **UVC 실패 주입.** `VIDIOC_STREAMOFF`와 `releaseBuffers()`에 각각 실패를 주입합니다. 원래 호출의 반환값, `state_`, 장치·요청 큐, cache, notifier, ASSERT 도달 여부와 이후 이벤트를 기록합니다. STREAMOFF 실패에서 버퍼 반환 루프와 notifier 정리에 도달했는지, UVC가 해제 호출로 진행했는지 확인합니다. 잔여 이벤트가 있으면 `DQBUF`의 성공 여부와 인덱스, 큐 일치 여부 및 cache 상태를 함께 기록하여 위의 null 접근 조건이 실제 성립하는지 판정합니다. 단순히 `Camera::stop()==0`인지만으로 성공 처리하지 않습니다. [UVC 정지 그림](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#uvc-정지의-정상-경로와-실패-경계-그림), [v4l2_videodevice.cpp:2023](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/v4l2_videodevice.cpp#L2023).

4. **동일 제출 회차의 횟수와 순서.** 요청이 유효할 때 재사용 주소나 cookie만으로 혼동되지 않는 논리적 회차 ID와 그 회차의 버퍼 ID 집합, 실제 제출·등록 순서를 보관합니다. 각 버퍼에 대해 완료 **신호 발생**과 수신자별 콜백 진입·복귀를 따로 기록하고, 같은 회차의 `completeRequest()` 진입, `requestComplete()` 통지, 수신자별 요청 콜백 진입·복귀도 별도 집계합니다. 각 대상 버퍼의 알림과 요청 통지가 누락·중복됐는지 회차별로 비교합니다. `completeRequest()` 진입 하나가 즉시 같은 요청의 앱 통지 하나와 대응한다고 가정하지 않습니다. 제출 순서는 동시 호출의 시작 시각 대신 실제 등록 기록과 대조합니다. [회차별 비교 그림](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#제출-회차별-완료-기록의-비교-계획), [동시 제출 그림](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#동시-제출정지지연-수신의-검증-위치), [pipeline_handler.cpp:584](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/pipeline_handler.cpp#L588).

   순서 판정은 **신호 발생, 내부 갱신, 앱 통지 호출, 각 수신 함수의 실행**을 따로 비교합니다. 소스가 보장하는 emit 후 내부 갱신과 제출 순서의 요청 통지를 확인하고, Direct 콜백은 중첩 진입·복귀를 확인합니다. Queued 콜백은 연결 종류, 수신 스레드와 dispatch 필터·재귀 깊이를 함께 기록하여 실제 관측 순서를 판정합니다. 버퍼 간 순서나 서로 다른 Queued 수신자의 실행 완료 순서를 임의로 요구하지 않습니다. [콜백 경계 그림](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#직접-중첩-호출과-별도-queued-수신의-경계), [마지막 사용 확인 그림](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#stop-반환과-별도-수신의-마지막-사용-확인).

5. **수명과 연결 해제.** Direct 재진입과 지연 Queued 수신을 각각 시험하고 요청·버퍼 포인터의 마지막 사용, 삭제·재사용 시점, 이벤트 루프 진행 여부를 기록합니다. 모든 해당 수신자의 마지막 사용 전에 대상이 파괴되거나 재사용되지 않았는지 판정합니다. 별도로 Running 중 연결 해제를 시험하여 당시 상태, 이후 `stop()` 분기와 잔여 완료가 실제 진입했다면 그 상태 검사 결과를 기록합니다. 도달하지 않은 분기의 결과는 추측하지 않습니다. [마지막 사용 확인 그림](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#stop-반환과-별도-수신의-마지막-사용-확인), [UVC 정지 그림](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#uvc-정지의-정상-경로와-실패-경계-그림).

이 자료만으로 특정 장치에서 ioctl 실패 후 이벤트가 실제 도착하는지, 모든 콜백이 소비되는지, 또는 변경 후 계약이 충족되는지는 확인할 수 없습니다. 위 판정은 해당 장치와 애플리케이션의 관측이 필요합니다.

TAILS: 1=2d6cfe4, 2=54fc9ae, 3=5510553, 4=3eed59a, 5=c71a1f1, 6=e425391, 7=6f0b721, 8=313bca6, 9=f3f19f8
