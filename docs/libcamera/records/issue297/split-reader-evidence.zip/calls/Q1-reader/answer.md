`queueRequest()`가 **0을 반환한 시점은 요청이 접수된 시점**입니다. 캡처나 요청 처리가 끝났다는 뜻은 아닙니다. 앱은 이후 `requestCompleted` 알림에서 요청 상태를 확인하고, 각 버퍼의 프레임 상태도 따로 확인해야 합니다. 버퍼를 다시 사용하려면 요청 완료와 해당 버퍼를 사용하는 모든 지연 수신자의 마지막 사용이 끝나야 하며, 남은 펜스가 있다면 먼저 회수해야 합니다.

### 접수부터 요청 반환까지

1. 앱이 `createRequest()`로 만든 `Request`는 앱 소유입니다. `addBuffer()`는 스트림에 대한 버퍼 참조를 저장하므로 앱은 적어도 **요청 완료 콜백이 호출될 때까지** 버퍼를 유효하게 유지해야 합니다. 제출 시 전달하는 raw 포인터도 객체의 수명을 늘리지 않습니다. 요청 소유자는 완료 핸들러에서 요청을 삭제하거나 상태를 초기화해 재사용할 수 있습니다. [요청과 버퍼를 유지할 기간](https://ttolsun.github.io/libcamera-sdd/camera-requests.html#요청과-버퍼를-유지할-기간), [camera.cpp:1254](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/camera.cpp#L1254), [request.cpp:447](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/request.cpp#L447).

2. `queueRequest()`는 접근 권한과 요청을 검사한 뒤 `ConnectionTypeQueued`로 파이프라인 핸들러 호출을 예약하고 0을 반환합니다. 예를 들어 버퍼가 없거나 비활성 스트림이 있으면 `-EINVAL`입니다. API 주석은 메모리 부족 시 `-ENOMEM`도 반환 계약에 포함하지만, 읽은 문서는 이 함수 본문에 직접 `-ENOMEM`을 반환하는 분기는 없다고 구분합니다. 그림의 판단 분기는 **“호출 뒤 0 반환”과 이후의 “큐에 넣은 요청 → 완료 알림”이 서로 다른 경로**라는 점입니다. [접수 반환과 완료 알림](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#접수-반환과-완료-알림), [제출 큐의 선두 상태와 반환 순서](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#제출-큐의-선두-상태와-반환-순서), [camera.cpp:1361](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/camera.cpp#L1361).

3. 접수 뒤에도 준비와 장치 제출이 남습니다. 문서상 핸들러는 요청을 `waitingRequests_`에 넣고 `prepare(300ms)`를 호출합니다. 준비 실패 시 요청을 취소합니다. 대기 큐의 선두가 준비되지 않았거나 장치에 제출 가능한 최대 요청 수에 도달하면 뒤의 요청을 장치에 넘기지 않습니다. 실제 장치 제출 시에는 요청을 `queuedRequests_`에 넣고 sequence를 지정합니다. 이미 취소된 요청은 완료 처리하고, 그렇지 않으면 `queueRequestDevice()`를 호출합니다. 이 호출이 0이 아니면 취소 경로로 갑니다. 핸들러 구현자는 요청 파라미터가 그 요청의 버퍼에 캡처되는 프레임에 적용되도록 장치를 설정할 책임이 있습니다. [제출 큐의 선두 상태와 반환 순서](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#제출-큐의-선두-상태와-반환-순서).

4. 버퍼마다 핸들러는 CameraManager 스레드에서 `completeBuffer()`를 호출합니다. 구현은 먼저 `bufferCompleted` 신호를 발생시키고, 이어 내부 대기 집합에서 버퍼를 제거하며 버퍼의 요청 연결을 해제합니다. 버퍼 상태가 `FrameCancelled`이면 요청의 취소 표시도 설정합니다. 반환값이 `false`면 남은 버퍼가 있고, `true`면 **모든 버퍼가 완료**된 것입니다. 그림의 중요한 분기는 `true`여도 **요청이 자동 완료되지는 않는다**는 것입니다. 핸들러는 필요한 후속 작업의 기회를 가진 뒤 `completeRequest()`를 명시적으로 호출해야 합니다. [버퍼 완료와 명시적 요청 완료의 경계](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#버퍼-완료와-명시적-요청-완료의-경계), [pipeline_handler.cpp:553](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/pipeline_handler.cpp#L553), [request.cpp:103](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/request.cpp#L103).

5. `completeRequest()`는 대기 버퍼가 없다는 조건에서 요청을 `RequestComplete` 또는 `RequestCancelled`로 바꿉니다. 취소된 버퍼가 있었는지에 따른 분기이며, 프레임 데이터의 성공 여부와는 별개입니다. 핸들러가 완료 처리를 호출하는 순서에는 제약이 없지만 앱에 반환하는 순서는 제출 순서입니다. 그림에서 `queuedRequests_`의 **선두가 `RequestPending`이면 `break`** 하므로, 뒤 요청이 이미 완료됐어도 반환을 기다립니다. 선두가 대기 상태가 아니면 대기 버퍼가 없음을 단언하고 큐에서 제거한 뒤 `Camera::requestComplete()`를 호출합니다. Camera는 `requestCompleted` 신호를 발생시킵니다. 따라서 앱이 완료를 판단하는 알림은 이 요청별 신호이고, 그때 상태를 읽어 정상 완료와 취소를 구분해야 합니다. [제출 큐의 선두 상태와 반환 순서](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#제출-큐의-선두-상태와-반환-순서), [request.cpp:125](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/request.cpp#L125), [pipeline_handler.cpp:584](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/pipeline_handler.cpp#L584), [camera.cpp:1475](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/camera.cpp#L1475).

### 실패·취소 시 읽을 수 있는 것

요청의 완료 상태만으로 이미지가 유효하다고 판단할 수 없습니다. 각 버퍼의 `FrameMetadata::status`를 확인해야 합니다.

| 버퍼 상태 | 읽을 수 있는 데이터 |
|---|---|
| `FrameSuccess` | 프레임 데이터와 모든 메타데이터 필드가 유효합니다. |
| `FrameError` | 프레임 데이터는 일부 또는 전부 손상·누락·무효일 수 있습니다. `sequence`와 `timestamp`는 유효하지만 나머지 메타데이터는 무효일 수 있습니다. |
| `FrameCancelled` | 프레임 데이터와 `status`를 제외한 모든 메타데이터가 무효입니다. |
| `FrameStartup` | 소스 주석상 캡처 자체와 나머지 메타데이터 필드는 유효하지만, IPA 초기화 또는 리셋 단계의 화질로 인해 이미지를 사용하지 않도록 권고합니다. |

문서는 프레임 데이터를 사용할 때 `FrameSuccess`를 기준으로 삼으라고 안내합니다. `RequestComplete`는 모든 프레임이 `FrameSuccess`라는 보장이 아닙니다. [QBUF 호출 전 실패와 cache 반환](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#qbuf-호출-전-실패와-cache-반환), [타임아웃 뒤 펜스 회수](https://ttolsun.github.io/libcamera-sdd/camera-requests.html#타임아웃-뒤-펜스-회수), [framebuffer.cpp:40](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/framebuffer.cpp#L40), [request.cpp:125](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/request.cpp#L125).

읽은 문서의 UVC 경로는 **접수 후에도 실패해 취소될 수 있는 예**를 보여 줍니다. `queueRequestDevice()`가 제어를 처리한 다음 버퍼 제출에 실패하면 오류를 전달하고, 공통 호출자는 0이 아닌 반환값에서 `cancelRequest()`를 호출합니다. 제어 처리 뒤 버퍼 제출이 실패한 경로에 제어 변경을 롤백하는 코드는 문서에 확인되지 않습니다.

그림에서 사용한 구체적인 분기는 다음과 같습니다.

- 캐시 `get()`이 사용 가능한 항목을 찾지 못하면 `-ENOENT`입니다. 아직 인덱스와 guard를 확보하지 않았으므로 이번 호출의 guard에 의한 `put`은 없습니다.
- 인덱스를 확보한 뒤 플레인 수가 장치 형식보다 적으면 `-EINVAL`입니다. 수가 다르고 버퍼가 비연속인 경우도 `-EINVAL`입니다. 두 경우 guard가 확보한 인덱스를 `put`하며, 이번 버퍼는 QBUF와 `queuedBuffers_` 등록에 도달하지 않습니다.
- 검사를 통과해도 QBUF 성공이 보장되는 것은 아닙니다. QBUF 실패 시 guard가 캐시 인덱스를 반환합니다. 성공하면 버퍼를 등록하고 guard를 해제하며, 프레임 완료 알림은 별도입니다.
- DQBUF 오류나 예상 밖 인덱스에서는 `nullptr`를 반환하고 `bufferReady`를 보내지 않습니다. 이 경우를 완료가 있었다는 증거로 해석할 수 없습니다.

이 내용은 해당 문서가 설명하는 UVC 및 V4L2 경로의 범위입니다. 모든 핸들러나 장치가 동일한 내부 경로를 사용한다는 근거는 아닙니다. [QBUF 호출 전 실패와 cache 반환](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#qbuf-호출-전-실패와-cache-반환).

### 버퍼와 요청을 다시 쓰는 조건

요청 완료 콜백에 도달한 뒤, 앱이 해당 요청과 버퍼를 사용하는 다른 수신자까지 모두 끝냈음을 확인하고 재사용할 수 있습니다. 같은 `Request`를 다시 제출하려면 `reuse()`로 상태를 초기화합니다.

- **기본 `reuse()`**: 기존 버퍼 맵을 비웁니다. 다시 제출하려면 `addBuffer()`로 버퍼를 다시 연결해야 합니다.
- **`reuse(ReuseBuffers)`**: 기존 버퍼 맵을 유지하고 각 버퍼를 요청에 다시 연결해 대기 집합에 넣습니다. 두 경우 모두 요청 상태는 `RequestPending`으로 돌아가고 controls와 요청 메타데이터가 지워집니다.
- **펜스 사용 시**: `ReuseBuffers`는 버퍼를 재사용하지만 연결된 펜스를 재사용하지 않으며, API는 펜스를 쓰는 경우 이 플래그를 피하도록 권고합니다. 펜스가 신호되지 않아 타임아웃된 버퍼에는 펜스가 남을 수 있으므로 `releaseFence()`로 회수한 뒤 재사용해야 합니다. 남은 펜스를 가진 버퍼를 `addBuffer()`에 넣으면 구현은 `-EEXIST`를 반환합니다. 같은 요청을 `ReuseBuffers`로 재사용하는 경우에도 문서는 남은 타임아웃 펜스를 재제출 전에 회수하라고 안내합니다. [재사용 버퍼의 요청 연결](https://ttolsun.github.io/libcamera-sdd/camera-requests.html#재사용-버퍼의-요청-연결), [버퍼 재사용과 펜스 권고](https://ttolsun.github.io/libcamera-sdd/camera-requests.html#버퍼-재사용과-펜스-권고), [타임아웃 뒤 펜스 회수](https://ttolsun.github.io/libcamera-sdd/camera-requests.html#타임아웃-뒤-펜스-회수), [request.cpp:375](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/request.cpp#L375), [request.cpp:462](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/request.cpp#L462), [request.cpp:483](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/request.cpp#L483), [framebuffer.cpp:432](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/framebuffer.cpp#L432).

### 직접 수신과 지연 수신의 수명

완료 핸들러에서 요청을 삭제할 수 있다는 API 계약은 **별도로 큐에 전달된 모든 수신자가 사용을 마쳤다는 보장까지 뜻하지 않습니다**. 신호 발신자는 전달한 포인터나 참조가 신호 발생 이후에도 유효하도록 해야 합니다. `invokeMethod()`는 값과 참조 인자를 복사하지만 포인터는 그대로 전달합니다. 따라서 앱의 요청 소유자와 발신자는 별도 Queued 수신자들의 마지막 사용을 추적·동기화한 뒤 요청과 버퍼를 삭제하거나 재사용해야 합니다. [queued 수신과 해제 시점의 책임](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#queued-수신과-해제-시점의-책임), [object.cpp:264](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/base/object.cpp#L264).

Object 슬롯의 `Auto`는 같은 스레드면 `Direct`, 다른 스레드면 `Queued`를 선택합니다. 명시적 `Direct`는 다른 스레드에 속한 객체라도 발신 스레드에서 즉시 동기 호출합니다. Object 외 수신자의 멤버 함수, functor, 정적 함수도 호출 문맥에서 즉시 실행됩니다. 반면 Queued는 메시지를 게시하고 수신 완료를 기다리지 않습니다. 구현상 다른 스레드의 수신이 `emit()` 반환 전에 시작될 수도 있으므로 두 시점의 일반적인 선후관계는 보장되지 않습니다. 수신 객체가 살아 있고 수신 스레드가 메시지를 실제 소비하는지도 중요하며, 스레드가 멈추기 전 Queued 호출이 실행된다는 보장은 없습니다. [stop 반환과 별도 수신의 마지막 사용 확인](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#stop-반환과-별도-수신의-마지막-사용-확인), [bound_method.cpp:68](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/base/bound_method.cpp#L68).

`Camera::stop()`은 실행 중이고 접근 검사를 통과한 경우 파이프라인 정지를 Blocking으로 호출하고, 돌아온 뒤 pending request가 없음을 단언합니다. 그러나 그림의 분기처럼 **stop 반환과 별도 Queued 수신자의 마지막 사용 사이에는 보장된 순서가 없습니다**. 앱은 카메라 상태 변경도 필요에 따라 동기화해야 합니다. [stop 반환과 별도 수신의 마지막 사용 확인](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#stop-반환과-별도-수신의-마지막-사용-확인).

문서에 적힌 콜백 진입·복귀, 스레드 ID, 큐 선두, 메시지 전달 및 마지막 포인터 사용 추적은 **검증 계획**입니다. 실제 장치에서 실행해 관측한 결과는 제공된 자료에서 확인되지 않습니다. 따라서 특정 앱의 콜백 실행 스레드, 지연 수신 완료 시점, 장치별 제어 적용과 실패 후 동작은 이 자료만으로 확정할 수 없습니다. [제출 큐의 선두 상태와 반환 순서](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#제출-큐의-선두-상태와-반환-순서), [stop 반환과 별도 수신의 마지막 사용 확인](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#stop-반환과-별도-수신의-마지막-사용-확인).

TAILS: 1=7c8e881, 2=0e8b2d7, 3=4b55857, 4=107d101, 5=6f0b721, 6=8045828, 7=fe74acd
