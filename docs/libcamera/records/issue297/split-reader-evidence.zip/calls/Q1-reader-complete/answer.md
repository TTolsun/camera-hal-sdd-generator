**`queueRequest()`가 0을 반환한 시점은 제출이 접수된 시점입니다.** 촬영이나 요청 완료를 뜻하지 않습니다. 각 버퍼가 완료된 뒤에도 파이프라인 핸들러가 요청을 명시적으로 완료해야 하고, 애플리케이션에는 앞서 제출한 요청들까지 반환 가능한 순서가 되었을 때 `requestCompleted` 신호가 전달됩니다. 버퍼를 다시 사용하려면 해당 작업의 완료뿐 아니라 그 버퍼를 사용하는 모든 소비자의 마지막 사용과 필요한 동기화가 끝나야 합니다.

### 제출부터 요청 반환까지

1. **제출 가능 상태와 접수.** 카메라는 요청 제출 시 `Running` 상태여야 합니다. 구현은 접근 검사 후 요청이 이 카메라에서 만들어졌는지, 상태가 `RequestPending`인지 확인합니다. 이어서 컨트롤 목록, 비어 있지 않은 버퍼 맵, 활성 스트림 여부를 검사합니다. 실패하면 즉시 오류를 반환합니다. 검사를 통과하면 `PipelineHandler::queueRequest`를 `ConnectionTypeQueued`로 호출하고 0을 반환합니다. 따라서 0은 장치 처리 완료의 증거가 아닙니다. 문서의 그림에서도 **“호출 뒤 반환”**과 **“큐에 넣은 뒤의 API 완료 알림”**이 별도 분기입니다. ([접수·반환과 완료 알림](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#접수-반환과-완료-알림), [camera.cpp:1330](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/camera.cpp#L1330), [camera.cpp:1349](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/camera.cpp#L1349))

   이후 준비 단계가 실패하면 요청은 취소됩니다. 준비되지 않은 선두 요청이나 장치 큐 용량 제한은 뒤 요청의 전달을 지연할 수 있습니다. 장치 제출 함수가 오류를 반환하는 경로도 요청 취소로 이어집니다. 이는 최초 `queueRequest()`의 성공 반환 이후에 일어날 수 있는 일입니다. ([제출 큐의 선두 상태와 반환 순서](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#제출-큐의-선두-상태와-반환-순서))

2. **버퍼별 완료.** 핸들러는 CameraManager 스레드에서 `completeBuffer(request, buffer)`를 호출합니다. 실제 순서는 중요합니다. 먼저 `bufferCompleted.emit(request, buffer)`로 통지하고, **그 다음** 내부 `completeBuffer()`를 호출합니다. 내부 함수는 `pending_`에서 버퍼를 제거하고, 이어서 버퍼의 요청 역참조를 `nullptr`로 설정한 뒤 취소 상태를 기록하고 남은 버퍼가 없는지를 반환합니다. 따라서 직접 실행되는 버퍼 완료 수신자는 통지 시점에 아직 이 내부 갱신이 끝났다고 가정하면 안 됩니다. ([버퍼 완료와 명시적 요청 완료의 경계](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#버퍼-완료와-명시적-요청-완료의-경계), [pipeline_handler.cpp:563](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/pipeline_handler.cpp#L563), [request.cpp:103](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/request.cpp#L103))

3. **요청별 완료와 반환.** 그림에서 `completeBuffer()`의 **false 분기**는 남은 버퍼가 있음을 뜻하고, **true 분기**는 모든 버퍼가 완료됐음을 뜻합니다. true여도 요청은 자동 완료되지 않습니다. 핸들러가 필요한 후속 작업을 할 기회를 가진 뒤 `completeRequest()`를 명시적으로 호출해야 합니다. 구현은 남은 버퍼가 없음을 단언하고, 취소된 버퍼가 있었는지에 따라 요청을 `RequestComplete` 또는 `RequestCancelled`로 바꿉니다. ([버퍼 완료와 명시적 요청 완료의 경계](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#버퍼-완료와-명시적-요청-완료의-경계), [request.cpp:125](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/request.cpp#L125))

   핸들러는 요청들을 완료 순서대로 처리할 수 있지만 앱 반환은 **제출 순서**입니다. 완료 루프는 큐 선두가 `RequestPending`이면 중단하고, 아니면 pending 버퍼가 없음을 확인한 후 선두를 제거해 `Camera::requestComplete()`를 호출합니다. 따라서 뒤 요청이 이미 완료되어도 앞 요청이 pending이면 알림이 기다립니다. `requestComplete()`는 `requestCompleted` 신호를 발생시킵니다. ([제출 큐의 선두 상태와 반환 순서](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#제출-큐의-선두-상태와-반환-순서), [pipeline_handler.cpp:584](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/pipeline_handler.cpp#L584), [camera.cpp:1481](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/camera.cpp#L1481))

### 완료 후 무엇을 읽을 수 있는가

요청 상태만으로 각 프레임의 성공을 판정하지 말고 각 버퍼의 `FrameMetadata::status`를 확인해야 합니다. 요청의 `RequestComplete`는 취소 여부에 따른 상태이며, 개별 프레임의 성공과는 별개입니다.

- `FrameSuccess`: 프레임 데이터와 모든 메타데이터 필드가 유효합니다.
- `FrameError`: 데이터가 일부 또는 전부 손상·누락되었거나 유효하지 않습니다. `sequence`와 `timestamp`는 유효하지만 다른 필드는 유효하지 않을 수 있습니다.
- `FrameCancelled`: 프레임 완료 전에 캡처가 중단됐습니다. 프레임 데이터와 `status` 이외의 메타데이터는 유효하지 않습니다.
- `FrameStartup`: 캡처 자체는 성공하고 다른 메타데이터도 유효하지만, 이미지 품질 파라미터가 초기화 단계여서 사용하지 않도록 권고합니다.

따라서 이 문서의 재사용 안내대로 프레임 데이터를 소비하려면 `FrameSuccess`를 기준으로 삼습니다. ([타임아웃 뒤 펜스 회수](https://ttolsun.github.io/libcamera-sdd/camera-requests.html#타임아웃-뒤-펜스-회수), [framebuffer.cpp:40](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/framebuffer.cpp#L40), [request.cpp:112](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/request.cpp#L112))

### 객체 수명과 버퍼 재사용

앱은 `createRequest()`가 반환한 요청을 소유합니다. 완료 핸들러에서 요청을 삭제하거나 상태를 초기화해 재사용할 수 있습니다. `addBuffer()`는 버퍼 참조를 저장하며, 호출자는 적어도 요청 완료 콜백이 호출될 때까지 버퍼를 유효하게 유지해야 합니다. 큐에 전달된 raw 포인터도 소유권이나 수명을 연장하지 않습니다. ([요청과 버퍼를 유지할 기간](https://ttolsun.github.io/libcamera-sdd/camera-requests.html#요청과-버퍼를-유지할-기간), [camera.cpp:1254](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/camera.cpp#L1254), [request.cpp:447](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/request.cpp#L447))

완료 알림이 모든 별도 소비자의 사용 종료를 뜻하지는 않습니다. 직접 연결된 수신자는 발신 중 동기 실행될 수 있고, 다른 스레드의 `Object`에 대한 Auto 연결은 Queued가 될 수 있습니다. Queued는 메시지를 게시하고 기다리지 않으며, 수신은 발신 반환 전에도 시작할 수 있습니다. 포인터는 복사된 소유 객체가 아니라 그대로 전달되므로, 앱과 발신자는 별도 지연 수신자마다 마지막 사용을 추적·동기화하고 그때까지 해당 요청과 버퍼를 유효하게 유지해야 합니다. 버퍼를 계속 사용하는 다른 소비자가 있다면 그 소비자의 마지막 사용도 재사용 판단에 포함해야 합니다. `stop()`의 반환만으로 별도 Queued 수신자의 마지막 사용이 끝났다고 보장되지 않습니다. ([Queued 수신과 해제 시점의 책임](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#queued-수신과-해제-시점의-책임), [stop 반환과 별도 수신의 마지막 사용 확인](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#stop-반환과-별도-수신의-마지막-사용-확인), [object.cpp:264](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/base/object.cpp#L264), [bound_method.cpp:71](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/base/bound_method.cpp#L71))

요청을 다시 제출할 때 `reuse()`의 두 분기는 다음과 같습니다.

- **기본 `reuse()`**: `bufferMap_.clear()`로 기존 스트림·버퍼 맵을 비웁니다. 다시 제출하기 전에 `addBuffer()`로 버퍼를 다시 연결해야 합니다.
- **`reuse(ReuseBuffers)`**: 기존 맵을 유지하면서 각 버퍼의 요청 역참조를 이 요청으로 설정하고 `pending_`에 다시 넣습니다.
- **두 경로 모두** 분기 후 `status_ = RequestPending`을 설정하고 컨트롤과 메타데이터를 비웁니다. 이는 다음 `queueRequest()`의 `RequestPending` 검사와 연결됩니다. ([재사용 버퍼의 요청 연결](https://ttolsun.github.io/libcamera-sdd/camera-requests.html#재사용-버퍼의-요청-연결), [request.cpp:385–403의 시작 행](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/request.cpp#L385), [camera.cpp:1344](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/camera.cpp#L1344))

`ReuseBuffers`는 이전 버퍼들을 재사용하지만 연결됐던 펜스를 재사용하는 옵션은 아닙니다. 문서는 펜스를 사용하는 경우 이 플래그를 피하도록 권고합니다. 특히 펜스가 신호되지 않아 요청이 타임아웃되면 펜스가 버퍼에 남습니다. 앱은 재사용 전에 `releaseFence()`로 회수해야 합니다. `addBuffer()` 구현도 버퍼에 펜스가 남아 있으면 `-EEXIST`로 거부합니다. ([버퍼 재사용과 펜스 권고](https://ttolsun.github.io/libcamera-sdd/camera-requests.html#버퍼-재사용과-펜스-권고), [request.cpp:462](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/request.cpp#L462), [request.cpp:483](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/request.cpp#L483), [framebuffer.cpp:432](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/framebuffer.cpp#L432))

자료의 수신자 추적과 동기화 절차는 **검증 계획**이며, 특정 앱이나 장치에서 완료되었다는 결과가 아닙니다. 문서에는 WSL2 Virtual2에서 CPU 전용 버퍼를 이용한 콜백 관측이 따로 있지만, 반환 근처 표식은 실제 C++ 함수 반환 완료를 증명하지 않고 DMA 동기화나 물리 카메라·센서·ISP 촬영도 검증하지 않았습니다. 따라서 이 자료만으로 플랫폼별 DMA 또는 장치 간 동기화가 정확히 어디까지 완료되는지 판단할 수 없으며, 해당 플랫폼과 모든 소비자의 동기화 계약을 별도로 확인해야 합니다. ([반환 근처 표시로 알 수 있는 범위](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#반환-근처-표시로-알-수-있는-범위))

TAILS: 1=422e7b4, 2=b28f715, 3=4b55857, 4=107d101, 5=6f0b721, 6=8045828, 7=fe74acd
