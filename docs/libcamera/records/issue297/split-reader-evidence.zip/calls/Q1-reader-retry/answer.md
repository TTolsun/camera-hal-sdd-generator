`queueRequest()`가 0을 반환한 시점은 **제출이 접수된 시점**입니다. 요청의 완료는 핸들러가 모든 버퍼의 완료 처리를 마친 뒤 `completeRequest()`를 호출해 요청 상태를 확정하고, 제출 순서에 따라 `requestCompleted`로 앱에 반환될 때 판단해야 합니다. 각 버퍼의 프레임 데이터 사용 가능 여부는 그 버퍼의 `FrameMetadata::status`로 따로 판단합니다.

버퍼를 다시 사용하려면 요청 완료 통지만 보는 것으로 충분하지 않습니다. 해당 버퍼를 계속 사용하는 모든 소비자의 마지막 사용이 끝났고, 지연 수신자에게 전달한 요청·버퍼도 더 이상 사용되지 않으며, 남은 펜스가 있다면 필요한 회수를 마쳐야 합니다. 그 후 요청을 재사용한다면 `reuse()`의 버퍼 연결 방식에 맞춰 다시 준비합니다.

1. **제출 접수와 처리 대기**

   제출은 카메라가 `Running` 상태일 때 허용됩니다. 요청은 그 카메라가 만든 `RequestPending` 요청이어야 하고, 유효한 컨트롤 목록과 적어도 하나의 버퍼가 있어야 하며, 각 스트림은 활성 상태여야 합니다. 검사 실패는 즉시 음수로 반환됩니다. 검사를 통과하면 `PipelineHandler::queueRequest`를 `ConnectionTypeQueued`로 호출하고 0을 반환합니다. 따라서 그림의 **“호출 뒤 반환 → 0”** 분기는 장치 처리나 촬영 완료를 뜻하지 않습니다. ([접수 반환과 완료 알림](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#접수-반환과-완료-알림), [camera.cpp:1330](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/camera.cpp#L1330), [camera.cpp:1349](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/camera.cpp#L1349))

   문서에서 설명한 이후 경로에서는 준비가 끝나지 않은 선두 요청이나 장치 큐의 용량 제한 때문에 전달이 기다려질 수 있습니다. 준비 실패는 취소로 이어지고, 장치 제출 함수가 0이 아닌 값을 반환하면 핸들러가 요청을 취소합니다. 즉 최초의 0은 이후 처리까지 성공했다는 보장이 아닙니다. API 주석은 메모리 부족의 `-ENOMEM`도 반환 계약에 적지만, 읽은 `Camera::queueRequest()` 본문에 이를 직접 반환하는 분기는 없습니다. ([제출 큐의 선두 상태와 반환 순서](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#제출-큐의-선두-상태와-반환-순서))

2. **버퍼별 완료와 요청별 완료**

   핸들러는 CameraManager 스레드에서 `completeBuffer(request, buffer)`를 호출합니다. 구현은 먼저 `bufferCompleted`를 발신하고, 이어 내부 대기 집합에서 버퍼를 제거하고 버퍼의 요청 연결을 지웁니다. 그림의 **“모든 버퍼가 완료됐는가?”** 분기에서 `false`는 아직 남은 버퍼가 있다는 뜻이고, `true`는 마지막 버퍼까지 완료됐다는 뜻입니다. `true`여도 요청이 자동 완료되지는 않습니다. 핸들러는 필요한 나머지 작업을 한 뒤 `completeRequest()`를 명시적으로 호출해야 합니다. 직접 수신 콜백은 발신 중 실행될 수 있으므로, 버퍼 완료 신호의 진입 시점과 그 뒤 내부 추적 갱신 시점을 같은 시점으로 취급해서는 안 됩니다. ([버퍼 완료와 명시적 요청 완료의 경계](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#버퍼-완료와-명시적-요청-완료의-경계), [pipeline_handler.cpp:553](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/pipeline_handler.cpp#L553), [request.cpp:103](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/request.cpp#L103))

   `completeRequest()`는 대기 버퍼가 없음을 전제로 요청 상태를 확정합니다. 버퍼 취소가 기록됐으면 `RequestCancelled`, 그렇지 않으면 `RequestComplete`입니다. 그다음 제출 큐의 선두부터 확인합니다. 그림에서 **선두가 `RequestPending`이면 중단**, 대기 상태가 아니면 대기 버퍼가 없음을 단언하고 큐에서 빼 `requestCompleted`를 발신한 뒤 다음 선두를 검사합니다. 따라서 핸들러의 완료 호출은 순서가 달라도 앱으로의 반환은 제출 순서이며, 앞 요청이 대기 중이면 뒤의 완료 요청도 기다립니다. 반환 반복 후에는 대기 요청의 장치 전달을 다시 시도합니다. ([제출 큐의 선두 상태와 반환 순서](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#제출-큐의-선두-상태와-반환-순서), [request.cpp:118](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/request.cpp#L118), [pipeline_handler.cpp:584](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/pipeline_handler.cpp#L584), [camera.cpp:1475](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/camera.cpp#L1475))

3. **완료 후 읽을 수 있는 데이터**

   요청의 `RequestComplete`는 각 프레임 데이터가 성공했다는 판정과 별개입니다. 앱은 각 버퍼의 상태를 확인해야 합니다.

   - `FrameSuccess`: 프레임 데이터와 모든 메타데이터 필드가 유효합니다.
   - `FrameError`: 데이터가 일부 또는 전부 손상·누락됐거나 유효하지 않습니다. `sequence`와 `timestamp`는 유효하지만 다른 필드는 유효하지 않을 수 있습니다.
   - `FrameCancelled`: 프레임 완료 전에 캡처가 중단됐습니다. 데이터와 `status`를 제외한 모든 메타데이터 필드는 유효하지 않습니다.
   - `FrameStartup`: 캡처 자체는 성공했고 다른 메타데이터도 유효하지만, 초기화 단계의 화질 때문에 앱이 프레임을 소비하지 않도록 권고합니다.

   따라서 이 자료의 사용 지침대로 일반적인 프레임 데이터 소비는 `FrameSuccess`일 때 합니다. ([타임아웃 뒤 펜스 회수](https://ttolsun.github.io/libcamera-sdd/camera-requests.html#타임아웃-뒤-펜스-회수), [framebuffer.cpp:40](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/framebuffer.cpp#L40), [request.cpp:112](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/request.cpp#L112))

4. **수명과 재사용 조건**

   `createRequest()`가 돌려준 요청은 앱 소유입니다. `addBuffer()`는 버퍼의 참조를 저장하므로 앱은 적어도 요청 완료 콜백이 호출될 때까지 버퍼를 유효하게 유지해야 합니다. 큐에 전달된 raw 포인터도 소유권이나 수명을 연장하지 않습니다. 완료 핸들러에서 요청을 삭제하거나 상태를 초기화해 재사용할 수 있다는 API 계약은, 별도 수신자나 소비자가 아직 그 객체를 쓰는 상황의 수명 관리까지 대신해 주지는 않습니다. ([요청과 버퍼를 유지할 기간](https://ttolsun.github.io/libcamera-sdd/camera-requests.html#요청과-버퍼를-유지할-기간), [camera.cpp:1254](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/camera.cpp#L1254), [request.cpp:442](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/request.cpp#L442))

   직접 호출되는 수신자는 발신 문맥에서 동기 실행됩니다. 반면 다른 스레드의 `Object`에 대한 `Auto` 연결은 `Queued`를 선택하고, 명시적 `Queued`도 메시지를 게시한 뒤 기다리지 않습니다. 포인터 값은 복사된 소유권이 아니라 그대로 전달됩니다. 수신 실행이 `emit()` 반환 전 시작될 수도 있고 나중에 실행될 수도 있으므로, 소유자는 **각 지연 수신자의 마지막 사용을 추적하고 동기화한 다음** 요청이나 버퍼를 삭제·재사용해야 합니다. 별도의 앱 수신자뿐 아니라 버퍼를 계속 읽거나 쓰는 다른 소비자가 있다면 그 소비자의 마지막 사용도 재사용 전에 끝나야 합니다. `stop()`의 Blocking 호출과 반환만으로 별도 Queued 수신자의 마지막 사용이 끝났다는 보장은 없습니다. ([queued 수신과 해제 시점의 책임](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#queued-수신과-해제-시점의-책임), [stop 반환과 별도 수신의 마지막 사용 확인](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#stop-반환과-별도-수신의-마지막-사용-확인), [object.cpp:264](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/base/object.cpp#L264), [bound_method.cpp:68](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/base/bound_method.cpp#L68))

   같은 요청의 기본 `reuse()`는 상태·컨트롤 등을 초기화하고 버퍼 맵을 비우므로, 다시 제출하기 전에 `addBuffer()`로 버퍼를 붙여야 합니다. 그림의 **`ReuseBuffers` 분기**에서는 기존 버퍼마다 요청 연결을 다시 설정하고 대기 집합에 넣습니다. 이 옵션은 연결된 펜스까지 재사용하지 않으며, API는 펜스를 사용할 때 이 플래그를 피하도록 권고합니다. 신호되지 않은 펜스로 타임아웃되면 펜스가 버퍼에 남으므로 앱이 `releaseFence()`로 회수해야 합니다. 남은 펜스가 있는 버퍼를 `addBuffer()`에 넣으면 `-EEXIST`입니다. ([재사용 버퍼의 요청 연결](https://ttolsun.github.io/libcamera-sdd/camera-requests.html#재사용-버퍼의-요청-연결), [버퍼 재사용과 펜스 권고](https://ttolsun.github.io/libcamera-sdd/camera-requests.html#버퍼-재사용과-펜스-권고), [request.cpp:375](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/request.cpp#L375), [request.cpp:462](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/request.cpp#L462), [request.cpp:475](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/request.cpp#L475), [framebuffer.cpp:432](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/framebuffer.cpp#L432))

문서의 콜백 시점·스레드 및 지연 수신자 마지막 사용 조사는 **검증 계획**입니다. 별도로 문서는 Ubuntu WSL2의 Virtual2 가상 프로브에서 CPU 전용 `memfd` 버퍼와 신호 없는 `eventfd` 입력으로 실제 앱 콜백을 관찰했다고 밝힙니다. 그 반환 근처 표식은 실제 C++ 함수의 반환 완료를 증명하지 않습니다. 이 관측은 DMA 동기화, 물리 카메라·센서·ISP, 다른 앱이나 사내 Camera HAL을 검증하지 않았습니다. 따라서 읽은 자료만으로 특정 플랫폼에서 다른 장치 소비자의 완료를 어떤 펜스나 캐시 동기화로 확인해야 하는지까지 단정할 수 없습니다. ([반환 근처 표시로 알 수 있는 범위](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#반환-근처-표시로-알-수-있는-범위))

TAILS: 1=422e7b4, 2=b28f715, 3=4b55857, 4=107d101, 5=6f0b721, 6=8045828, 7=fe74acd
