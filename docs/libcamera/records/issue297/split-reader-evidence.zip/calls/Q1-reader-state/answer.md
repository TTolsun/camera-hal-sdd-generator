`queueRequest()`가 **0을 반환한 시점은 요청이 접수된 시점**입니다. 촬영이나 요청 전체의 완료를 뜻하지 않습니다. 앱은 이후 `requestCompleted` 알림과 요청 상태를 확인해야 합니다. 버퍼별 완료 알림이 먼저 올 수 있지만, 마지막 버퍼가 완료되어도 핸들러가 요청을 명시적으로 완료해야 합니다.

버퍼를 다시 사용하려면 해당 버퍼의 사용이 끝났는지 확인하고, 요청을 재사용할 경우 상태를 초기화해야 합니다. 또한 별도 지연 수신자나 그 밖의 소비자가 버퍼를 계속 사용한다면 **그 소비자의 마지막 사용까지** 기다려야 합니다. 완료 신호나 `stop()` 반환만으로 모든 별도 소비자의 사용이 끝났다고 단정할 수 없습니다.

**제출부터 완료·반환까지**

1. `Camera::queueRequest()`는 카메라가 `Running` 상태여야 제출을 허용합니다. 요청이 이 카메라에서 만들어졌고 `RequestPending` 상태여야 하며, 유효한 controls와 적어도 하나의 버퍼가 있어야 하고 모든 스트림이 활성 상태여야 합니다. 접근 검사 실패는 그 오류를 반환하고, 다른 카메라의 요청은 `-EXDEV`, 잘못된 상태·controls·버퍼·스트림은 `-EINVAL`입니다. 검사를 통과하면 파이프라인 핸들러 호출을 `ConnectionTypeQueued`로 게시하고 0을 반환합니다. 따라서 성공 반환 뒤에도 준비나 장치 제출은 아직 진행 중일 수 있습니다. [접수·반환과 완료 알림](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#접수-반환과-완료-알림), [camera.cpp:1330](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/camera.cpp#L1330), [camera.cpp:1349](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/camera.cpp#L1349).

2. 핸들러는 요청 준비가 끝나고 장치 큐에 여유가 있을 때 요청을 전달합니다. 준비 실패는 취소로 이어지고, 장치 제출 함수가 0이 아닌 값을 반환해도 요청을 취소합니다. 따라서 최초의 0 반환은 이후 성공적인 프레임을 보장하지 않습니다. 문서의 큐 그림에서 **준비되지 않은 선두 요청** 또는 **장치 큐가 가득 찬 경우**에는 뒤 요청 전달이 중단됩니다. [제출 큐의 선두 상태와 반환 순서](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#제출-큐의-선두-상태와-반환-순서).

3. 핸들러가 CameraManager 스레드에서 `completeBuffer()`를 호출하면 `bufferCompleted` 신호를 내고 내부 대기 집합에서 해당 버퍼를 제거합니다. 그림의 **남은 버퍼가 있으면 `false`**, **마지막 버퍼이면 `true`** 분기가 중요합니다. `true`여도 요청은 자동 완료되지 않습니다. 핸들러는 필요한 후속 작업을 마친 뒤 `completeRequest()`를 명시적으로 호출해야 합니다. [버퍼 완료와 명시적 요청 완료의 경계](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#버퍼-완료와-명시적-요청-완료의-경계), [pipeline_handler.cpp:553](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/pipeline_handler.cpp#L553), [request.cpp:103](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/request.cpp#L103).

4. `completeRequest()`는 남은 버퍼가 없음을 전제로 요청 상태를 정합니다. 취소된 버퍼가 기록됐으면 `RequestCancelled`, 그렇지 않으면 `RequestComplete`입니다. 완료 호출은 요청마다 순서가 달라도 되지만 앱 반환은 제출 순서입니다. 그림에서 큐 선두가 **`RequestPending`이면 `break`**하므로, 그 뒤의 완료된 요청도 기다립니다. 선두가 대기 중이 아니면 꺼내서 `requestComplete()`를 호출하고, 카메라는 `requestCompleted`를 발생시킵니다. [제출 큐의 선두 상태와 반환 순서](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#제출-큐의-선두-상태와-반환-순서), [request.cpp:118](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/request.cpp#L118), [pipeline_handler.cpp:584](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/pipeline_handler.cpp#L584), [camera.cpp:1475](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/camera.cpp#L1475).

**완료된 데이터의 판정**

요청의 `RequestComplete`만으로 모든 프레임이 정상이라고 판단하면 안 됩니다. 요청 상태는 위 구현에서 취소 여부로 정해지므로, 각 버퍼의 `FrameMetadata::status`도 확인해야 합니다.

- `FrameSuccess`: 프레임 데이터와 모든 메타데이터 필드가 유효합니다.
- `FrameError`: 데이터가 일부 또는 전부 손상·누락됐거나 유효하지 않습니다. `sequence`와 `timestamp`는 유효하지만 다른 메타데이터는 유효하지 않을 수 있습니다.
- `FrameCancelled`: 프레임 완료 전에 캡처가 중단됐습니다. 프레임 데이터와 `status` 이외의 메타데이터는 유효하지 않습니다.
- `FrameStartup`: 캡처는 성공했고 다른 메타데이터 필드는 유효하지만, IPA의 초기화 또는 리셋 단계로 이미지 품질이 사용하기에 부적절하므로 소비하지 않도록 권고합니다.

문서는 프레임 데이터 사용을 `FrameSuccess`일 때로 제한합니다. [타임아웃 뒤 펜스 회수](https://ttolsun.github.io/libcamera-sdd/camera-requests.html#타임아웃-뒤-펜스-회수), [framebuffer.cpp:40](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/framebuffer.cpp#L40).

**소유권과 마지막 사용**

`createRequest()`가 반환한 요청은 앱 소유이며, 앱이 삭제할 책임이 있습니다. 계약상 완료 핸들러에서 삭제하거나 `reuse()` 후 다시 사용할 수 있습니다. 다만 `addBuffer()`는 버퍼의 참조를 저장할 뿐이므로 호출자가 적어도 요청 완료 콜백까지 버퍼를 유효하게 유지해야 합니다. 큐에 전달되는 요청 포인터도 소유권이나 수명을 연장하지 않습니다. [요청과 버퍼를 유지할 기간](https://ttolsun.github.io/libcamera-sdd/camera-requests.html#요청과-버퍼를-유지할-기간), [camera.cpp:1254](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/camera.cpp#L1254), [request.cpp:442](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/request.cpp#L442).

직접 수신자는 호출 문맥에서 동기적으로 실행됩니다. 반면 다른 스레드의 `Object` 슬롯에 대한 `Auto` 연결은 `Queued`를 선택하며, 명시적 `Queued`도 메시지를 게시하고 기다리지 않습니다. 포인터는 복사해도 가리키는 객체는 연장되지 않습니다. 수신은 발신 측 `emit()` 반환 전에도 시작될 수 있으므로 반환과 수신의 일반적인 선후 관계는 보장되지 않습니다. 별도 지연 수신자가 있다면 요청 소유자는 **각 수신자의 마지막 사용을 추적하고 동기화한 후** 요청이나 버퍼를 삭제하거나 재사용해야 합니다. 수신 객체가 유효하고 해당 스레드가 메시지를 소비하는지도 필요합니다. [queued 수신과 해제 시점의 책임](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#queued-수신과-해제-시점의-책임), [object.cpp:264](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/base/object.cpp#L264), [bound_method.cpp:68](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/base/bound_method.cpp#L68).

마찬가지로 별도 앱 수신자 외에 버퍼를 계속 사용하는 소비자가 있다면, 재사용 판단에는 그 소비자의 마지막 사용도 포함해야 합니다. `stop()`의 실행 중 경로는 핸들러 정지를 Blocking으로 호출하고 pending 요청이 없음을 단언한 뒤 반환하지만, 문서의 그림은 **stop 반환과 별도 Queued 수신자의 마지막 사용 사이의 순서는 보장되지 않는다**고 구분합니다. 카메라 상태 변경을 함께 수행하는 호출자의 동기화도 필요합니다. [stop 반환과 별도 수신의 마지막 사용 확인](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#stop-반환과-별도-수신의-마지막-사용-확인).

**재사용과 펜스**

다음 제출 전에 `reuse()`는 공통으로 요청 상태를 **`RequestPending`**으로 설정하고 controls와 요청 메타데이터를 지웁니다. 실제 분기와 상태 대입은 [request.cpp:385–403](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/request.cpp#L385)에서 확인됩니다.

- 기본 `reuse()`는 `bufferMap_.clear()`로 기존 버퍼 맵을 비웁니다. 다시 제출하기 전에 `addBuffer()`로 버퍼를 붙여야 합니다. 빈 버퍼 맵은 제출 검사에서 거부됩니다.
- `reuse(Request::ReuseBuffers)`는 기존 버퍼 맵을 유지하고, 맵의 각 버퍼에 요청을 다시 연결한 뒤 `pending_`에 넣습니다. 두 분기는 이후 같은 `status_ = RequestPending` 대입에 도달합니다. [재사용 버퍼의 요청 연결](https://ttolsun.github.io/libcamera-sdd/camera-requests.html#재사용-버퍼의-요청-연결).

`ReuseBuffers`는 버퍼를 재사용하지만 연결된 펜스까지 재사용하는 옵션은 아닙니다. 문서는 펜스를 쓸 때 이 플래그를 피하도록 권고합니다. 펜스가 신호되지 않아 요청이 타임아웃되면 버퍼에 펜스가 남으므로, 재사용 전에 `releaseFence()`로 회수해야 합니다. 같은 요청의 `ReuseBuffers` 경로에서도 회수해야 합니다. `addBuffer()` 구현은 여전히 펜스를 참조하는 버퍼를 `-EEXIST`로 거부합니다. [버퍼 재사용과 펜스 권고](https://ttolsun.github.io/libcamera-sdd/camera-requests.html#버퍼-재사용과-펜스-권고), [request.cpp:462](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/request.cpp#L462), [request.cpp:475](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/request.cpp#L475), [framebuffer.cpp:432](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/framebuffer.cpp#L432).

**확인 범위**

위 내용은 공개 문서의 계약과 이번에 읽은 고정 소스 구현에 근거합니다. 별도 수신자의 마지막 사용과 실제 콜백 스레드 등을 기록하는 내용은 문서의 **검증 계획**이지 그 자체로 실행 결과가 아닙니다. 문서는 별도로 WSL2의 Virtual2 가상 프로브에서 CPU 전용 버퍼 등을 사용한 콜백 관측을 설명하지만, DMA 동기화, 물리 카메라·센서·ISP, 다른 앱과 사내 Camera HAL은 검증하지 않았습니다. 따라서 이 자료만으로 특정 플랫폼의 DMA 동기화나 다른 소비자의 완료를 보장하는 구체적인 동기화 방법·범위를 확정할 수 없습니다. [반환 근처 표시로 알 수 있는 범위](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#반환-근처-표시로-알-수-있는-범위).

TAILS: 1=422e7b4, 2=b28f715, 3=4b55857, 4=107d101, 5=6f0b721, 6=8045828, 7=fe74acd
