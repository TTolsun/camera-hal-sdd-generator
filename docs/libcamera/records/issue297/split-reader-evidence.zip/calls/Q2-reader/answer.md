가장 먼저 **같은 제출 회차를 식별해 `Camera::queueRequest()`의 시작과 반환, 메시지 게시, `PipelineHandler::queueRequest()` 진입을 연결**하겠습니다. 반환값 `0`은 검증을 통과해 파이프라인 호출을 게시했다는 관측값입니다. 파이프라인이 호출을 받았거나 장치가 촬영을 마쳤다는 뜻은 아닙니다. 이후에는 요청이 마지막으로 확인된 경계부터 아래 순서로 좁혀 갑니다.

1. **앱 API 진입 → 파이프라인 수신**

   앱에서 호출마다 회차 표식을 만들고, 그 표식으로 API 시작, 반환값, 게시, 파이프라인 진입을 기록합니다. 같은 `Request` 주소는 재사용될 수 있고, 소프트웨어 `sequence_`는 파이프라인의 더 뒤 단계에서야 부여되므로 진입 전의 회차 표식을 대신하지 못합니다.

   - 반환이 **음수**이면 게시 이후를 조사하기 전에 API 검증을 봅니다. 문서는 접근 상태, 다른 카메라의 요청, 요청 상태, controls, 버퍼와 활성 스트림을 확인하도록 설명합니다. API 주석의 `-ENOMEM` 반환 계약과 함수 본문에 이를 직접 반환하는 분기가 없는 점도 구분합니다. 근거: [제출 큐의 선두 상태와 반환 순서](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#제출-큐의-선두-상태와-반환-순서).
   - 반환이 **0인데 파이프라인 진입이 없으면** 메시지 게시와 소비를 확인합니다. `Camera::queueRequest()`는 `ConnectionTypeQueued` 호출을 게시하고 0을 반환합니다. `Thread::postMessage()`는 mutex 안에서 목록에 추가합니다. 여러 스레드의 API 호출 **시작 순서**가 게시 순서를 결정하지는 않습니다. 게시된 호출이 스레드 정지 전에 반드시 실행된다는 보장도 없습니다. 근거: [동시 제출의 순서를 관찰할 경계](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#동시-제출의-순서를-관찰할-경계), [camera.cpp:1376](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/camera.cpp#L1376), [thread.cpp:558](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/base/thread.cpp#L558), [thread.cpp:625](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/base/thread.cpp#L625).
   - **진입이 있으면** 같은 요청이 `waitingRequests_`에 들어갔는지 확인하고 준비 단계로 이동합니다. 구현은 삽입 후 `prepare(300ms)`를 호출합니다. [pipeline_handler.cpp:469](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/pipeline_handler.cpp#L469).

2. **준비 → 전달 가능 여부**

   `waitingRequests_`의 **선두**, 그 요청의 `prepared_`와 `cancelled_`, 남은 fence, 그리고 `queuedRequests_` 크기와 `maxQueuedRequestsDevice_`를 함께 봅니다. `registerRequest()`가 준비 신호를 연결하고, 준비 신호가 전달 반복을 다시 시도하게 합니다.

   [선두 요청을 전달하거나 반복을 멈추는 조건](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#선두-요청을-전달하거나-반복을-멈추는-조건) 그림에서 사용하는 분기는 다음과 같습니다.

   - 대기 큐가 비었으면 이번 전달 반복을 종료합니다.
   - 대기 항목이 있고 `queuedRequests_.size() == maxQueuedRequestsDevice_`이면 `break`합니다. 장치에 이미 등록된 요청과 그 완료를 먼저 조사합니다.
   - 한도에 걸리지 않았지만 **선두의 `prepared_ == false`**이면 `break`합니다. 뒤 요청이 준비됐더라도 선두의 fence와 타이머를 조사합니다.
   - 선두가 준비됐으면 먼저 `pop()`한 후 `doQueueRequest()`를 호출하고 반복 조건을 다시 검사합니다. 먼저 제거하는 이유는 완료·취소 중 전달 반복이 재귀 호출될 수 있기 때문입니다. 근거: [pipeline_handler.cpp:509](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/pipeline_handler.cpp#L509).

   fence가 없으면 준비 완료가 동기적으로 발행됩니다. fence가 있으면 notifier를 기다립니다. 각 fence의 fd와 `revents`, `notifierActivated()`와 `timeout()`의 진입 순서, 남은 notifier, 타이머 등록, `prepared_`와 `cancelled_`를 기록합니다. 마지막 fence가 신호되면 fence를 꺼내고 notifier를 제거한 뒤 타이머를 소멸시키고 준비 완료를 발행합니다. timeout이면 남은 notifier를 지우고 요청을 취소한 뒤에도 준비 완료를 발행합니다. **따라서 `prepared_ == true`만으로 준비 성공이나 촬영 성공을 판정할 수 없습니다.** 미신호 fence는 버퍼에 남으므로 재사용 전에 `FrameBuffer::releaseFence()`로 꺼내야 합니다. 근거: [같은 poll 회차의 fence와 타이머 처리](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#같은-poll-회차의-fence와-타이머-처리), [request.cpp:192](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/request.cpp#L192), [request.cpp:239](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/request.cpp#L239), [request.cpp:275](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/request.cpp#L275).

   특히 위 poll 그림의 분기는 `ret > 0`일 때 **notifier 처리 후 timer 처리**입니다. 같은 회차에 fence 이벤트와 만료가 모두 관측되어도, 마지막 notifier가 먼저 제거되면서 타이머가 등록 해제되면 timeout이 먼저 실행됐다고 결론 낼 수 없습니다. 다른 fence가 남고 타이머가 등록된 채 만료됐다면 뒤이어 timeout이 실행될 수 있습니다. 이는 선택된 dispatcher의 처리 경로이며, 실제 실행 순서는 계측으로 확인해야 합니다.

3. **장치 전달과 즉시 실패**

   `doQueueRequest()`에 도달하면 요청이 `queuedRequests_`에 추가되고 소프트웨어 `sequence_`가 부여됩니다. 이 sequence를 장치의 `FrameMetadata::sequence`와 같다고 가정하지 않습니다. 출력 버퍼 여부와 첫 프레임 보정 조건도 함께 확인합니다.

   [void 전달 함수의 두 취소 경로](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#void-전달-함수의-두-취소-경로) 그림의 분기는 다음과 같습니다.

   - 이미 `cancelled_ == true`이면 장치 함수를 호출하지 않고 `completeRequest()`로 갑니다.
   - 그렇지 않으면 `queueRequestDevice()`를 호출합니다. 반환이 **0이 아니면** `cancelRequest()`로 갑니다.
   - 반환이 **0이면** `doQueueRequest()`는 끝납니다. 함수 자체는 `void`이고, 0은 이후의 장치 완료 이벤트까지 보장하지 않습니다.

   근거: [pipeline_handler.cpp:483](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/pipeline_handler.cpp#L483).

   문서가 구체적으로 연 **UVC 구현**에서는 스트림 버퍼를 찾지 못하면 `-ENOENT`, 제어 처리나 `queueBuffer()`가 음수이면 그 오류를 반환합니다. 제어 처리는 버퍼 제출보다 먼저이며, `processControls()`의 0은 요청한 모든 개별 제어가 적용됐다는 증거가 아닙니다. 이후 버퍼 제출이 실패해도 제어 롤백은 보장되지 않습니다. 근거: [UVC의 장치 제출과 완료를 추적하기 그림](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#uvc의-장치-제출과-완료를-추적하기-그림), [uvcvideo.cpp:448](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/pipeline/uvcvideo/uvcvideo.cpp#L448).

   `queueBuffer()`까지 갔다면 기존 호출의 반환값과 QBUF 도달 여부를 봅니다.

   - `Stopping`이면 `-ESHUTDOWN`입니다. cache 자체가 없으면 Fatal 경계이므로 뒤의 음수 반환이나 취소까지 정상적으로 도달한다고 단정하지 않습니다.
   - cache 항목을 얻지 못하면 `-ENOENT`로, 아직 index와 guard가 없고 이번 버퍼는 QBUF나 `queuedBuffers_` 등록에 도달하지 않습니다.
   - index를 얻은 뒤 plane 수가 장치 형식보다 적거나, 수가 다르면서 비연속이면 `-EINVAL`입니다. 이때 guard가 index를 cache에 반환합니다. 다른 사전 검증도 실패할 수 있습니다.
   - `VIDIOC_QBUF`가 음수여도 guard가 index를 반환하고 이번 버퍼를 새로 등록하지 않습니다. QBUF가 성공하면 index로 `queuedBuffers_`에 등록하고 guard를 해제합니다. **등록은 하드웨어 완료나 즉시 알림의 증거가 아닙니다.**

   근거: [QBUF 호출 전 실패와 cache 반환](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#qbuf-호출-전-실패와-cache-반환), [v4l2_videodevice.cpp:1669](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/v4l2_videodevice.cpp#L1669), [v4l2_videodevice.cpp:1723](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/v4l2_videodevice.cpp#L1723), [v4l2_videodevice.cpp:1785](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/v4l2_videodevice.cpp#L1785).

4. **장치 반환 → 버퍼 완료**

   QBUF 성공과 등록이 확인됐다면 별도의 장치 이벤트, `bufferAvailable()`, `VIDIOC_DQBUF` 반환값과 index, `bufferReady` 발생을 차례로 확인합니다.

   [UVC 그림](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#uvc의-장치-제출과-완료를-추적하기-그림)에서 DQBUF가 성공하고 등록된 버퍼를 찾는 **`!buffer == false`** 분기는 `bufferReady`와 연결된 UVC `imageBufferReady()`로 이어집니다. DQBUF 오류나 예상 밖 index는 `nullptr`로 돌아가며 `bufferAvailable()`은 `bufferReady`를 발행하지 않습니다. 예상 밖 index에 관한 코드 주석은 과거 커널 문제의 가능성을 설명하지만, 해당 증상만으로 그 원인을 확정할 수는 없습니다. 근거: [v4l2_videodevice.cpp:1814](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/v4l2_videodevice.cpp#L1814), [v4l2_videodevice.cpp:1848](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/v4l2_videodevice.cpp#L1848).

   UVC의 `imageBufferReady()`는 버퍼 timestamp를 요청의 `SensorTimestamp`에 기록하고 `completeBuffer()` 다음에 `completeRequest()`를 호출합니다. [uvcvideo.cpp:893](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/pipeline/uvcvideo/uvcvideo.cpp#L893).

   반환된 프레임의 상태도 별도로 봅니다. 문서상 `FrameError`는 데이터가 손상되었거나 없거나 유효하지 않을 수 있지만 sequence와 timestamp는 유효합니다. `FrameCancelled`는 완료 전 중단을 뜻하며 status 이외의 메타데이터와 데이터는 유효하지 않습니다. 캡처 plane 검사나 V4L2 오류 플래그로 `FrameError`가 될 수도 있습니다. 요청의 완료 상태는 별도로 `cancelled_`에 따라 정해지므로, **요청 완료 통지와 프레임 성공을 같은 관측값으로 취급하지 않습니다.** 근거: [QBUF 호출 전 실패와 cache 반환](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#qbuf-호출-전-실패와-cache-반환).

5. **공통 완료 → 순서 대기**

   [버퍼 완료와 명시적 요청 완료의 경계](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#버퍼-완료와-명시적-요청-완료의-경계) 그림에서 `completeBuffer()`가 **false**이면 남은 버퍼를 추적합니다. **true**이면 마지막 버퍼가 완료된 것이지만 요청이 자동 완료되는 것은 아니므로, 핸들러가 필요한 후속 작업을 마친 뒤 `completeRequest()`를 명시적으로 호출하는지 확인합니다. 이 함수들은 문서 계약상 CameraManager 스레드에서 호출합니다. 근거: [pipeline_handler.cpp:553](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/pipeline_handler.cpp#L553).

   `completeRequest()`가 호출됐는데 앱에 통지가 없다면 현재 요청뿐 아니라 **`queuedRequests_` 선두의 상태와 pending 버퍼**를 확인합니다. [제출 큐의 선두 상태와 반환 순서](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#제출-큐의-선두-상태와-반환-순서) 그림에서:

   - 큐가 비지 않았고 선두가 `RequestPending`이면 **break**합니다. 뒤 요청이 이미 완료됐어도 선두 요청의 장치 반환과 완료를 먼저 조사합니다.
   - 선두가 Pending이 아니면 pending 버퍼가 없다는 assertion 위치를 거쳐 선두를 제거하고 `Camera::requestComplete()`를 호출한 뒤 다음 선두를 검사합니다.
   - 반복이 끝나면 `doQueueRequests()`를 다시 호출해 대기 요청의 전달을 시도합니다.

   핸들러는 요청을 순서에 관계없이 완료할 수 있지만 앱에는 제출 순서대로 반환된다는 문서 계약과 위 구현이 연결됩니다. 완료 함수 반환 후 핸들러가 요청에 접근해서는 안 된다는 계약도 확인합니다. [pipeline_handler.cpp:584](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/pipeline_handler.cpp#L584).

6. **카메라 신호 → 특정 앱 수신자**

   `Camera::requestComplete()` 진입, 카메라 상태 검사, `requestCompleted` 발행, 관심 있는 **각 연결의 콜백 진입과 복귀**를 별도로 기록합니다. 신호 발행과 특정 콜백 관찰은 다른 경계이며, 여러 수신 연결을 여러 번의 요청 완료로 세지 않습니다.

   연결이 `Auto`인 Object 슬롯은 같은 스레드면 Direct, 다른 스레드면 Queued를 선택합니다. Queued는 메시지를 게시하고 수신 완료를 기다리지 않으며, 수신이 `emit()` 반환 전에 시작될 수도 있습니다. 따라서 신호는 발행됐지만 특정 콜백이 없다면 연결 방식, 수신 스레드의 메시지 전달과 객체 수명을 확인합니다. 버퍼는 적어도 요청 완료 콜백까지 유효해야 하고, 별도의 Queued 수신자가 더 오래 사용한다면 그 마지막 사용까지의 수명과 동기화를 따로 확인해야 합니다. 근거: [queued 수신과 해제 시점의 책임](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#queued-수신과-해제-시점의-책임), [bound_method.cpp:68](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/base/bound_method.cpp#L68), [camera.cpp:1481](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/camera.cpp#L1481).

정지와 겹친 경우에는 위 경계들의 시간 순서를 추가로 확인합니다. 호출 게시와 실행, `CameraStopping` 설정, 대기 큐 분리, `stopDevice()`, 준비와 장치 제출, 완료 시 상태 검사를 기록합니다. 문서는 `stop()`과 다른 상태 변경 함수의 동기화를 호출자 책임으로 설명합니다. 게시된 호출이 대기 큐 분리 뒤 실행되고 완료가 이미 `CameraConfigured`인 상태에서 도착하면, 연결 해제를 허용하는 인자에도 상태 범위 검사는 유지되어 Fatal 로그 경계에 도달할 수 있습니다. 근거: [같은 poll 회차의 fence와 타이머 처리](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#같은-poll-회차의-fence와-타이머-처리), [camera.cpp:1481](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/camera.cpp#L1481).

여기서 제시한 시간 기록, 스레드 ID 비교, fence와 장치 반환값 확인은 **문서의 검증 계획**입니다. 실제 카메라에서 관측한 결과가 아닙니다. 읽은 고정 소스는 공통 경로와 위 UVC/V4L2 경로를 뒷받침하지만, 다른 파이프라인 구현이나 특정 장치·드라이버가 실제로 이벤트를 반환했는지까지 확인하지는 못했습니다.

TAILS: 1=8915e74, 2=220060f, 3=3e95902, 4=99686a9, 5=1d77ae8, 6=4b55857, 7=8878bf8, 8=f51a931, 9=1a33c70, 10=5974778
