from hashlib import sha256
import json
from pathlib import Path
import re
import zipfile


root = Path(__file__).resolve().parent
records = Path('docs/libcamera/records/issue297')
items = {name:(root/name).read_bytes() for name in (
    'progress.md','reader.py','routes.py','call.py','prompts.py','prepare-judge.py','package.py','write-record.py',
    'verify-pages.py','expected-manifest.json','verified-pages.json')}
items['requirements.txt'] = b'beautifulsoup4==4.15.0\n'
receipts = []
verdicts = []
required = {'Q1-reader-complete-judge','Q2-reader-judge','Q3-reader-complete-judge'}
for folder in sorted((root/'calls').iterdir()):
    if not folder.is_dir():
        continue
    name = folder.name
    for leaf in ('answer.md','receipt.json','navigation.jsonl','stdout.jsonl','delivery-proof.json','stderr.log'):
        file = folder/leaf
        if not file.exists():
            continue
        raw = file.read_bytes()
        if leaf == 'receipt.json':
            result = json.loads(raw)
            result['argv'] = ['codex',*[re.sub(r'[A-Z]:[\\/][^"\']*?python\.exe','<python>',arg)
                                     .replace(str(root),'<work>').replace(str(root).replace('\\','\\\\'),'<work>')
                                     for arg in result['argv'][1:]]]
            raw = (json.dumps(result,ensure_ascii=False,indent=2)+'\n').encode()
            receipts.append(result)
        if leaf == 'answer.md' and name.endswith('-judge'):
            text = raw.decode('utf-8').strip()
            verdict = json.loads(re.sub(r'^```(?:json)?\s*|\s*```$', '', text))
            assert verdict['question'] == name.split('-')[0] and len(verdict['ratings']) == 6
            assert verdict['pass'] == all(row in {'충족','해당 없음'} for row in verdict['ratings'])
            verdicts.append({'call':name, **verdict})
        assert not re.search(rb'c:\\+users\\+baboe',raw,re.I), (name,leaf)
        items[f'calls/{name}/{leaf}'] = raw
    prompt = root/'prompts'/f'{name}.txt'
    if prompt.exists():
        items[f'prompts/{name}.txt'] = prompt.read_bytes()

total = sum(usage['input_tokens']+usage['output_tokens'] for receipt in receipts if (usage:=receipt.get('usage')))
result = {'calls':len(receipts),'measured_total_tokens':total,'verdicts':verdicts}
assert required <= {item['call'] for item in verdicts}
items['summary.json'] = (json.dumps(result,ensure_ascii=False,indent=2)+'\n').encode()
items['SHA256SUMS.json'] = (json.dumps({name:sha256(raw).hexdigest() for name,raw in items.items()},indent=2)+'\n').encode()
out = records/'split-reader-evidence.zip'
with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as bundle:
    for name,raw in sorted(items.items()):
        entry = zipfile.ZipInfo(name)
        entry.compress_type = zipfile.ZIP_DEFLATED
        bundle.writestr(entry,raw)
with zipfile.ZipFile(out) as bundle:
    assert bundle.testzip() is None
(root/'summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(out, out.stat().st_size, sha256(out.read_bytes()).hexdigest(), len(items), total)
