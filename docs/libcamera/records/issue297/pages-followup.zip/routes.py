"""Public document routes with line windows reached via actual links."""

LIFE = 'request-lifecycle.html#'
CAM = 'camera-requests.html#'
STOP = 'scenarios/camera_stop.html#'
ROUTES = {
    'Q1': (
        ([LIFE+'접수-반환과-완료-알림', LIFE+'버퍼-완료와-명시적-요청-완료의-경계',
          LIFE+'제출-큐의-선두-상태와-반환-순서'],
         {'camera.cpp': [(1369,1380),(1475,1489)],'pipeline_handler.cpp':[(553,568),(584,603)],'request.cpp':[(111,125)]}),
        ([CAM+'요청과-버퍼를-유지할-기간', CAM+'재사용-버퍼의-요청-연결', CAM+'버퍼-재사용과-펜스-권고',
          CAM+'타임아웃-뒤-펜스-회수', LIFE+'qbuf-호출-전-실패와-cache-반환', LIFE+'queued-수신과-해제-시점의-책임',
          LIFE+'stop-반환과-별도-수신의-마지막-사용-확인'],
         {'camera.cpp':[(1249,1263)],'request.cpp':[(375,403),(442,449),(462,465),(475,493)],
          'framebuffer.cpp':[(38,58),(432,449)],'base/object.cpp':[(260,273)],'base/bound_method.cpp':[(68,102)]}),
    ),
    'Q2': (
        ([LIFE+'동시-제출의-순서를-관찰할-경계', LIFE+'선두-요청을-전달하거나-반복을-멈추는-조건',
          LIFE+'같은-poll-회차의-fence와-타이머-처리', LIFE+'void-전달-함수의-두-취소-경로'],
         {'camera.cpp':[(1369,1380)],'pipeline_handler.cpp':[(469,480),(483,502),(509,526)],
          'request.cpp':[(192,226),(253,269)],'base/thread.cpp':[(558,576),(625,654)]}),
        ([LIFE+'uvc의-장치-제출과-완료를-추적하기-그림', LIFE+'qbuf-호출-전-실패와-cache-반환'],
         {'pipeline/uvcvideo/uvcvideo.cpp':[(448,466),(893,904)],
          'v4l2_videodevice.cpp':[(1669,1702),(1723,1743),(1814,1835),(1848,1874)]}),
        ([LIFE+'버퍼-완료와-명시적-요청-완료의-경계', LIFE+'제출-큐의-선두-상태와-반환-순서',
          LIFE+'queued-수신과-해제-시점의-책임'],
         {'pipeline_handler.cpp':[(553,568),(584,603)],'base/bound_method.cpp':[(68,102)],'camera.cpp':[(1475,1489)]}),
    ),
    'Q3': (
        ([LIFE+'camerastop의-미실행오류정상-경로', STOP+'파이프라인-정지와-대기-요청-취소',
          STOP+'버퍼별-취소-통지와-내부-정리', LIFE+'제출-큐의-선두-상태와-반환-순서'],
         {'camera.cpp':[(1431,1445),(1453,1472)],'pipeline_handler.cpp':[(368,394),(395,402),(584,603)],
          'request.cpp':[(139,164)]}),
        ([LIFE+'uvc-정지의-정상-경로와-실패-경계-그림', LIFE+'정지-api-계약과-연결-해제-todo'],
         {'pipeline/uvcvideo/uvcvideo.cpp':[(318,330)],'v4l2_videodevice.cpp':[(2009,2018),(2023,2055)]}),
        ([LIFE+'직접-중첩-호출과-별도-queued-수신의-경계', LIFE+'stop-반환과-별도-수신의-마지막-사용-확인',
          LIFE+'동시-제출정지지연-수신의-검증-위치'],
         {'base/bound_method.cpp':[(68,102)],'camera.cpp':[(1475,1489)],'request.cpp':[(442,449)]}),
    ),
}
