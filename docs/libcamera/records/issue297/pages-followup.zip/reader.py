"""Read a pinned public SDD and follow its real, discovered GitHub links."""
import hashlib
import json
import re
import sys
from pathlib import Path
from urllib.parse import unquote, urljoin, urlsplit
from urllib.request import Request, urlopen

sys.path.insert(0, str(Path(__file__).with_name('deps')))
from bs4 import BeautifulSoup
from routes import ROUTES

site, journal = map(Path, sys.argv[1:])
manifest = json.loads((site / 'site-manifest.json').read_bytes())
origin = 'https://ttolsun.github.io/libcamera-sdd/'
source = 'https://github.com/TTolsun/libcamera-sdd/blob/'
source_sha = json.loads((site / 'item-visual-audit.json').read_bytes())['source_commit']
source_pattern = re.compile(re.escape(source + source_sha) + r'/([A-Za-z0-9_./-]+)#L(\d+)(?:-L(\d+))?$')
headings = re.compile(r'^h[1-4]$')
documents = {}
known = {}
remote_code = {}
http_proof = {}
caption_sources = set()

def record(**event):
    with journal.open('a', encoding='utf-8') as stream:
        stream.write(json.dumps(event, ensure_ascii=False) + '\n')

def label(tag):
    return re.sub(r'\s+', ' ', tag.get_text(' ', strip=True)).strip()

for relative, expected in manifest['outputs'].items():
    if not relative.endswith('.html') or relative.startswith('en/'):
        continue
    raw = (site / relative).read_bytes()
    if hashlib.sha256(raw).hexdigest() != expected:
        raise ValueError('Manifest mismatch: ' + relative)
    soup = BeautifulSoup(raw, 'html.parser')
    main = soup.select_one('main')
    if not main:
        continue
    article = main.select_one('article') or main
    title = label(main.select_one('h1') or soup.title)
    sections = [{'title': title, 'anchor': '', 'level': 1, 'body': [], 'links': []}]
    for node in article.find_all(recursive=False):
        if headings.fullmatch(node.name) and node.get('id'):
            sections.append({'title': label(node), 'anchor': node['id'],
                             'level': int(node.name[1]), 'body': [], 'links': []})
            continue
        section = sections[-1]
        for link in node.select('a[href]'):
            dest = unquote(urljoin(origin + relative, link['href']))
            if link.get('data-sdd-caption-source') == 'true':
                caption_sources.add((relative, section['anchor'], dest))
            if source_pattern.fullmatch(dest) or (dest.startswith(origin) and '.html' in dest):
                section['links'].append((label(link), dest))
        for target in [node, *node.select('[data-sdd-evidence]')]:
            for description, markup in json.loads(target.get('data-sdd-evidence', '[]')):
                code_link = BeautifulSoup(markup, 'html.parser').find('a', href=True)
                if code_link and source_pattern.fullmatch(code_link['href']):
                    section['links'].append((description, code_link['href']))
        if node.name == 'pre' and 'mermaid' in node.get('class', []):
            section['body'].append('\n'.join(line for line in node.get_text().splitlines()
                                             if not line.startswith('%%')))
        elif node.name not in {'details', 'div', 'script', 'pre'}:
            text = label(node)
            if text and text != 'Mermaid 원문':
                section['body'].append(text)
    documents[relative] = sections

def find(terms):
    terms = [term.casefold() for term in terms if term.strip()]
    scored = []
    for page, sections in documents.items():
        for section in sections:
            key = page + ('#' + section['anchor'] if section['anchor'] else '')
            body = ' '.join(section['body']).casefold()
            title = section['title'].casefold()
            rank = sum(5 * (term in title) + min(body.count(term), 3) for term in terms)
            if rank:
                scored.append((rank, key, section['title']))
    result = [{'section': key, 'title': title} for _, key, title in sorted(scored, reverse=True)[:13]]
    record(event='search', terms=terms, matches=[row['section'] for row in result])
    return result

def read(sections):
    result = []
    for key in sections[:4]:
        key = unquote(key.removeprefix(origin))
        relative, _, anchor = key.partition('#')
        matches = documents.get(relative, [])
        section = next((item for item in matches if item['anchor'] == anchor), None)
        if section is None:
            raise ValueError('Unknown section: ' + key)
        url = origin + key
        presented = []
        all_links = {dest: description for description, dest in reversed(section['links'])}
        for dest, description in sorted(all_links.items(), key=lambda pair: (relative, anchor, pair[0]) not in caption_sources):
            if source_pattern.fullmatch(dest):
                identity = hashlib.sha256((key + '|' + dest).encode()).hexdigest()[:12]
                known[identity] = (url, dest)
                file, line, _ = source_pattern.fullmatch(dest).groups()
                presented.append({'id': identity, 'label': description[:100], 'code_location': f'{file}:{line}'})
            else:
                presented.append({'label': description, 'href': dest})
        index = matches.index(section)
        related = []
        for other in matches[max(index - 2, 0):index + 4]:
            if other is not section:
                related.append({'section': relative + ('#' + other['anchor'] if other['anchor'] else ''),
                                'title': other['title']})
        result.append({'url': url, 'title': section['title'], 'text': '\n\n'.join(section['body']),
                       'links': presented, 'nearby_sections': related})
    delivered = bounded(result, sections)
    for item in delivered['results']:
        record(event='read', url=item['url'], links=item['links'])
    return delivered


def bounded(results, requested):
    selected = []
    for result in results:
        if selected and len(json.dumps(selected + [result], ensure_ascii=False)) > 8500:
            break
        selected.append(result)
    return {'results': selected, 'continue_with': requested[len(selected):]}


def route(question, part):
    anchors, windows = ROUTES[question][part-1]
    docs = []
    for key in anchors:
        item, = read([key])['results']
        docs.append({key: item[key] for key in ('url','title','text')})
    visited = {item['url'] for item in docs}
    code = []
    for name, ranges in windows.items():
        filename = 'src/libcamera/'+name
        for start,end in ranges:
            candidates = []
            for identity,(parent,href) in known.items():
                path, anchor, _ = source_pattern.fullmatch(href).groups()
                if path == filename and parent in visited:
                    row = int(anchor)
                    candidates.append((not start <= row <= end, abs(row-start), identity))
            if not candidates:
                record(event='error',tool='route',path=filename,start=start,end=end,error='No source link in the opened route sections')
                continue
            identity = min(candidates)[-1]
            query = {'id':identity,'start':start,'end':end}
            while query:
                view, = follow([query])['results']
                query = view.pop('next',None)
                code.append(view)
    return {'documents':docs, 'linked_code':code}


def read_public_routes():
    docs, code, paths = {}, {}, {}
    for question, parts in ROUTES.items():
        paths[question] = {'documents':[], 'linked_code':[]}
        for part in range(1,len(parts)+1):
            current = route(question, part)
            for item in current['documents']:
                identifier = item['url']
                docs[identifier] = item
                paths[question]['documents'].append(identifier)
            for item in current['linked_code']:
                identifier = f"{item['path']}:{item['start']}-{item['end']}"
                code.setdefault(identifier,item)
                paths[question]['linked_code'].append(identifier)
    return {'routes':paths, 'documents':docs, 'linked_code':code}


def read_independent_routes():
    evidence = read_public_routes()
    seen_documents = set()
    seen_code = set()
    groups = []
    for question, ids in evidence['routes'].items():
        docs = {ident: evidence['documents'][ident]['text'] for ident in ids['documents']
                if ident not in seen_documents}
        code = {ident: evidence['linked_code'][ident]['code'] for ident in ids['linked_code']
                if ident not in seen_code}
        proof = {ident: [evidence['linked_code'][ident][key] for key in ('href','raw_sha256')]
                 for ident in ids['linked_code'] if ident not in seen_code}
        groups.append(dict(question=question, pages=docs, sources=code, links=proof,
                           shared_pages=[ident for ident in ids['documents'] if ident in seen_documents],
                           shared_sources=[ident for ident in ids['linked_code'] if ident in seen_code],
                           end_of_route=f'END {question}'))
        seen_documents.update(ids['documents'])
        seen_code.update(ids['linked_code'])
    return groups

def download(url):
    request = Request(url, headers={'User-Agent': 'SDD-Reader-Evaluation/1.0'})
    return urlopen(request, timeout=18)

def follow(links):
    output = []
    for item in links[:5]:
        identity = item['id']
        if identity not in known:
            raise ValueError('Read a document section to discover this code link first.')
        from_url, dest = known[identity]
        filename, base, _ = source_pattern.fullmatch(dest).groups()
        if '..' in Path(filename).parts:
            raise ValueError('Invalid path')
        base = int(base)
        start = item.get('start', max(1, base - 4))
        end = item.get('end', start + 24)
        if not 0 < start <= end:
            raise ValueError('Invalid line interval')
        requested_end = end
        end = min(end, start + 33)
        if dest not in http_proof:
            with download(dest) as response:
                if response.status != 200 or urlsplit(response.url).hostname != 'github.com':
                    raise ValueError('GitHub code link did not resolve')
                http_proof[dest] = response.status
        if filename not in remote_code:
            raw_url = f'https://raw.githubusercontent.com/TTolsun/libcamera-sdd/{source_sha}/{filename}'
            with download(raw_url) as response:
                if response.status != 200 or urlsplit(response.url).hostname != 'raw.githubusercontent.com':
                    raise ValueError('Pinned raw code did not resolve')
                raw = response.read()
            remote_code[filename] = (raw.decode('utf-8').splitlines(), hashlib.sha256(raw).hexdigest())
        lines, digest = remote_code[filename]
        end = min(end, len(lines))
        if end < start:
            raise ValueError('Requested lines are outside the linked file')
        proof = {'from': from_url, 'href': dest, 'github_http': http_proof[dest],
                 'path': filename, 'start': start, 'end': end, 'raw_sha256': digest}
        output.append({**proof, 'code': '\n'.join(f'{n}: {lines[n-1]}' for n in range(start, end + 1))})
        if end < min(requested_end, len(lines)):
            output[-1]['next'] = {'id': identity, 'start': end + 1, 'end': requested_end}
    result = bounded(output, links)
    for item in result['results']:
        record(event='follow', **{key: value for key, value in item.items() if key not in {'code', 'next'}})
    return result


def array(items, maximum):
    return {'type': 'array', 'items': items, 'minItems': 1, 'maxItems': maximum}

def schema(key, data):
    return {'type': 'object', 'properties': {key: data}, 'required': [key], 'additionalProperties': False}

string = {'type': 'string'}
tools = [
    {'name':'read_independent_routes','description':'Open the real Pages and pinned code links. Returns three separate content blocks with a complete end marker per question.',
     'inputSchema':{'type':'object','properties':{},'additionalProperties':False}},
    {'name':'read_public_routes','description':'Open the live public document routes for Q1–Q3 and follow their pinned code links. Shared pages and code are returned once.',
     'inputSchema':{'type':'object','properties':{},'additionalProperties':False}},
    {'name': 'route', 'description': 'Open sections on the real public Pages site and follow the source links they provide. Q1 has parts 1–2. Q2 and Q3 have parts 1–3.',
     'inputSchema': {'type': 'object', 'properties': {
         'question': {'type':'string','enum':sorted(ROUTES)}, 'part':{'type':'integer','enum':[1,2,3]}},
         'required':['question','part'], 'additionalProperties':False}},
    {'name': 'find', 'description': 'Search the frozen Korean public SDD by terms and return section IDs.',
     'inputSchema': schema('terms', array(string, 7))},
    {'name': 'read', 'description': 'Read public sections by IDs from find or nearby sections. Returns real source link IDs. Request continue_with in the next call if nonempty.',
     'inputSchema': schema('sections', array(string, 4))},
    {'name': 'follow', 'description': 'Open real GitHub code links from read and read pinned numbered lines. Use start/end to navigate. Use next for additional rows and continue_with for any deferred windows.',
     'inputSchema': schema('links', array({'type': 'object', 'properties': {
         'id': string, 'start': {'type': 'integer'}, 'end': {'type': 'integer'}},
         'required': ['id'], 'additionalProperties': False}, 5))},
]
for tool in tools:
    tool['annotations'] = {'readOnlyHint': True, 'destructiveHint': False, 'openWorldHint': tool['name'] in {'follow','route'}}
handlers = {'find': find, 'read': read, 'follow': follow, 'route': route, 'read_public_routes': read_public_routes,
            'read_independent_routes': read_independent_routes}
for line in sys.stdin.buffer:
    message = json.loads(line)
    if 'id' not in message:
        continue
    method = message.get('method')
    params = message.get('params', {})
    if method == 'initialize':
        result = {'protocolVersion': params.get('protocolVersion','2025-06-18'),
                  'capabilities': {'tools': {}}, 'serverInfo': {'name': 'sdd-reader', 'version': '1.0.0'}}
    elif method == 'tools/list':
        result = {'tools': tools}
    elif method == 'tools/call':
        try:
            value = handlers[params['name']](**params['arguments'])
            payload = value if params['name'] == 'read_independent_routes' else [value]
            result = {'content': [{'type':'text','text':json.dumps(item,ensure_ascii=False,separators=(',',':'))}
                                  for item in payload]}
        except Exception as error:
            record(event='error', tool=params.get('name'), error=str(error))
            result = {'isError': True, 'content': [{'type': 'text', 'text': str(error)}]}
    else:
        result = {}
    reply = json.dumps({'jsonrpc':'2.0','id':message['id'],'result':result}, ensure_ascii=False)
    sys.stdout.buffer.write(reply.encode('utf-8') + b'\n')
    sys.stdout.buffer.flush()
