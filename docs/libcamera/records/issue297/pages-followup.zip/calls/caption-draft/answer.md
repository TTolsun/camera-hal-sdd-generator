{
  "waiting-queue-conditions": {
    "text": "queueRequest()는 요청 준비에 300 ms 인자를 전달합니다. 전달이 멈추면 queuedRequests_.size()가 maxQueuedRequestsDevice_와 같은지와 waitingRequests_의 맨 앞 요청이 준비되었는지를 각각 확인하세요.",
    "text_en": "queueRequest() passes 300 ms to request preparation. If forwarding stops, check separately whether queuedRequests_.size() equals maxQueuedRequestsDevice_ and whether the request at the front of waitingRequests_ is prepared."
  },
  "buffer-and-request-completion": {
    "text": "completeBuffer()가 true를 반환하면 요청에 포함된 모든 버퍼가 완료된 것입니다. 마지막 버퍼가 완료되어도 요청은 자동으로 완료되지 않으므로, 요청이 완료되지 않았다면 파이프라인 핸들러가 completeRequest()를 명시적으로 호출하는지 확인하세요.",
    "text_en": "A true return from completeBuffer() means all buffers in the request have completed. The request does not complete automatically when its last buffer completes, so if it remains incomplete, check whether the pipeline handler explicitly calls completeRequest()."
  },
  "submission-order-completion": {
    "text": "파이프라인 핸들러는 완료된 요청에 대해 순서 제약 없이 completeRequest()를 호출할 수 있지만, 요청은 제출 순서대로 애플리케이션에 반환됩니다. 앞선 요청의 상태가 Request::RequestPending이면 뒤에 있는 완료된 요청도 반환되지 않습니다.",
    "text_en": "The pipeline handler may call completeRequest() on completed requests in any order, but requests are returned to the application in submission order. If an earlier request has status Request::RequestPending, a later completed request is not returned yet."
  },
  "stop-exact-negated-guard": {
    "text": "실행 중에 Camera::stop()을 호출하면 촬영과 요청 처리가 즉시 중단되고, 대기 중인 모든 요청이 취소되어 오류 상태로 동기적으로 완료됩니다. !d->isRunning()이면 이 함수는 아무 작업도 하지 않고 0을 반환합니다.",
    "text_en": "When Camera::stop() is called while the camera is running, capture and request processing stop immediately, and all pending requests are cancelled and complete synchronously in an error state. If !d->isRunning(), the function does nothing and returns 0."
  },
  "pipeline-stop-waiting-cancellation": {
    "text": "PipelineHandler::stop()은 대기 요청을 따로 보관하고 stopDevice()를 호출한 뒤 대기 요청을 취소하며, completeRequest()는 요청을 제출 순서대로 애플리케이션에 반환합니다. 마지막으로 data->queuedRequests_.empty()와 data->waitingRequests_.empty()를 각각 확인하는 ASSERT를 실행하고 data->requestSequence_를 0으로 초기화합니다.",
    "text_en": "PipelineHandler::stop() sets waiting requests aside, calls stopDevice(), and then cancels the waiting requests; completeRequest() returns requests to the application in submission order. Finally, it asserts data->queuedRequests_.empty() and data->waitingRequests_.empty(), then resets data->requestSequence_ to 0."
  }
}
