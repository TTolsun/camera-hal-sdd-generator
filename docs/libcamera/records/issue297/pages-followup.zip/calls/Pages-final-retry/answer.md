## Q1

**첫 판단:** `queueRequest()`가 0을 반환한 것은 요청을 접수했다는 뜻입니다. 요청 완료는 이후 `requestCompleted` 알림으로 판단합니다. `completeBuffer()`가 `true`를 반환해 모든 버퍼가 완료됐더라도 요청이 자동으로 완료되는 것은 아닙니다. 파이프라인 핸들러가 `completeRequest()`를 명시적으로 호출해야 합니다. ([접수 반환과 완료 알림](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#접수-반환과-완료-알림), [버퍼 완료와 명시적 요청 완료의 경계](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#버퍼-완료와-명시적-요청-완료의-경계), 문서에 인용된 `pipeline_handler.cpp:556, 560`)

판단에 사용한 그림의 분기는 **“모든 버퍼가 완료됐는가?” → 예 → 마지막 버퍼 완료, 요청 자동 완료 아님 → `completeRequest()` 명시 호출**입니다. 또 완료된 뒤에도 제출 큐의 앞선 요청이 `RequestPending`이면 애플리케이션으로의 반환은 기다립니다. ([제출 큐의 선두 상태와 반환 순서](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#제출-큐의-선두-상태와-반환-순서), 문서에 인용된 `pipeline_handler.cpp:588, 594`)

**다음 행동:** 요청 완료 콜백까지 버퍼를 유효하게 유지하고, 프레임 데이터는 버퍼 상태가 `FrameSuccess`일 때 사용합니다. 요청을 다시 제출할 때 기본 `reuse()`는 버퍼 연결을 비우므로 `addBuffer()`로 다시 연결합니다. `ReuseBuffers`는 기존 버퍼를 다시 연결하지만 펜스까지 재사용하지는 않습니다. 특히 타임아웃으로 펜스가 버퍼에 남았다면 재제출 전에 `releaseFence()`로 회수합니다. 별도의 Queued 수신자가 버퍼를 계속 사용할 수 있다면 그 마지막 사용도 동기화한 뒤 재사용을 결정해야 합니다. ([요청과 버퍼를 유지할 기간](https://ttolsun.github.io/libcamera-sdd/camera-requests.html#요청과-버퍼를-유지할-기간), [버퍼 재사용과 펜스 권고](https://ttolsun.github.io/libcamera-sdd/camera-requests.html#버퍼-재사용과-펜스-권고), [타임아웃 뒤 펜스 회수](https://ttolsun.github.io/libcamera-sdd/camera-requests.html#타임아웃-뒤-펜스-회수), 문서에 인용된 `request.cpp:391, 397, 464`, `framebuffer.cpp:42`)

## Q2

**첫 판단:** 제출 성공만으로 장치 제출이나 완료 알림까지 진행됐다고 판단하지 않습니다. 먼저 해당 요청의 준비 상태와 대기 큐, 제출 큐 선두 상태를 확인합니다. 준비되지 않은 선두 요청은 뒤 요청의 장치 전달을 막고, 제출 큐 선두가 `RequestPending`이면 뒤에서 완료된 요청의 반환도 막습니다. ([제출 큐의 선두 상태와 반환 순서](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#제출-큐의-선두-상태와-반환-순서), 문서에 인용된 `pipeline_handler.cpp:588, 594`)

그림에서 사용할 분기는 **“제출 큐가 비어 있지 않은가?” → 예 → “선두가 `RequestPending`인가?” → 예이면 반환 반복을 중단**입니다. 따라서 선두의 상태와 남은 버퍼를 기록해, 조사 대상을 현재 요청에서 앞선 요청으로 옮길지 결정합니다.

**다음 행동:** 기존 호출의 반환값과 큐 상태를 다음 순서로 관찰합니다.

- 준비 단계가 끝났는지, 장치에 전달할 수 있는 큐 여유가 있는지 확인합니다.
- UVC 경로라면 `processControls`, `queueBuffer`, `VIDIOC_QBUF`의 반환값과 이번 버퍼의 `queuedBuffers_` 등록 여부를 확인합니다. 캐시 항목을 얻지 못한 `-ENOENT`와, 인덱스 확보 후 플레인 검사에 실패한 `-EINVAL`은 서로 다른 분기입니다. 후자는 확보한 인덱스를 캐시에 돌려줍니다. 장치 제출 실패가 확인되면 공통 경로에서 요청 취소로 이어지는지도 확인합니다. ([QBUF 호출 전 실패와 cache 반환](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#qbuf-호출-전-실패와-cache-반환))
- QBUF가 성공했다면 이후 `VIDIOC_DQBUF`의 결과와 반환 인덱스, `bufferReady`, `completeBuffer()` 및 `completeRequest()` 진입을 확인합니다. 문서는 DQBUF 오류나 예상 밖 인덱스에서는 `dequeueBuffer()`가 `nullptr`을 반환하고 `bufferReady`가 발생하지 않는다고 설명합니다. 버퍼 완료와 요청 완료는 별도로 기록합니다. ([QBUF 호출 전 실패와 cache 반환](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#qbuf-호출-전-실패와-cache-반환), [버퍼 완료와 명시적 요청 완료의 경계](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#버퍼-완료와-명시적-요청-완료의-경계), 문서에 인용된 `pipeline_handler.cpp:556, 560`)

위 값들은 **앞으로 관측할 항목**입니다. 이번에 실제 장치 실행이나 콜백 누락을 관측한 것은 아닙니다. Q2에 대응하는 일부 코드 창은 아래에 적은 출력 잘림으로 확인하지 못했습니다.

## Q3

**첫 판단:** 정상 정지 계약은 대기 중인 요청을 취소하고 오류 상태로 동기 완료하는 것입니다. 구현에서는 `PipelineHandler::stop()`이 준비 대기 큐를 먼저 분리하고 장치를 정지한 뒤 그 요청들을 취소합니다. 이는 장치 정지 중 완료 콜백이 대기 요청을 다시 장치에 넣는 일을 막고 순서를 유지하기 위한 처리입니다. ([정지 API 계약과 연결 해제 TODO](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#정지-api-계약과-연결-해제-todo), [`camera.cpp:1433–1439`](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/camera.cpp#L1433), [`pipeline_handler.cpp:368–398`](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/pipeline_handler.cpp#L368))

판단에 사용한 그림의 분기는 **정지 계약 → 대기 요청 취소·오류 완료**와, 별도로 **연결 해제 알림 → Running 중 대기 요청 처리 TODO**입니다. 연결 해제도 정상 정지와 동일하게 정리된다고 가정하지 않습니다.

**수정 시 확인할 위험과 다음 행동:**

- **장치 정지 실패:** `VIDIOC_STREAMOFF` 실패 시 `streamOff()`는 버퍼 반환 루프와 큐·알림 정리에 도달하지 않습니다. 그런데 UVC의 `stopDevice()`는 그 반환값을 검사하지 않고 `releaseBuffers()`를 호출합니다. 실패를 주입해 반환값, 큐와 캐시, 알림 상태 및 남은 요청을 관찰해야 합니다. 잔존 알림에서 DQBUF가 성공하는 등의 조건에서는 null이 된 캐시에 접근할 가능성도 조사 대상입니다. ([정지 API 계약과 연결 해제 TODO](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#정지-api-계약과-연결-해제-todo), [`v4l2_videodevice.cpp:2023–2053`](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/v4l2_videodevice.cpp#L2023), [`uvcvideo.cpp:320–324`](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/pipeline/uvcvideo/uvcvideo.cpp#L320))
- **콜백 순서와 재진입:** 취소 구현은 각 대기 버퍼에 대해 `bufferCompleted`를 발신한 뒤 요청 취소 상태와 내부 집합을 갱신합니다. 직접 연결된 슬롯은 동기적으로 중첩 실행될 수 있으므로 콜백에서 보는 상태와 재진입을 검증해야 합니다. 장치의 정지 시 버퍼 반환 순서 자체는 지정되지 않습니다. 요청별 완료 횟수와 애플리케이션 반환 순서도 기록합니다. ([직접 중첩 호출과 별도 Queued 수신의 경계](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#직접-중첩-호출과-별도-queued-수신의-경계), [`request.cpp:139–160`](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/request.cpp#L139), [`v4l2_videodevice.cpp:2011–2016`](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/v4l2_videodevice.cpp#L2011))
- **버퍼 수명:** `Camera::stop()`의 Blocking 호출이 끝나도 별도 Queued 수신자의 마지막 사용까지 끝났다는 보장은 없습니다. 수신자의 실행과 마지막 사용을 기록하고, 그 종료와 동기화한 다음 삭제 또는 재사용해야 합니다. ([stop 반환과 별도 수신의 마지막 사용 확인](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#stop-반환과-별도-수신의-마지막-사용-확인), [`camera.cpp:1462–1471`](https://github.com/TTolsun/libcamera-sdd/blob/da6a6ed33ed0ab305f10b6f8b44736150d39cef4/src/libcamera/camera.cpp#L1462))

준비 대기中の 요청과 장치에 대기 중인 요청이 섞인 상태, 정지 실패, 연결 해제, 지연된 수신을 각각 재현하는 검증은 아직 수행하지 않았습니다.

도구는 지정대로 **한 번** 호출했습니다. 반환 출력이 잘려 제가 실제로 확인한 종료 표식은 **`END Q3`**뿐입니다. `END Q1`, `END Q2`와 Q1·Q2의 일부 코드 창은 출력에서 확인하지 못했습니다. 따라서 그 부분은 보이는 문서의 인용 행과 설명을 근거로 적었으며, 잘린 코드 창을 직접 읽었다고 주장하지 않습니다.
