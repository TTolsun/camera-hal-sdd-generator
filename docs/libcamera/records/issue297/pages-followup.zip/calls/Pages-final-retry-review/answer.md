[
  {
    "question": "Q1",
    "document": {
      "ratings": ["충족", "충족", "충족", "충족", "충족", "충족"],
      "pass": true,
      "findings": [
        "https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#접수-반환과-완료-알림 및 #버퍼-완료와-명시적-요청-완료의-경계는 제출 성공, 버퍼 완료와 요청 완료를 구분한다. pipeline_handler.cpp:563–567, 584–599와 일치한다.",
        "https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#qbuf-호출-전-실패와-cache-반환은 요청 상태와 FrameSuccess·FrameError·FrameCancelled의 데이터 유효성을 구분한다. request.cpp:125–132, framebuffer.cpp:40–53이 근거다.",
        "https://ttolsun.github.io/libcamera-sdd/camera-requests.html#버퍼-재사용과-펜스-권고와 request-lifecycle.html#queued-수신과-해제-시점의-책임은 재사용 및 별도 수신자의 마지막 사용 조건을 설명한다. request.cpp:385–400, 462–466과 맞는다."
      ]
    },
    "reader": {
      "ratings": ["충족", "부분 충족", "부분 충족", "충족", "부분 충족", "부분 충족"],
      "pass": false,
      "findings": [
        "제출 성공과 requestCompleted, 마지막 버퍼 이후 명시적 completeRequest, 선두 Pending에 따른 반환 대기를 정확히 설명했다. 독해가 읽은 pipeline_handler.cpp:553–568, 584–603이 이를 뒷받침한다.",
        "필수 범위 누락: RequestComplete와 RequestCancelled 및 FrameError·FrameCancelled를 명시적으로 구분하지 않아 취소·실패 후 버퍼 재사용과 실패한 프레임 데이터 읽기의 차이를 충분히 설명하지 않았다.",
        "기본 reuse, ReuseBuffers, 잔존 fence 회수와 Queued 수신자의 마지막 사용을 설명했다. 다만 앱의 요청 소유와 raw 포인터가 수명을 연장하지 않는다는 책임은 답변에 빠졌다.",
        "근거 범위 누락: 독해가 받은 request.cpp 창에는 요청 완료 상태를 결정하는 132행이 없다. 제공된 검토 전용 소스 창으로 그 누락을 보충하지 않았다."
      ]
    },
    "evidence_scope": "문서는 camera-requests.html의 수명·재사용 앵커와 request-lifecycle.html의 완료·상태 앵커를 평가했다. 독해의 소스 접근은 제공된 전달 창으로 한정했다. framebuffer.cpp#L42는 같은 링크로 432–449행이 전달됐지만, FrameSuccess 정의는 별도로 열린 framebuffer.cpp#L40의 38–58행에서 확인됐다.",
    "unchecked": "실기기 실행, 플랫폼별 DMA 동기화 및 실제 외부 소비자의 마지막 사용은 검증하지 않았다. Pages 빌드의 소스 커밋 da6a6ed와 고정 기준의 공식 소스 커밋 c19d051의 차이 전체는 검증하지 않았다."
  },
  {
    "question": "Q2",
    "document": {
      "ratings": ["충족", "충족", "충족", "충족", "충족", "충족"],
      "pass": true,
      "findings": [
        "https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#같은-poll-회차의-fence와-타이머-처리는 제출 회차 표식과 PipelineHandler 진입 여부를 먼저 연결하고, 진입하지 않은 경우 메시지 전달을 조사하도록 한다. camera.cpp:1376–1379, pipeline_handler.cpp:469–477이 근거다.",
        "https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#선두-요청을-전달하거나-반복을-멈추는-조건과 #void-전달-함수의-두-취소-경로는 준비 여부, 장치 한도, 사전 취소와 장치 제출 실패를 구분한다. pipeline_handler.cpp:483–500, 509–525와 일치한다.",
        "https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#qbuf-호출-전-실패와-cache-반환은 UVC의 QBUF·DQBUF 경계를 공통 경로와 구분한다. 계획과 관측 결과도 구분한다.",
        "https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#제출-회차별-완료-기록의-비교-계획과 #queued-수신과-해제-시점의-책임은 완료 통지 이후 수신과 dispatch를 별도 조사 경계로 둔다."
      ]
    },
    "reader": {
      "ratings": ["부분 충족", "부분 충족", "부분 충족", "부분 충족", "충족", "부분 충족"],
      "pass": false,
      "findings": [
        "준비되지 않은 선두와 장치 큐 여유, 반환 큐의 Pending 선두, UVC의 QBUF·DQBUF와 버퍼·요청 완료 경계를 조사 대상으로 제시했다. 실제 장치 관측은 없었다고 명시했다.",
        "중요한 분기 누락: 제출 회차를 식별해 PipelineHandler::queueRequest 진입 여부부터 확인하고, 미진입이면 메시지 dispatch를 조사하는 절차가 없다.",
        "중요한 분기 누락: fence·notifier·timer와 준비 timeout 취소, 이미 취소되어 장치 함수에 가지 않는 경로, requestCompleted 발신 후 수신 연결과 dispatch를 조사하는 경계가 빠졌다.",
        "필수 근거 범위 누락: 독해에 전달된 v4l2_videodevice.cpp 창에는 VIDIOC_QBUF 호출·성공 후 등록 행인 1785–1801행이 없다. QBUF 성공 이후의 설명은 열린 문서에 근거하지만 해당 핵심 구현을 직접 읽은 것으로 인정할 수 없다."
      ]
    },
    "evidence_scope": "독해는 pipeline_handler.cpp:469–480, 483–502, 509–526, 553–568, 584–603과 UVC 및 V4L2의 일부 창을 받았다. 문서에서 열었으나 답하지 않은 내용과 전달되지 않은 QBUF 핵심 행은 독해 답변에 보충하지 않았다.",
    "unchecked": "실제 로그, 요청별 추적, 메시지 dispatch 및 실기기 지연 원인은 관측하지 않았다. 고정 기준과 Pages 소스 커밋의 전체 차이는 검증하지 않았다."
  },
  {
    "question": "Q3",
    "document": {
      "ratings": ["충족", "충족", "충족", "충족", "충족", "충족"],
      "pass": true,
      "findings": [
        "https://ttolsun.github.io/libcamera-sdd/scenarios/camera_stop.html#파이프라인-정지와-대기-요청-취소는 대기 큐 분리, 장치 정지, 대기 요청 취소와 순번 처리를 설명한다. pipeline_handler.cpp:367–401과 그림의 순서가 맞는다.",
        "https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#uvc-정지의-정상-경로와-실패-경계-그림은 STREAMOFF 실패 시 조기 반환과 UVC의 반환값 미확인을 구분한다. v4l2_videodevice.cpp:2023–2055, uvcvideo.cpp:320–324가 근거다.",
        "https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#stop-반환과-별도-수신의-마지막-사용-확인과 #동시-제출정지지연-수신의-검증-위치는 연결 방식, 수명 및 검증 계획을 설명하며 실행 결과와 구분한다."
      ]
    },
    "reader": {
      "ratings": ["충족", "충족", "부분 충족", "부분 충족", "충족", "충족"],
      "pass": false,
      "findings": [
        "정상 정지 계약, 대기 큐 분리 이유, 연결 해제 TODO와 UVC STREAMOFF 실패 위험을 구분했다. 독해가 읽은 camera.cpp:1431–1445, pipeline_handler.cpp:368–402, v4l2_videodevice.cpp:2023–2055와 일치한다.",
        "취소 시 버퍼 알림 후 내부 정리, 직접 콜백의 중첩 가능성, 별도 Queued 수신자의 마지막 사용을 설명했다. request.cpp:139–164와 bound_method.cpp:68–102를 읽었다.",
        "필수 검증 계획 누락: 동일 제출 회차별 버퍼 및 요청 콜백의 횟수와 순서를 함께 비교하는 방법, stop 후 큐·상태 확인, 카메라 상태 변경 호출의 동기화 조건을 충분히 제시하지 않았다. 요청별 완료 횟수만 기록하라는 답변으로는 버퍼 콜백의 중복·누락을 검증하기 어렵다.",
        "정확성 문제와 별개로, 열어 본 검증 위치의 내용을 답변에 포함하지 않은 범위 누락이다. 실기기 재현을 수행하지 않았다는 구분은 적절하다."
      ]
    },
    "evidence_scope": "독해는 명시한 stop·취소·UVC 소스의 핵심 창을 전달받았다. v4l2_videodevice.cpp#L2023 링크로 같은 함수의 2009–2018행과 2023–2055행을 읽은 범위를 근거 접근으로 인정했다.",
    "unchecked": "혼합된 대기·장치 요청, 정지 실패, 연결 해제와 지연 수신의 재현 및 실기기 검증은 수행하지 않았다. 고정 기준과 Pages 소스 커밋의 전체 차이는 검증하지 않았다."
  }
]
