[
  {
    "question": "Q1",
    "document": {
      "ratings": ["충족", "충족", "충족", "충족", "충족", "충족"],
      "pass": true,
      "findings": [
        "정확성: 접수와 요청 완료를 구분하고, 마지막 버퍼 완료 뒤에도 명시적인 completeRequest가 필요하다고 설명한다. request-lifecycle.html#접수-반환과-완료-알림, #버퍼-완료와-명시적-요청-완료의-경계; pipeline_handler.cpp:563-567, 584-599.",
        "근거 범위: camera-requests.html#버퍼-재사용과-펜스-권고와 request-lifecycle.html#queued-수신과-해제-시점의-책임은 펜스 회수와 별도 수신자의 마지막 사용을 다룬다. request.cpp:385-400, 462-466."
      ]
    },
    "reader": {
      "ratings": ["부분 충족", "부분 충족", "부분 충족", "부분 충족", "부분 충족", "부분 충족"],
      "pass": false,
      "findings": [
        "정확성: 제출 접수, 명시적 요청 완료, 선두 Pending에 따른 반환 대기, reuse와 펜스 회수는 대체로 맞다. pipeline_handler.cpp:553-568, 584-603; request.cpp:375-403, 462-465.",
        "중요 조건 누락: 완료 콜백까지 버퍼를 유지해야 한다고만 답해, 재사용이나 해제 전에 별도 앱 수신자와 외부 소비자의 마지막 사용을 확인해야 한다는 조건을 빠뜨렸다. 열린 request-lifecycle.html#queued-수신과-해제-시점의-책임은 독해 답변의 누락을 보충하지 않는다.",
        "범위 누락: FrameSuccess만 언급하고 요청의 완료·취소 상태와 버퍼의 성공·오류·취소 상태를 구분하거나 실패·취소 후 재사용과 데이터 읽기를 설명하지 않았다."
      ]
    },
    "evidence_scope": "독해에 전달된 핵심 창은 camera.cpp:1249-1263, 1369-1380, 1475-1489, pipeline_handler.cpp:553-568, 584-603, request.cpp:375-403, 442-449, 462-465, 475-493이다. 답변은 Pages 앵커를 명시했다.",
    "unchecked": "실기기 동작, 외부 소비자의 실제 마지막 사용 시점과 플랫폼별 DMA 동기화는 검증되지 않았다."
  },
  {
    "question": "Q2",
    "document": {
      "ratings": ["충족", "충족", "충족", "충족", "충족", "충족"],
      "pass": true,
      "findings": [
        "정확성: request-lifecycle.html#같은-poll-회차의-fence와-타이머-처리에는 제출 회차 표식과 PipelineHandler::queueRequest 진입 여부에 따른 메시지 전달 조사, 준비 및 타임아웃 분기가 있다. camera.cpp:1373-1379; pipeline_handler.cpp:469-477, 509-525.",
        "근거 범위: #void-전달-함수의-두-취소-경로, #qbuf-호출-전-실패와-cache-반환, #제출-큐의-선두-상태와-반환-순서는 취소, UVC 제출, 장치 완료와 반환 경계를 구분한다. pipeline_handler.cpp:483-501, 584-603; v4l2_videodevice.cpp:1669-1700, 1814-1821."
      ]
    },
    "reader": {
      "ratings": ["부분 충족", "부분 충족", "부분 충족", "부분 충족", "충족", "부분 충족"],
      "pass": false,
      "findings": [
        "중요 분기 누락: 제출 성공 직후 PipelineHandler::queueRequest 진입 여부를 확인하고, 미진입이면 수신 스레드의 메시지 게시·dispatch를 조사하는 첫 분기가 없다. 요청 포인터와 구분되는 제출 회차 식별도 제시하지 않았다.",
        "중요 분기 누락: doQueueRequest에서 이미 취소된 요청이 장치 함수에 가지 않고 완료되는 경로와 장치 제출 실패 취소 경로를 명시적으로 구분하지 않았다. pipeline_handler.cpp:483-501.",
        "필수 소스 탐색 범위 누락: QBUF 전 캐시 획득과 공통 planes 검증의 핵심인 v4l2_videodevice.cpp:1669-1700은 독해에 전달되지 않았다. 같은 #L1648 링크로 전달된 창은 1723-1743행이므로 핵심 행 접근으로 인정할 수 없다.",
        "정확성: 준비 선두와 장치 한도, UVC 제출, DQBUF와 bufferReady, FIFO 반환 및 수신 연결 방식에 관한 조사 계획은 대체로 타당하다. 실제 장치 관측 결과로 주장하지 않았다."
      ]
    },
    "evidence_scope": "독해 답변은 Pages URL과 uvcvideo.cpp:448-466, 893-903, v4l2_videodevice.cpp:1814-1821, 1848-1868, bound_method.cpp:68-102를 명시했다. DQBUF 창은 예상 밖 인덱스의 실제 반환 분기인 1869-1874행보다 앞에서 끝났다.",
    "unchecked": "실제 요청별 로그, 메시지 전달, 장치 지연과 완료 누락 원인은 관측되지 않았다."
  },
  {
    "question": "Q3",
    "document": {
      "ratings": ["부분 충족", "부분 충족", "충족", "부분 충족", "부분 충족", "부분 충족"],
      "pass": false,
      "findings": [
        "정확성: scenarios/camera_stop.html#파이프라인-정지와-대기-요청-취소와 #버퍼별-취소-통지와-내부-정리는 대기열 분리, 장치 정지 후 취소, 버퍼별 알림과 내부 정리를 설명한다. pipeline_handler.cpp:368-402; request.cpp:139-151.",
        "필수 근거 범위 누락: 제공된 실제 Pages의 request-lifecycle.html#uvc-정지의-정상-경로와-실패-경계는 정상 경로만 설명한다. STREAMOFF 실패 시 버퍼 반환 루프 전에 복귀하고 UVC 호출이 반환값을 검사하지 않는 예외를 다루지 않는다. v4l2_videodevice.cpp:2033-2046; uvcvideo.cpp:320-325.",
        "정확성: #stop-반환과-별도-수신의-마지막-사용-확인과 #직접-중첩-호출과-별도-queued-수신의-경계는 stop 반환과 별도 수신 완료를 구별하고 실행 전 검증 계획으로 표시한다."
      ]
    },
    "reader": {
      "ratings": ["충족", "충족", "부분 충족", "부분 충족", "충족", "부분 충족"],
      "pass": false,
      "findings": [
        "정확성: 대기 요청 분리, 취소 처리, STREAMOFF 실패의 조기 반환, Blocking 정지와 별도 queued 수신의 수명 차이를 구분했다. pipeline_handler.cpp:368-402; request.cpp:139-164; uvcvideo.cpp:318-325; v4l2_videodevice.cpp:2023-2055.",
        "중요 조건 누락: 카메라 상태를 바꾸는 호출을 호출자가 동기화해야 한다는 계약과 직접 콜백의 중첩·재진입 위험을 검증 조건으로 명시하지 않았다. 동시 제출 시험만으로 그 계약을 설명한 것은 아니다. camera.cpp:1436-1439.",
        "검증 범위 누락: 정지 후 두 요청 큐와 카메라 상태를 확인하는 계획이 없다. 또한 버퍼별 알림까지 제출 순서를 지켜야 하는 것처럼 읽히는 검증 항목은 버퍼 반환 순서가 지정되지 않은 streamOff 계약과 구별해야 한다. pipeline_handler.cpp:397-401; v4l2_videodevice.cpp:2013-2016.",
        "근거 범위: 독해가 인용한 UVC 실패 경계 그림 앵커는 제공된 실제 Pages 목록의 앵커와 다르다. 다만 답변에 명시된 독해 소스 창에서 실패 분기 자체는 확인했다."
      ]
    },
    "evidence_scope": "독해에 전달된 창에는 camera.cpp:1431-1445, 1453-1472, pipeline_handler.cpp:368-402, request.cpp:139-164, uvcvideo.cpp:318-330, v4l2_videodevice.cpp:2023-2055 및 bound_method.cpp:68-102가 포함된다. 도구 출력이 잘렸다는 독해의 제한을 그대로 적용한다.",
    "unchecked": "실기기 정지, 동시 제출, 실패 주입, 콜백 순서와 객체의 실제 마지막 사용은 검증되지 않았다."
  }
]
