## Q1

`queueRequest()`가 0을 반환한 시점에는 **제출이 접수된 것**입니다. 요청 완료는 이후 `requestCompleted` 알림으로 판단합니다. 개별 버퍼가 모두 완료되어 `completeBuffer()`가 `true`를 반환해도 요청이 자동 완료되는 것은 아닙니다. 파이프라인 핸들러가 필요한 후처리 뒤 `completeRequest()`를 호출해야 합니다. 또 뒤 요청이 먼저 내부적으로 완료돼도 앞 요청이 `RequestPending`이면 앱에는 제출 순서대로 반환될 때까지 기다립니다.

앱은 요청과 버퍼의 수명을 관리해야 합니다. 요청에 저장된 버퍼 참조나 큐에 전달된 포인터가 객체의 수명을 늘려주지는 않으므로, **버퍼를 요청 완료 콜백까지 유효하게 유지**해야 합니다. 완료 후 같은 요청을 재사용할 때 기본 `reuse()`는 버퍼 연결을 비우므로 `addBuffer()`로 다시 연결합니다. `ReuseBuffers`는 기존 버퍼 연결을 재사용하지만 펜스는 재사용하지 않으며, 문서는 펜스를 사용할 때 이 플래그를 피하도록 권고합니다. 타임아웃으로 버퍼에 펜스가 남았다면 다시 제출하기 전에 `releaseFence()`로 회수해야 합니다. 프레임 데이터는 버퍼 상태가 `FrameSuccess`일 때만 사용합니다.

근거: [접수 반환과 완료 알림](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#접수-반환과-완료-알림), [버퍼 완료와 명시적 요청 완료의 경계](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#버퍼-완료와-명시적-요청-완료의-경계), [제출 큐의 선두 상태와 반환 순서](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#제출-큐의-선두-상태와-반환-순서), [요청과 버퍼를 유지할 기간](https://ttolsun.github.io/libcamera-sdd/camera-requests.html#요청과-버퍼를-유지할-기간), [버퍼 재사용과 펜스 권고](https://ttolsun.github.io/libcamera-sdd/camera-requests.html#버퍼-재사용과-펜스-권고), [타임아웃 뒤 펜스 회수](https://ttolsun.github.io/libcamera-sdd/camera-requests.html#타임아웃-뒤-펜스-회수). 반환 순서 그림의 핵심 분기는 **선두가 `RequestPending`이면 중단**, 아니면 제거 후 알림입니다.

## Q2

먼저 요청이 어느 경계까지 진행했는지 요청별로 확인합니다. 아래는 **조사 계획**이며, 실제 장치에서 관측한 결과는 아닙니다.

1. **준비와 전달:** `waitingRequests_`의 선두가 준비됐는지, 펜스 신호 또는 300ms 준비 타임아웃이 있었는지, `queuedRequests_`가 장치 전달 한도에 도달했는지 기록합니다. 선두가 준비되지 않았거나 한도에 도달하면 뒤 요청도 장치로 전달되지 않습니다.
2. **장치 제출:** UVC라면 `queueRequestDevice()`에서 버퍼 검색, 제어 처리, `queueBuffer()`의 반환값을 차례로 확인합니다. 버퍼를 찾지 못하거나 제어·버퍼 제출이 실패하면 오류가 반환되고 취소 경로로 갑니다. QBUF 이전에 캐시 항목이 없으면 `-ENOENT`, planes 검증 실패면 `-EINVAL`이 될 수 있습니다. 검증 실패 시 이미 확보한 캐시 인덱스는 guard가 반환합니다. 제어 처리 성공 후 버퍼 제출이 실패하는 경로에는 제어 롤백이 없습니다.
3. **장치 완료:** 제출 이후 `VIDIOC_DQBUF` 결과와 `bufferReady`를 확인합니다. `dequeueBuffer()`가 버퍼를 반환하지 않으면 `bufferReady`는 발생하지 않습니다. UVC의 `imageBufferReady()`에 도달했다면 `completeBuffer()` 다음 `completeRequest()`가 호출되는지 확인합니다.
4. **앱 알림:** 내부 완료가 있었어도 `queuedRequests_`의 선두가 아직 대기 중인지 확인합니다. 그다음 신호 연결 방식과 수신자의 메시지 처리를 조사합니다. 자동 연결은 같은 스레드면 직접 호출, 다른 스레드면 queued 전달이므로, 내부 완료 시각과 앱 콜백 진입·복귀 시각 및 스레드 ID를 각각 기록해야 합니다.

근거 그림은 [선두 요청을 전달하거나 반복을 멈추는 조건](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#선두-요청을-전달하거나-반복을-멈추는-조건), [같은 poll 회차의 fence와 타이머 처리](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#같은-poll-회차의-fence와-타이머-처리), [QBUF 호출 전 실패와 cache 반환](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#qbuf-호출-전-실패와-cache-반환), [제출 큐의 선두 상태와 반환 순서](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#제출-큐의-선두-상태와-반환-순서)입니다. QBUF 그림은 캐시 획득 실패, planes 검증 실패, QBUF 도달을 구분합니다.

실제로 확인한 코드 창에는 `uvcvideo.cpp` 448–466행과 893–903행, `v4l2_videodevice.cpp` 1814–1821행과 1848–1868행, `bound_method.cpp` 68–102행이 포함됩니다. DQBUF 창은 1868행에서 끝나므로 그 이후의 모든 처리까지 확인한 것은 아닙니다.

## Q3

정지 수정의 핵심 위험은 **대기 요청이 다시 장치로 전달되거나, 취소·완료 누락과 순서 역전이 생기고, 지연된 콜백이 이미 해제된 객체를 사용하는 것**입니다.

정상 정지 경로에서 파이프라인은 먼저 `waitingRequests_`를 별도 큐로 옮겨 장치 정지 중 재전달을 막습니다. 장치 정지 후 대기 요청을 취소하고 `doQueueRequest()`를 거쳐 시퀀스를 부여해 순서대로 완료합니다. 취소 시에는 각 미완료 버퍼를 취소하고 `bufferCompleted`를 발생시킨 뒤 내부 pending 집합과 notifier, 타이머를 정리합니다. 따라서 버퍼별 알림과 요청 완료의 순서, 중복 알림 및 누락을 검증해야 합니다.

UVC에서는 `stopDevice()`가 `streamOff()`와 `releaseBuffers()`를 호출합니다. `streamOff()` 성공 경로는 큐의 버퍼를 취소하고 `bufferReady`를 발생시킵니다. **예외적으로 `VIDIOC_STREAMOFF`가 실패하면 그 버퍼 반환 루프 전에 오류를 반환**하며, 표시된 UVC 호출은 그 반환값을 검사하지 않습니다. 이 실패 경로까지 정상 경로와 같은 정리 결과가 보장된다고 판단해서는 안 됩니다.

API 주석은 미완료 요청이 동기적으로 취소·완료된다고 설명합니다. 구현에서는 실행 중이 아니면 0으로 바로 반환하고, 실행 중이면 blocking 호출로 파이프라인을 정지한 뒤 pending 요청이 없음을 검사합니다. 다만 신호의 직접 호출과 별도 스레드로의 queued 수신은 다릅니다. 따라서 `stop()` 반환만을 근거로 **별도 수신자가 요청·버퍼를 마지막으로 사용했음**을 단정하지 말고, 수신 완료까지 수명을 유지할 방법을 확인해야 합니다.

검증 계획은 다음과 같습니다. 아직 실행하거나 관측한 결과는 아닙니다.

- 장치에 들어간 요청과 준비 대기 요청이 섞인 상태에서 정지하고, 각 요청의 시퀀스와 버퍼별 취소·요청 완료 알림이 누락이나 중복 없이 제출 순서를 지키는지 확인합니다.
- 제출과 정지를 경합시키고 직접 연결과 지연된 queued 수신 각각에서 콜백 진입·복귀, `stop()` 반환 및 객체의 마지막 사용을 기록합니다.
- `STREAMOFF` 실패와 이미 정지된 상태를 따로 주입해 반환값, 남은 큐, 알림 및 버퍼 수명을 확인합니다.

근거: [Camera.stop의 미실행·오류·정상 경로](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#camerastop의-미실행오류정상-경로), [파이프라인 정지와 대기 요청 취소](https://ttolsun.github.io/libcamera-sdd/scenarios/camera_stop.html#파이프라인-정지와-대기-요청-취소), [버퍼별 취소 통지와 내부 정리](https://ttolsun.github.io/libcamera-sdd/scenarios/camera_stop.html#버퍼별-취소-통지와-내부-정리), [UVC 정지의 정상 경로와 실패 경계](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#uvc-정지의-정상-경로와-실패-경계-그림), [stop 반환과 별도 수신의 마지막 사용 확인](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#stop-반환과-별도-수신의-마지막-사용-확인). 실제로 확인한 코드는 `camera.cpp` 1431–1445행, 1453–1472행, `pipeline_handler.cpp` 368–402행, `request.cpp` 139–164행, `uvcvideo.cpp` 318–325행, `v4l2_videodevice.cpp` 2023–2055행입니다.

지정 도구는 한 번 호출했습니다. **응답은 출력 한도에서 잘렸으므로**, 위에 명시한 문서 내용과 코드 창 밖의 세부 구현이나 모든 링크의 열람 성공 여부는 확인하지 못했습니다. 코드 확인은 실행 관측이 아닙니다.
