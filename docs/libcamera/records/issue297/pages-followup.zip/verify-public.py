from concurrent.futures import ThreadPoolExecutor
from hashlib import sha256
from pathlib import Path
from urllib.parse import quote
from urllib.request import Request, urlopen
import json
import sys
import time

root = Path(__file__).resolve().parent
snapshot = root / sys.argv[1]
site = sys.argv[2] if len(sys.argv) > 2 else 'https://ttolsun.github.io/libcamera-sdd/'
started = time.perf_counter()


def download(name):
    request = Request(site + quote(name, safe='/'), headers={'Cache-Control': 'no-cache'})
    with urlopen(request, timeout=20) as response:
        return response.read()


raw = snapshot.read_bytes()
while True:
    try:
        if download('site-manifest.json') == raw:
            break
    except OSError:
        pass
    if time.perf_counter() - started >= 180:
        raise TimeoutError('The expected Pages manifest did not become available')
    time.sleep(5)
manifest = json.loads(raw)


def verify(pair):
    name, digest = pair
    for attempt in range(3):
        try:
            actual = sha256(download(name)).hexdigest()
            if actual != digest:
                raise ValueError(f'{name}: {actual} != {digest}')
            return
        except (OSError, ValueError):
            if attempt == 2:
                raise
            time.sleep(attempt + 1)


with ThreadPoolExecutor(max_workers=10) as pool:
    list(pool.map(verify, manifest['outputs'].items()))
assert download('site-manifest.json') == raw
result = {'url': site, 'build_id': manifest['build_id'], 'manifest_sha256': sha256(raw).hexdigest(),
          'verified_outputs': len(manifest['outputs']), 'seconds': time.perf_counter() - started}
(root / f'verified-{manifest["build_id"][:12]}.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
