from collections import defaultdict
from hashlib import sha256
import json
from pathlib import Path
import re
import subprocess
import sys
from zipfile import ZipFile


root = Path(__file__).resolve().parent
source = root.parent / 'issue303/source'
phase = sys.argv[1]
site = root / ('pages-live' if phase == 'baseline' else 'pages-final')
live_phase = phase != 'baseline'
site_manifest = json.loads((site/'site-manifest.json').read_bytes())
commit = json.loads((site/'item-visual-audit.json').read_bytes())['source_commit']
original = 'c19d05128f3ae1f0ebe63acb4deaca9fbb1dde78'
files = {}
def get_file(path):
    if path not in files:
        raw = subprocess.check_output(['git','-C',str(source),'show',f'{commit}:{path}'])
        files[path] = sha256(raw).hexdigest(), raw.decode('utf-8').splitlines()
    return files[path]


instructions = '''당신은 문서를 쓰거나 읽기 시험을 한 모델과 별도로 실행된 소스 근거 검토자입니다. 질문과 고정 기준을 적용해 실제 Pages 문서의 깊이와 독립 독해 답변의 성공을 각각 판정하세요. 각 결과는 아래 여섯 기준을 순서대로 충족, 부분 충족, 미충족, 해당 없음 중 하나로 기록합니다.
① 직접 답변·적용 조건 ② 정상·실패·취소·예외 ③ 책임·소유권·수명·순서·동시성 ④ 실제 코드와 다음 행동·검증 ⑤ API 계약·구현·해석·미확인 구별 ⑥ 근거 접근과 충분성·그림 일치.
필수 오답, 중요한 조건·분기 누락, 필수 소스 탐색 실패는 해당 질문의 통과를 막습니다. 독해가 실제로 연 문서와 소스 행 및 독해 답변을 대조합니다. 이 검토에만 제공된 소스 창, 독해가 열었으나 답하지 않은 내용, 도구가 전달하지 못한 내용으로 독해의 누락을 보충하지 마세요. 코드 링크의 앵커 행이 해당 파일에서 실제로 읽은 창 안에 있거나, 같은 링크로 그 함수의 실제 핵심 행을 읽었다면 근거 접근으로 인정합니다. 답변에 URL이나 실제 소스 파일·행이 명시되어야 합니다. 무관한 탐색 오류는 그 때문에 필수 근거가 누락됐을 때만 실패로 판정합니다. 문서 평가와 독해 평가에서 발견한 정확성 문제와 근거 범위 누락을 구분하세요. 실기기에서 검증했다고 추정하지 마세요.
JSON으로만 출력하세요. 형식은 {"question":"Qx","document":{"ratings":["..."],"pass":true,"findings":["..."]},"reader":{"ratings":["..."],"pass":true,"findings":["..."]},"evidence_scope":"...","unchecked":"..."} 입니다. 근거가 있는 핵심 문서 앵커와 소스 파일·행을 findings 또는 evidence_scope에 넣으세요.
'''

paths = {
    'Q1': [
        'camera-requests.html#요청과-버퍼를-유지할-기간',
        'camera-requests.html#타임아웃-뒤-펜스-회수',
        'camera-requests.html#재사용-버퍼의-요청-연결',
        'camera-requests.html#버퍼-재사용과-펜스-권고',
        'request-lifecycle.html#접수-반환과-완료-알림',
        'request-lifecycle.html#버퍼-완료와-명시적-요청-완료의-경계',
        'request-lifecycle.html#qbuf-호출-전-실패와-cache-반환',
        'request-lifecycle.html#queued-수신과-해제-시점의-책임',
    ],
    'Q2': [
        'request-lifecycle.html#동시-제출의-순서를-관찰할-경계',
        'request-lifecycle.html#같은-poll-회차의-fence와-타이머-처리',
        'request-lifecycle.html#선두-요청을-전달하거나-반복을-멈추는-조건',
        'request-lifecycle.html#void-전달-함수의-두-취소-경로',
        'request-lifecycle.html#qbuf-호출-전-실패와-cache-반환',
        'request-lifecycle.html#버퍼-완료와-명시적-요청-완료의-경계',
        'request-lifecycle.html#제출-큐의-선두-상태와-반환-순서',
        'request-lifecycle.html#제출-회차별-완료-기록의-비교-계획',
        'request-lifecycle.html#queued-수신과-해제-시점의-책임',
    ],
    'Q3': [
        'scenarios/camera_stop.html#stop의-상태-검사와-정상-종료',
        'scenarios/camera_stop.html#파이프라인-정지와-대기-요청-취소',
        'scenarios/camera_stop.html#버퍼별-취소-통지와-내부-정리',
        'request-lifecycle.html#정지-api-계약과-연결-해제-todo',
        'request-lifecycle.html#camerastop의-미실행오류정상-경로',
        'request-lifecycle.html#제출-큐의-선두-상태와-반환-순서',
        'request-lifecycle.html#uvc-정지의-정상-경로와-실패-경계',
        'request-lifecycle.html#uvc-정지의-정상-경로와-실패-경계-그림',
        'request-lifecycle.html#동시-제출정지지연-수신의-검증-위치',
        'request-lifecycle.html#직접-중첩-호출과-별도-queued-수신의-경계',
        'request-lifecycle.html#stop-반환과-별도-수신의-마지막-사용-확인',
    ],
}


def actual_sections(anchors, question):
    init = {'jsonrpc':'2.0', 'id':0, 'method':'initialize'}
    requests = [init]+[{'jsonrpc':'2.0','id':n,'method':'tools/call',
                       'params':{'name':'read','arguments':{'sections':[key]}}}
                      for n,key in enumerate(anchors,1)]
    payload = ''.join(json.dumps(row, ensure_ascii=False)+'\n' for row in requests).encode()
    proc = subprocess.run([sys.executable,str(root/'reader.py'),str(site),str(root/f'{question}-{phase}-review-material.jsonl')],
                          input=payload, capture_output=True, check=True)
    for raw in proc.stdout.splitlines()[1:]:
        result = json.loads(raw)['result']
        if result.get('isError'):
            raise ValueError(result)
        for row in json.loads(result['content'][0]['text'])['results']:
            yield {k: row[k] for k in ('url', 'title', 'text', 'links')}


def reader_evidence(call, question):
    seen = defaultdict(list)
    delivered = []
    access_failures = []
    trace = [json.loads(raw) for raw in (call/'navigation.jsonl').read_bytes().splitlines()]
    for raw in (call/'stdout.jsonl').read_bytes().splitlines():
        event = json.loads(raw)
        item = event.get('item',{})
        if event.get('type') != 'item.completed' or item.get('type') != 'mcp_tool_call' or item.get('tool') not in {'follow','read','route','read_public_routes','read_independent_routes'}:
            continue
        if not item.get('result') or item['result'].get('isError'):
            continue
        try:
            result = json.loads(item['result']['content'][0]['text'])
        except (KeyError, IndexError, json.JSONDecodeError):
            access_failures.append({'tool':item['tool'],'arguments':item.get('arguments')})
            continue
        if item['tool'] == 'read_independent_routes':
            groups = [json.loads(block['text']) for block in item['result']['content']]
            assert [group['end_of_route'] for group in groups] == ['END Q1','END Q2','END Q3']
            all_sources = {name:source for group in groups for name,source in group['sources'].items()}
            all_links = {name:source for group in groups for name,source in group['links'].items()}
            group, = [group for group in groups if group['question'] == question]
            delivered.extend(group['pages'])
            delivered.extend(group['shared_pages'])
            entries = []
            for name in [*group['sources'],*group['shared_sources']]:
                file,_,span = name.rpartition(':')
                first,last = map(int,span.split('-'))
                href,digest = all_links[name]
                entry = next(row for row in trace if row['event']=='follow' and row['href']==href
                             and (row['path'],row['start'],row['end'])==(file,first,last))
                assert entry['raw_sha256'] == digest
                entries.append({**entry,'code':all_sources[name]})
        elif item['tool'] == 'read_public_routes':
            route = result['routes'][question]
            delivered.extend(route['documents'])
            entries = [result['linked_code'][key] for key in route['linked_code']]
        elif item['tool'] == 'route':
            delivered.extend(entry['url'] for entry in result['documents'])
            entries = result['linked_code']
        else:
            entries = result['results'] if isinstance(result,dict) else result
        for entry in entries:
            if item['tool'] == 'read':
                delivered.append(entry['url'])
                continue
            digest, lines = get_file(entry['path'])
            assert entry['raw_sha256'] == digest and entry['github_http'] == 200
            assert entry['code'] == '\n'.join(f'{n}: {lines[n-1]}' for n in range(entry['start'],entry['end']+1))
            seen[entry['path']].append({k:entry[k] for k in ('from','href','start','end')})
    return {'sections_opened': sorted(set(delivered)), 'source_windows_delivered': seen, 'access_failures':access_failures}


combined, shared_docs, shared_windows = {}, {}, {}
with ZipFile('docs/libcamera/records/issue297/evidence.zip') as archive:
    for question in sys.argv[2:] or paths:
        lookup = 'Q1' if question == 'Q1' else 'Q2-Q3'
        key = archive.read(f'{lookup}-source-key.md').decode('utf-8-sig')
        if question == 'Q2':
            key = key.partition('\n## Q3')[0]
        if question == 'Q3':
            key = '## Q3'+key.partition('## Q3')[2]
        primary = json.loads(archive.read(f'{question}-review-windows.json'))
        if question != 'Q1':
            for path, ranges in json.loads(archive.read(f'{question}-supplement-windows.json')).items():
                primary.setdefault(path, []).extend(ranges)
        windows = []
        for path, ranges in primary.items():
            digest, lines = get_file(path)
            previous = subprocess.check_output(['git','-C',str(source),'show',f'{original}:{path}'])
            assert sha256(previous).hexdigest() == digest, path
            for first, last in sorted(set(map(tuple,ranges))):
                last = min(last, len(lines))
                assert first <= last, (path, first, last)
                windows.append(f'{path}:{first}-{last}\n'+'\n'.join(f'{n}: {lines[n-1]}' for n in range(first,last+1)))
        run = f'{question}-{phase}'
        call = root/'calls'/run
        if phase == 'baseline' and question == 'Q1':
            call = root/'calls/Q1-baseline-retry'
        if live_phase:
            call = root/'calls'/('Pages-final-retry' if phase == 'retry' else 'Pages-final')
        prompt = (root/'prompts'/f'{question}-{("final" if live_phase else phase)}.txt').read_text(encoding='utf-8')
        answer = (call/'answer.md').read_text(encoding='utf-8')
        if live_phase:
            answer = re.search(rf'(?ms)^##\s+{question}\b.*?(?=^##\s+Q[123]\b|\Z)',answer)[0]
            prompt = next(line for line in prompt.splitlines() if line.startswith(f'질문 {question}. '))
        result = {'build_id':site_manifest['build_id'],'source_commit':commit,
                  'actual_pages_sections':list(actual_sections(paths[question],question)),
                  'reader_prompt':prompt,'reader_answer':answer,
                  'reader_navigation':reader_evidence(call,question)}
        data = instructions+'\n'+key+'\n[실제 Pages, 질문, 독해 답변과 확인된 탐색]\n'+json.dumps(result,ensure_ascii=False,separators=(',',':'))
        data += '\n[공식 저장소 고정 소스 창]\n'+'\n\n'.join(windows)
        (root/'prompts'/f'{run}-review.txt').write_text(data,encoding='utf-8')
        print(run,len(data),len(result['reader_navigation']['source_windows_delivered']))
        if live_phase:
            sections = result.pop('actual_pages_sections')
            result['actual_pages_urls'] = [row['url'] for row in sections]
            for row in sections:
                row.pop('links')
                shared_docs[row['url']] = row
            for window in windows:
                name, _, content = window.partition('\n')
                shared_windows[name] = content
            combined[question] = {**result,'frozen_source_key':key}

if combined:
    guide = instructions.replace('JSON으로만 출력하세요.',
        '세 질문을 각각 판정하고, 아래 형식의 판정 세 개를 Q1, Q2, Q3 순서의 JSON 배열로만 출력하세요.')
    prompt = guide+'\n[고정 질문, 기준, 답변, 확인한 탐색]\n'+json.dumps(combined,ensure_ascii=False,separators=(',',':'))
    prompt += '\n[실제 Pages 문서와 그림]\n'+json.dumps(shared_docs,ensure_ascii=False,separators=(',',':'))
    prompt += '\n[공식 소스 창]\n'+'\n\n'.join(f'{name}\n{code}' for name,code in shared_windows.items())
    name = 'Pages-final-retry-review' if phase == 'retry' else 'Pages-final-review'
    (root/'prompts'/f'{name}.txt').write_text(prompt,encoding='utf-8')
    print('joint independent evidence review',len(prompt))
