from pathlib import Path
import json
import sys

root = Path(__file__).parent.resolve()
question, role = sys.argv[1:]
prompt_dir = root / 'prompts'
questions = {
    'Q1': '요청 제출이 성공한 뒤 언제 완료됐다고 판단하며, 버퍼는 어떤 조건에서 재사용할 수 있는가?',
    'Q2': '제출은 성공했는데 완료가 오지 않을 때, 어디부터 확인하고 어떤 관측값으로 다음 분기를 고르는가?',
    'Q3': '정지·취소 경로를 수정할 때 미완료 요청, 버퍼 수명, 콜백 순서에 어떤 위험이 있으며 무엇을 검증해야 하는가?',
}
windows = {
    'Q1': {
        'src/libcamera/camera.cpp': [(905, 919), (1240, 1277), (1307, 1380), (1430, 1489)],
        'src/libcamera/request.cpp': [(90, 170), (228, 305), (375, 404), (446, 505)],
        'src/libcamera/framebuffer.cpp': [(35, 56), (366, 394), (432, 449)],
        'src/libcamera/framebuffer_allocator.cpp': [(29, 54), (100, 143)],
        'src/libcamera/pipeline_handler.cpp': [(483, 501), (546, 617)],
        'src/libcamera/base/bound_method.cpp': [(22, 113)],
        'src/apps/cam/camera_session.cpp': [(458, 491), (536, 564)],
        'test/camera/capture.cpp': [(37, 57)],
    },
    'Q2': {
        'src/libcamera/camera.cpp': [(1307, 1380), (1474, 1489)],
        'src/libcamera/pipeline_handler.cpp': [(430, 526), (546, 617)],
        'src/libcamera/request.cpp': [(90, 170), (192, 305)],
        'src/libcamera/base/bound_method.cpp': [(22, 113)],
        'src/libcamera/base/thread.cpp': [(558, 576), (609, 689)],
        'src/libcamera/pipeline/uvcvideo/uvcvideo.cpp': [(448, 466), (893, 904)],
        'src/libcamera/v4l2_videodevice.cpp': [(1648, 1743), (1806, 1920)],
    },
    'Q3': {
        'src/libcamera/camera.cpp': [(905, 919), (1430, 1489)],
        'src/libcamera/pipeline_handler.cpp': [(358, 426), (483, 526), (546, 617)],
        'src/libcamera/request.cpp': [(90, 170), (375, 404), (446, 505)],
        'src/libcamera/base/bound_method.cpp': [(22, 113)],
        'src/libcamera/base/thread.cpp': [(558, 689)],
        'src/libcamera/pipeline/uvcvideo/uvcvideo.cpp': [(306, 330), (893, 904)],
        'src/libcamera/v4l2_videodevice.cpp': [(2000, 2068)],
        'src/apps/cam/camera_session.cpp': [(337, 373), (458, 491)],
        'test/camera/capture.cpp': [(37, 57), (118, 167)],
    },
}
bundle = (root / (question + '-reader-bundle.txt')).read_text(encoding='utf-8')
if role == 'reader':
    name = f'{question}-baseline-bundle-reader'
    instruction = f"""공개 libcamera 한국어 SDD를 처음 읽는 개발자의 과제를 수행하세요. 아래는 고정된 실제 공개 문서에서 평가 범위에 해당하는 절을 옮긴 텍스트입니다. 질문에 답하고, 문서에서 실제로 찾은 근거만 사용하세요. 다른 파일, 도구, 웹, 외부 지식은 사용하지 마세요. PAGE, 절 앵커, CODE: 링크를 근거로 기록하세요. CODE:는 공개 SDD가 연결한 소스 링크입니다. 직접 열지 못한 링크는 열었다고 쓰지 마세요. 답을 찾은 절과 그림, 찾지 못한 조건과 이유도 기록하세요. 파일을 작성하지 말고 최종 메시지로 답하세요.

질문 {question}. {questions[question]}

고정 공개 문서 발췌

"""
    prompt = instruction + bundle
elif role == 'review':
    name = f'{question}-baseline-review'
    reader = root / 'calls' / f'{question}-baseline-bundle-reader' / 'answer.md'
    key = root / ('Q1-source-key.md' if question == 'Q1' else 'Q2-Q3-source-key.md')
    key_text = key.read_text(encoding='utf-8-sig')
    if question == 'Q2':
        key_text = key_text.split('## Q3')[0]
    if question == 'Q3':
        key_text = '## Q3' + key_text.split('## Q3')[1]
    snippets = []
    for relative, ranges in windows[question].items():
        lines = (root / 'source' / relative).read_text(encoding='utf-8').splitlines()
        for start, stop in ranges:
            end = min(stop, len(lines))
            snippets.append(f'--- {relative}:{start}–{end} ---\n' + '\n'.join(
                f'{number}: {lines[number - 1]}' for number in range(start, end + 1)
            ))
    (root / f'{question}-review-windows.json').write_text(json.dumps(windows[question], indent=2) + '\n')
    instruction = f"""libcamera 공개 문서의 독립 근거 검토를 수행하세요. 제공된 고정 소스, 질문과 정답 기준, 실제 한국어 발행본 발췌, 별도 문서 읽기 응답을 대조하세요. 파일·웹·도구를 사용하지 마세요. 정답표의 진술도 틀릴 수 있으므로 소스와 반례로 확인하세요.

질문 {question}. {questions[question]}

6개 항목을 각각 충족, 부분 충족, 미충족, 해당 없음 중 하나로 판정하고, 페이지/앵커와 소스 파일/줄 근거를 적으세요. ① 직접 답변과 적용 조건 ② 정상·실패·취소 ③ 책임·소유권·수명·순서·동시성 ④ 코드 위치 및 행동 ⑤ API 계약·구현·해석·실기기 미확인 구별 ⑥ 근거 접근, 충분성 및 그림과의 일치입니다. 문서의 깊이와 읽기 평가의 실제 답을 따로 판정하세요. 인용 문장의 정확성, 근거 선택의 충분성, 질문별 그림의 기능과 내용, 평가 입력이 가린 범위를 각각 기록하세요. 필수 판단을 뒤집는 오답, 필수 조건이나 분기 누락, 실제 근거 접근 실패는 통과시킬 수 없습니다. 문서에서 링크를 추적할 수 있는지와 실행 중 실제로 연 근거를 구분하세요. 문서의 필수 보완이 필요하면 한 가지 최소 범위로 특정하고, 자료 투영 때문에 평가가 막힌 경우 그 사실을 문서 결함과 구분하세요. 사람 또는 실기기 평가를 추정하지 마세요.

고정 정답 기준
"""
    prompt = instruction + key_text + '\n\n공식 소스 창\n' + '\n'.join(snippets)
    prompt += '\n\n실제 읽기 답변\n' + reader.read_text(encoding='utf-8')
    prompt += '\n\n고정 공개 문서 발췌\n' + bundle
else:
    raise SystemExit('Unsupported role')
target = prompt_dir / (name + '.txt')
target.write_text(prompt, encoding='utf-8')
print(name, target.stat().st_size)
