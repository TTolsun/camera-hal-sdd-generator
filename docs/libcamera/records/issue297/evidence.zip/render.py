from pathlib import Path
import hashlib
import json
import sys
from urllib.parse import urljoin
from bs4 import BeautifulSoup

root = Path(__file__).parent
manifest = json.loads((root / 'live-manifest.json').read_bytes())
url = 'https://ttolsun.github.io/libcamera-sdd/'
output = root / 'rendered'
output.mkdir(exist_ok=True)
for path in sorted((root / 'baseline').rglob('*.html')):
    page = path.relative_to(root / 'baseline').as_posix()
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != manifest['outputs'][page]:
        raise SystemExit(f'Hash mismatch: {page}')
    soup = BeautifulSoup(raw, 'html.parser')
    main = soup.select_one('main')
    for tag in main.select('script, style, button, svg'):
        tag.decompose()
    for a in main.select('a[href]'):
        dest = urljoin(url + page, a['href'])
        if a.get_text(strip=True):
            a.append(' [' + dest + ']')
    for heading in main.select('h1, h2, h3, h4, h5, h6'):
        text = heading.get_text(' ', strip=True)
        link = f' [{url}{page}#{heading["id"]}]' if heading.get('id') else ''
        heading.string = '\n' + '#' * int(heading.name[1:]) + ' ' + text + link + '\n'
    for pre in main.select('pre'):
        pre.string = '\n' + pre.get_text() + '\n'
    article = main.select_one('article')
    if article is None:
        article = main
    target = (output / page).with_suffix('.txt')
    target.parent.mkdir(exist_ok=True, parents=True)
    def clean(soup):
        return '\n'.join(line.strip() for line in soup.get_text('\n', strip=True).splitlines() if line.strip())
    target.write_text(clean(article) + '\n', encoding='utf-8')
    print(page, target.stat().st_size, 'article bytes', len(article.select('pre.mermaid')), 'diagrams')
