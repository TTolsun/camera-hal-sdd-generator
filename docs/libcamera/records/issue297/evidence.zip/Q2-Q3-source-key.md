# #297 소스 정답 기준

공식 소스 c19d05128f3ae1f0ebe63acb4deaca9fbb1dde78 기준입니다. 실기기에서 관측한 지연이나 원인으로 추정하지 않습니다.

## Q2

1. `Camera::queueRequest()` 0은 `ConnectionTypeQueued` 요청 전달 성공입니다. 같은 요청을 포인터뿐 아니라 제출 회차로 구분하고, `PipelineHandler::queueRequest` 진입 여부부터 확인합니다. 진입하지 않았으면 파이프라인 수신 스레드의 메시지·dispatch 경계를 조사합니다. (camera.cpp 1307–1380, base/bound_method.cpp 68–113, base/thread.cpp 558–576, 609–689)
2. `waitingRequests_.front()->prepared_`, `queuedRequests_.size()`와 `maxQueuedRequestsDevice_`를 봅니다. 미준비 선두와 한도 도달을 구분합니다. `prepare`의 fence, notifier, timer, 준비 신호와 timeout 취소를 추적합니다. 구현의 300ms는 준비 timeout 호출 인자입니다. end-to-end 완료 시간이나 기기 지연 기준으로 일반화하지 않습니다. (pipeline_handler.cpp 430–526, request.cpp 192–305)
3. `doQueueRequest`에서 이미 취소되어 장치 함수로 가지 않는 경우와 `queueRequestDevice`의 0/실패를 구별합니다. 공개 UVC 예에서는 제어 설정, QBUF 전과 ioctl 반환, 버퍼 준비 알림 이후의 경계를 좁힙니다. 공통 경로와 UVC 사례의 범위를 구분합니다. (pipeline_handler.cpp 483–501; uvcvideo.cpp 448–466, 893–904; v4l2_videodevice.cpp 1648–1743, 1806–1868)
4. `bufferCompleted`를 받아도 `completeRequest`의 명시적 호출이 필요합니다. 요청이 완료 상태인데 앞선 요청이 Pending이면 FIFO 반환 대기를 확인합니다. 카메라가 `requestCompleted`를 emit했다면 Direct/Queued/Auto와 수신자의 dispatch/수명으로 조사 경계를 이동합니다. (pipeline_handler.cpp 546–617, request.cpp 90–170, camera.cpp 1474–1489, base/bound_method.cpp 22–113)
5. 각 갈림길에 실제 함수, 관측값, 다음 행동이 있어야 합니다. 실제 로그나 추적 수집 결과를 가정하지 않으며 문서가 주장하는 기존 tracepoint/로그가 있다면 원본과 대조합니다. 그림에서 진입, 준비, 장치 전달, 반환 경계가 본문과 맞는지 확인합니다.

## Q3

1. `Camera::stop`의 공개 계약은 실행 중 촬영·처리를 중단하고 pending을 동기 취소·오류 완료하는 것입니다. 호출자는 카메라 상태를 바꾸는 호출을 동기화합니다. 소스에서는 비실행 경로, 접근 실패, 정상 Stopping → Blocking 파이프라인 stop → pending 검사 → Configured를 구분합니다. Blocking은 같은 스레드에서 Direct로 실행될 수 있습니다. 연결 해제와 정상 stop을 구분하며 모든 사용자 콜백이 반환 전에 끝났다고 가정하지 않습니다. (camera.cpp 1430–1489, base/bound_method.cpp 22–113)
2. 공통 stop에서 waitingRequests_를 분리한 이유는 stopDevice 내 completeRequest가 doQueueRequests를 다시 부를 수 있기 때문입니다. 장치 요청을 먼저 완료한 뒤 분리한 대기 요청을 취소하고 doQueueRequest에서 순번과 큐 처리를 거칩니다. 끝에 두 큐를 검사하고 순번을 초기화합니다. 취소에서는 버퍼 알림·상태·내부 정리와 전체 요청 반환을 구별하며, 정상 completeBuffer의 내부 갱신을 취소 경로에 그대로 적용하지 않습니다. (pipeline_handler.cpp 358–426, 483–526, 546–617; request.cpp 90–170)
3. UVC 예에서 streamOff/releaseBuffers와 버퍼 콜백을 추적합니다. streamOff의 성공·실패 뒤 정리와 미완료 위험을 구분합니다. 다른 구현의 행동으로 일반화하지 않습니다. (uvcvideo.cpp 306–330, 893–904; v4l2_videodevice.cpp 2000–2068)
4. 직접 콜백은 현재 호출에 중첩될 수 있고 지연 연결은 포인터 전달 뒤 별도 dispatch입니다. stop 반환과 애플리케이션 마지막 사용, 요청/버퍼 파괴·재사용 시점을 구분합니다. 큐에 저장된 포인터의 수명은 앱이 관리합니다. 완료 상태와 submit order 반환, 중복 완료·누락·재진입·늦은 접근을 구분합니다. (request.cpp 375–404, 446–505; base/bound_method.cpp 22–113, base/thread.cpp 558–689; pipeline_handler.cpp 570–617; cam/camera_session.cpp 337–373, 458–491)
5. 재현 계획에 대기/장치 양쪽의 미완료 요청, 동일 회차당 버퍼·요청 콜백 횟수와 순서, stop 후 큐/상태, 직접/지연 수신, 마지막 사용과 해제, 장치 정지 실패 또는 동시 제출 조건을 포함해야 합니다. 코드에서 증명되는 계약, 논리적 위험, 실기기 검증을 구분합니다. 그림에서 대기·장치 정지 순서와 지연 수신의 위치가 본문과 일치해야 합니다.
