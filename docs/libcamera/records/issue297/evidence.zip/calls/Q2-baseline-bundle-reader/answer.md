**먼저 원래 `Camera::queueRequest()` 호출의 반환값과 호출 위치를 기록하고, 같은 요청이 어느 경계까지 진행했는지 확인합니다.** 반환값 0은 파이프라인 호출을 비동기로 예약한 성공이지 촬영 완료가 아닙니다. 아래 값들은 문서가 제안한 **관측 항목**이며, 제공된 발췌에는 이번 사례의 실행 결과가 없습니다.

1. **파이프라인에 진입했는지 확인합니다.** 요청의 cookie·sequence 등으로 기록을 연결하고, 원래 호출의 0 반환과 `PipelineHandler::queueRequest()` 진입을 각각 기록합니다. 0을 받았지만 진입하지 않았다면 준비 대기부터 추정하지 말고, `ConnectionTypeQueued` 메시지의 대상 객체와 스레드, 메시지 소비·이벤트 루프 진행을 확인합니다. 전달한 `Request` 포인터는 실제 호출까지 유효해야 합니다.  
   근거: PAGE `request-diagnosis.html#실패-위치별-확인-순서`, PAGE `request-lifecycle.html#준비-대기와-재진입을-좁히기`, `CODE:src/libcamera/camera.cpp#L1308`, `CODE:src/libcamera/base/object.cpp#L258`, `CODE:src/libcamera/base/thread.cpp#L558`.

2. **진입했다면 대기열의 두 중단 조건을 구분합니다.** `waitingRequests_`에 요청이 있는 동안 `queuedRequests_.size()`와 `maxQueuedRequestsDevice_`를 기록합니다. 두 값이 **같으면** 전달 반복이 중단됩니다. 같지 않으면 대기열 선두의 `prepared_`를 확인합니다. 거짓이면 선두에서 멈추고, 참이면 선두를 먼저 pop한 뒤 `doQueueRequest()`로 전달합니다. 크기가 한도를 넘지 않는다는 조건은 별도로 확인해야 합니다.  
   `prepared_`가 거짓이면 남은 fence와 `notifiers_`, `notifierActivated()`·`timeout()` 진입을 봅니다. 타임아웃은 취소 후 준비 완료를 알릴 수 있으므로 `prepared_ == true`만으로 준비 성공이라고 판정하지 않습니다. 300ms도 촬영 완료 시간의 보장이 아닙니다.  
   근거: PAGE `request-lifecycle.html#선두-요청을-전달하거나-반복을-멈추는-조건`의 그림, PAGE `request-lifecycle.html#준비-대기와-재진입을-좁히기-그림`, `CODE:src/libcamera/pipeline_handler.cpp#L516`, `CODE:src/libcamera/request.cpp#L192`.

3. **전달됐다면 취소와 장치 제출을 나눕니다.** `doQueueRequest()`에서 `cancelled_`가 참이면 장치 제출을 건너뛰고 `completeRequest()`로 갑니다. 거짓이면 기존 `queueRequestDevice()` 호출의 반환값을 봅니다. 0이 아니면 호출자가 `cancelRequest()`를 호출하는 분기를 확인합니다.  
   **UVC인 경우에 한해**, 스트림 버퍼 유무, `processControls()`와 `queueBuffer()` 반환값, QBUF 성공 및 `queuedBuffers_` 등록을 차례로 확인합니다. QBUF 성공·등록 후에도 별도의 장치 완료 이벤트가 필요합니다. `bufferAvailable()`에 도달했다면 DQBUF 반환과 인덱스를 확인합니다. DQBUF 오류나 예상 밖 인덱스에서는 그 호출이 `bufferReady` 없이 반환합니다. 이 한 번의 알림 부재만으로 영구 정지라고 결론 내리지는 않습니다.  
   근거: PAGE `request-diagnosis.html#실패-위치별-확인-순서`, PAGE `request-lifecycle.html#uvc의-장치-제출과-완료를-추적하기-그림`, `CODE:src/libcamera/pipeline_handler.cpp#L483`, `CODE:src/libcamera/pipeline/uvcvideo/uvcvideo.cpp#L448`, `CODE:src/libcamera/v4l2_videodevice.cpp#L1648`, `CODE:src/libcamera/v4l2_videodevice.cpp#L1814`.

4. **버퍼 완료 이후 요청 완료가 막혔는지 확인합니다.** `bufferCompleted` 발생, `completeBuffer()` 반환값과 요청의 `pending_`을 구분해 기록합니다. 마지막 버퍼가 끝나도 요청은 자동 완료되지 않으므로 핸들러의 `completeRequest()` 호출도 확인합니다. 이후 `queuedRequests_` **선두의** `status()`가 `RequestPending`이면 반환 반복이 멈춰 뒤에서 이미 완료된 요청의 통지도 지연될 수 있습니다. 선두가 Pending이 아니면 대기 버퍼가 없는지 검사하고 꺼낸 뒤 `Camera::requestComplete()`로 전달합니다.  
   근거: PAGE `request-lifecycle.html#버퍼-알림과-요청-반환의-내부-경계-그림`, PAGE `request-lifecycle.html#제출-큐의-선두-상태와-반환-순서`의 그림, `CODE:src/libcamera/request.cpp#L103`, `CODE:src/libcamera/pipeline_handler.cpp#L571`, `CODE:src/libcamera/camera.cpp#L1475`.

5. **신호와 실제 앱 콜백을 별도로 확인합니다.** `Camera::requestComplete()`의 상태 검사와 `requestCompleted` 발생, 특정 수신자의 콜백 진입·복귀를 각각 기록합니다. Queued 수신이라면 연결 종류, 수신 객체의 유효성, 수신 스레드와 메시지 소비 진행을 확인합니다. 신호 발생만으로 해당 수신자가 실행됐다고 단정할 수 없습니다. 정지와 겹쳤다면 제출 게시·실행, 정지 상태 변경, 완료 상태 검사의 순서도 기록합니다.  
   근거: PAGE `request-lifecycle.html#콜백의-스레드와-재진입을-구분하기`, PAGE `request-lifecycle.html#준비-대기와-재진입을-좁히기`, `CODE:src/libcamera/base/bound_method.cpp#L68`, `CODE:src/libcamera/base/thread.cpp#L613`, `CODE:src/libcamera/camera.cpp#L1431`.

조사 중에는 요청 완료 콜백까지 버퍼를 유효하게 유지하고, 지연된 수신자의 포인터 사용도 따로 추적해야 합니다. 제보, 직접 관측값, 문서에 따른 해석, 미확인 사항과 다음 분기를 분리해 기록합니다. 관측을 위해 상태 변경 함수를 다시 호출하지 않습니다. 근거: PAGE `request-diagnosis.html#실패-위치별-확인-순서`, `CODE:src/libcamera/request.cpp#L442`.

**찾지 못한 조건:** 실제 요청 식별자, 파이프라인 진입 여부, 큐 크기·선두 상태, fence·장치 이벤트, 완료 신호와 콜백 실행값은 발췌에 없습니다. 따라서 어느 분기가 실제 원인인지는 정할 수 없습니다. 해당 그림은 문서의 소스 연결 설계 해석이며 기기 실행 검증이 아닙니다. 위 `CODE:`는 문서가 연결한 근거 위치로 기록한 것이며, 제공된 고정 발췌 외에 링크를 직접 열어 확인하지 않았습니다.
