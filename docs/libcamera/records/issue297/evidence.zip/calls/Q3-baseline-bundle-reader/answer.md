정지·취소 경로를 수정할 때의 핵심 위험은 **요청이 내부적으로 완료되는 시점, 애플리케이션에 반환되는 시점, 별도 수신자가 포인터를 마지막으로 사용하는 시점이 서로 다르다**는 점입니다. 정상 정지 계약과 장치 오류·연결 해제 경로도 나누어 검증해야 합니다.

### 미완료 요청과 취소

- `PipelineHandler::stop()`의 계약은 모든 미완료 요청을 취소하고 오류 상태로 즉시 완료하는 것입니다. 정상 경로에서는 `waitingRequests_`를 분리해 `stopDevice()` 중 완료 콜백이 대기 요청을 다시 큐에 넣지 못하게 합니다. 그 뒤 분리된 요청을 순서대로 `cancel()`하고 `doQueueRequest()`에 넘겨 순번을 부여하고 완료합니다. 이 분리나 순서를 바꾸면 재투입 또는 완료 누락·중복 위험을 조사해야 합니다.  
  **근거:** PAGE `scenarios/camera_stop.html#장치-종료-뒤-대기-요청을-취소하는-순서`, 그림 `scenarios/camera_stop.pipeline-stop-waiting-cancellation.mmd`; [CODE:src/libcamera/pipeline_handler.cpp#L359].

- 취소는 각 pending 버퍼를 취소하고 `bufferCompleted`를 낸 **뒤** `cancelled_`를 설정하고 pending 등을 정리합니다. 일반 `cancelRequest()`는 그다음 `completeRequest()`를 호출합니다. 콜백이 취소 처리 도중 실행될 수 있으므로, 변경 시 콜백이 보는 상태와 재진입을 확인해야 합니다.  
  **근거:** PAGE `scenarios/camera_stop.html#버퍼별-취소-통지와-내부-정리`, 그림 `scenarios/camera_stop.pending-buffer-cancellation.mmd`; [CODE:src/libcamera/request.cpp#L139], [CODE:src/libcamera/pipeline_handler.cpp#L610].

- 연결 해제는 정상 stop과 별도입니다. 실행 중 연결 해제 시 대기 요청 처리는 TODO로 남아 있습니다. 문서에 설명된 조건에서는 연결 해제 후 `stop()`이 실행 중이 아니라고 판단해 공통 stop을 호출하지 않을 수 있고, 잔여 요청이 나중에 완료 경로에 진입하면 상태 검사에서 Fatal 분기에 들어갈 수 있습니다.  
  **근거:** PAGE `request-lifecycle.html#정지와-연결-해제를-구분하기`, `request-lifecycle.html#uvc-정지의-정상-경로와-실패-경계`; [CODE:src/libcamera/camera.cpp#L1431], [CODE:src/libcamera/camera.cpp#L709].

### 버퍼와 요청의 수명

- 마지막 `bufferCompleted`가 요청 완료를 뜻하지는 않습니다. 정상 경로에서 각 버퍼는 `completeBuffer()`로 정확히 한 번 완료해야 하며, 마지막 버퍼 이후에도 `completeRequest()`를 명시적으로 호출해야 합니다. 호출자는 **요청 완료 콜백까지 버퍼를 유효하게 유지**해야 합니다. 마지막 버퍼 알림만 보고 해제나 다른 요청에 연결하는 작업이 안전하다고 판단할 수 없습니다.  
  **근거:** PAGE `request-lifecycle.html#요청버퍼fence의-수명`, `#정상-완료와-다음-요청-준비`; 그림 `request-lifecycle.completion-notification-order.mmd`; [CODE:src/libcamera/request.cpp#L447], [CODE:src/libcamera/request.cpp#L91], [CODE:src/libcamera/pipeline_handler.cpp#L547].

- 파이프라인 핸들러는 `completeRequest()` 또는 `cancelRequest()`가 반환된 뒤 해당 요청에 접근하면 안 됩니다. 반면 요청 소유자는 별도의 지연 수신자까지 고려해야 합니다. `FrameBuffer::request()`로 얻은 포인터의 유효 기간도 버퍼 완료까지만입니다.  
  **근거:** PAGE `request-lifecycle.html#소유권과-두-완료-경계`, `#변경-검토와-실행-확인`; [CODE:src/libcamera/pipeline_handler.cpp#L575], [CODE:src/libcamera/pipeline_handler.cpp#L610], [CODE:src/libcamera/framebuffer.cpp#L368].

- 신호되지 않은 fence로 타임아웃이 나면 fence는 버퍼에 남습니다. 다른 요청에서 버퍼를 재사용하기 전에 `releaseFence()`로 회수해야 합니다. 문서는 fence를 사용하는 경우 `ReuseBuffers`를 사용하지 말 것을 권고합니다.  
  **근거:** PAGE `request-lifecycle.html#알림-순서와-취소가-달라질-때`, 그림 `request-lifecycle.lifecycle-timeout-fence-recovery.mmd`, `request-lifecycle.lifecycle-reuse-buffer-fence-distinction.mmd`; [CODE:src/libcamera/request.cpp#L456].

### 완료와 콜백 순서

`completeRequest(B)`가 먼저 호출돼도 제출 큐의 앞선 A가 `RequestPending`이면 B의 애플리케이션 통지는 지연됩니다. A와 B가 반환 가능한 상태가 되고 카메라 상태 검사도 허용되면 제출 순서대로 통지됩니다. 따라서 **완료 함수 호출 순서와 실제 콜백 실행 순서를 같은 것으로 취급하면 안 됩니다.**  
**근거:** PAGE `request-lifecycle.html#알림-순서와-취소가-달라질-때`, 그림 `request-lifecycle.completed-but-not-returned.mmd`; [CODE:src/libcamera/pipeline_handler.cpp#L575].

또한 `Camera::stop()`의 정상 경로에서 Blocking 호출이 반환되더라도 별도 `Queued` 수신자의 마지막 포인터 사용이 끝났다는 보장은 없습니다. Queued 실행은 비동기이며 수신 스레드의 메시지 소비에 의존합니다. 다른 스레드의 수신은 `Signal::emit()` 반환 전에도 시작될 수 있고, Direct 연결은 즉시 중첩 호출될 수 있습니다. 따라서 요청 소유자와 발신자는 **각 지연 수신자의 마지막 사용을 동기화한 뒤** 삭제하거나 재사용해야 합니다.  
**근거:** PAGE `request-lifecycle.html#콜백의-스레드와-재진입을-구분하기`, `#stop-반환과-별도-수신의-마지막-사용-확인`; 그림 `request-lifecycle.stop-lifetime-flow.mmd`; [CODE:src/libcamera/base/bound_method.cpp#L68], [CODE:src/libcamera/base/signal.cpp#L73], [CODE:src/libcamera/base/thread.cpp#L613].

### 변경 후 검증할 사항

1. **정상 정지와 취소:** 준비 대기 요청과 장치에 대기 중인 요청을 섞어 정지합니다. 요청별 sequence·cookie·상태와 버퍼별 완료 횟수, `completeRequest()` 진입·반환, 요청 통지 순서를 기록합니다. `pending_`, `queuedRequests_`, `waitingRequests_`의 잔존과 정지 중 재투입도 확인합니다. ASSERT가 컴파일에서 제외될 수 있으므로 ASSERT 통과만을 큐가 비었다는 실행 증거로 삼지 않습니다.
2. **수명과 스레드:** `completeBuffer()`와 `completeRequest()`가 CameraManager 스레드에서 호출되는지, 핸들러가 반환 후 요청에 접근하지 않는지 확인합니다. Direct와 Queued 연결별 콜백 진입·복귀, 수신 스레드의 메시지 소비, 포인터·참조의 마지막 사용 및 삭제·재사용 시점을 기록합니다. `stop()`과 다른 카메라 상태 변경 호출도 동기화합니다.
3. **실패와 연결 해제:** `VIDIOC_STREAMOFF`와 `releaseBuffers()` 실패를 각각 주입하고 반환값, 큐·cache·notifier 상태, 버퍼와 요청의 완료 여부를 관찰합니다. UVC에서는 `streamOff()`의 반환값을 검사하지 않고 `releaseBuffers()`를 호출하므로, STREAMOFF 실패 후 잔존 notifier와 큐, reset된 cache가 겹치는 조건에서 후속 DQBUF가 안전한지도 조사합니다. 연결 해제 시점의 상태와 잔여 요청의 후속 완료 경로도 별도로 기록합니다.  
   **근거:** PAGE `request-lifecycle.html#변경-검토와-실행-확인`, 그림 `request-lifecycle.concurrent-stop-and-queued-lifetime-review.mmd`, `request-lifecycle.failure-investigation-flow.mmd`; PAGE `request-lifecycle.html#uvc-정지의-정상-경로와-실패-경계`, 그림 `request-lifecycle.stop-depth-flow.mmd`; [CODE:src/libcamera/pipeline/uvcvideo/uvcvideo.cpp#L320], [CODE:src/libcamera/v4l2_videodevice.cpp#L2023], [CODE:src/libcamera/v4l2_videodevice.cpp#L1616].

위 검증 항목은 **문서가 제시한 조사 계획**입니다. 발췌만으로는 실제 제품의 콜백 실행 스레드와 순서, 이벤트 루프 진행, 장치 정지·DMA·캐시 동작, 실패 주입 결과 또는 사내 HAL의 동작을 확인할 수 없습니다. 그림 역시 문서가 밝힌 대로 소스에 연결한 설계 해석이며 기기 실행 검증 결과가 아닙니다. 여기서 기록한 `CODE:` 링크는 문서가 연결한 소스 위치이고, 별도로 열어 확인하지 않았습니다.
