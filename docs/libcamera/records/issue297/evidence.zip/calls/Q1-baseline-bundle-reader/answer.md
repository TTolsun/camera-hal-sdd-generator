**제출 성공은 요청 완료가 아닙니다.** `queueRequest()`가 0을 반환하면 파이프라인 호출이 비동기로 예약된 것입니다. 애플리케이션에서는 별도의 `requestCompleted` 신호에 따른 요청 완료 콜백을 확인해야 합니다. 완료 통지에는 취소된 요청도 포함될 수 있으므로, 촬영이 정상 완료됐는지는 요청 상태가 `RequestComplete`인지 `RequestCancelled`인지 구분해야 합니다.

마지막 버퍼의 완료도 요청 완료와는 다릅니다. `completeBuffer()`가 모든 버퍼 완료를 뜻하는 `true`를 반환해도 요청이 자동 완료되지는 않습니다. 핸들러가 필요한 처리를 마친 뒤 `completeRequest()`를 명시적으로 호출해야 합니다. 완료된 요청은 제출 순서대로 반환되므로 앞선 요청이 아직 대기 중이면 완료 통지가 지연될 수 있습니다.

- 근거: PAGE `request-lifecycle.html`의 [제출에서 완료까지](request-lifecycle.html#제출에서-완료까지), [접수 반환과 완료 알림](request-lifecycle.html#접수-반환과-완료-알림) 그림, [버퍼 완료와 명시적 요청 완료의 경계](request-lifecycle.html#버퍼-완료와-명시적-요청-완료의-경계) 그림. 문서가 연결한 소스: [CODE:src/libcamera/camera.cpp#L1308](CODE:src/libcamera/camera.cpp#L1308), [CODE:src/libcamera/pipeline_handler.cpp#L547](CODE:src/libcamera/pipeline_handler.cpp#L547), [CODE:src/libcamera/pipeline_handler.cpp#L571](CODE:src/libcamera/pipeline_handler.cpp#L571).

**버퍼 재사용은 유효기간과 적용되는 동기화 조건을 함께 확인해야 합니다.** `addBuffer()` 호출자는 적어도 요청 완료 콜백이 호출될 때까지 버퍼를 유효하게 유지해야 합니다. 마지막 `bufferCompleted` 알림만으로는 그 기한이 끝났거나 다른 요청에 연결해도 안전하다고 판단할 수 없습니다. 그렇다고 그 전의 모든 재사용이 일괄 금지된다는 뜻도 아닙니다. 적용되는 API와 동기화 계약을 별도로 대조해야 합니다. 별도의 Queued 수신자가 버퍼나 전달된 포인터를 계속 사용할 수 있다면, 그 수신자들의 마지막 사용도 추적하고 동기화해야 합니다.

- 펜스가 신호되지 않아 요청이 타임아웃되면 펜스가 버퍼에 남습니다. 다른 요청에 버퍼를 재사용하기 전에 `FrameBuffer::releaseFence()`로 회수해야 합니다. 회수는 필요한 선행 조건이며, 그것만으로 다른 모든 재사용 조건이 충족된다고 단정할 수는 없습니다.
- 완료된 요청 자체는 `Request::reuse()`로 초기화해 재사용할 수 있습니다. `ReuseBuffers`는 이전 버퍼를 유지하지만 연결된 펜스는 재사용하지 않으므로, 문서는 펜스를 사용할 때 이 플래그를 쓰지 않도록 권고합니다.
- `FrameBufferAllocator`가 제공한 버퍼라면 같은 스트림에 `free()`가 호출되거나 allocator가 파괴되기 전까지 유효합니다. 따라서 요청과 수신자의 사용이 끝나기 전에 그 유효기간을 끊지 않아야 합니다.

근거: PAGE `request-lifecycle.html`의 [정상 완료와 다음 요청 준비](request-lifecycle.html#정상-완료와-다음-요청-준비), [타임아웃 뒤 펜스 회수](request-lifecycle.html#타임아웃-뒤-펜스-회수) 그림, [Queued 수신과 해제 시점의 책임](request-lifecycle.html#queued-수신과-해제-시점의-책임) 그림; PAGE `camera-requests.html`의 [소유권과 재사용](camera-requests.html#소유권과-재사용); PAGE `framebuffer-allocator.html`의 [buffers 반환 참조의 유효기간](framebuffer-allocator.html#buffers-반환-참조의-유효기간). 문서가 연결한 소스: [CODE:src/libcamera/request.cpp#L442](CODE:src/libcamera/request.cpp#L442), [CODE:src/libcamera/request.cpp#L462](CODE:src/libcamera/request.cpp#L462), [CODE:src/libcamera/request.cpp#L326](CODE:src/libcamera/request.cpp#L326), [CODE:src/libcamera/base/signal.cpp#L73](CODE:src/libcamera/base/signal.cpp#L73), [CODE:src/libcamera/framebuffer_allocator.cpp#L141](CODE:src/libcamera/framebuffer_allocator.cpp#L141).

제공된 발췌에서는 **특정 애플리케이션에서 모든 수신자가 사용을 마쳤는지**, 실제 콜백이 어느 스레드에서 실행됐는지, 기기 DMA나 캐시 처리가 끝났는지를 확인할 수 없습니다. 문서의 관련 항목은 실행 결과가 아닌 조사·검증 계획이기 때문입니다. 위 그림들도 소스에 연결한 설계 해석이며 기기 실행 검증 결과는 아닙니다. `CODE:` 링크는 발췌에 기재된 연결을 기록한 것이며 직접 열어 확인하지 않았습니다.
