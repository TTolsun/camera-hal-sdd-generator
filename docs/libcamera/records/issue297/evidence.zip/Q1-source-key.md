# 소스 정답 기준

공식 소스 c19d05128f3ae1f0ebe63acb4deaca9fbb1dde78 기준입니다. 괄호 안 경로의 줄 번호는 별도 검토 입력에 제공한 원본 줄 번호입니다.

## Q1

1. 필수. Running 상태에서 제출 성공 0은 검사를 통과해 파이프라인 메서드를 Queued로 넘겼다는 뜻입니다. 요청 단위 완료는 requestCompleted 수신으로 판정합니다. 앞선 요청이 Pending이면 뒤의 terminal 상태도 앱 반환을 기다립니다. (camera.cpp 1307–1380, 1474–1489, pipeline_handler.cpp 546–617)
2. 필수. 버퍼 단위 bufferCompleted와 요청 완료가 다릅니다. 정상 구현은 버퍼 신호를 먼저 emit하고 pending과 역참조를 갱신하며, 마지막 버퍼 뒤에도 핸들러가 completeRequest를 명시적으로 호출합니다. 상태 RequestComplete/RequestCancelled와 버퍼 FrameSuccess/FrameError/FrameCancelled는 층위가 다릅니다. RequestComplete만으로 각 버퍼의 픽셀 데이터 유효성을 확정할 수 없습니다. 취소·실패 후 재사용과 실패 결과 읽기를 구분합니다. (request.cpp 90–170, framebuffer.cpp 29–76, 366–408)
3. 필수. 요청은 앱이 관리하며 addBuffer는 버퍼 참조를 보관합니다. bufferCompleted와 stop 반환만으로 앱의 마지막 사용을 확정할 수 없습니다. requestCompleted와 남아 있는 앱 수신자·외부 소비자의 마지막 사용을 확인한 뒤 재사용·해제합니다. 큐의 raw 포인터 전달은 소유권·수명 연장 계약이 아닙니다. 정상 경로의 직접/지연 수신은 구현과 연결 유형으로 설명하고 플랫폼별 DMA 동기화는 미검증으로 둡니다. (camera.cpp 907–919, 1240–1277; request.cpp 375–404, 446–505; framebuffer_allocator.cpp 29–54; bound_method.cpp 22–113; cam/camera_session.cpp 458–491, 536–564)
4. 필수. ReuseBuffers는 버퍼 맵을 유지하고 RequestPending으로 재설정합니다. 옵션 없는 reuse는 맵을 비우므로 버퍼를 다시 붙입니다. fence timeout 후 남은 fence가 있다면 releaseFence로 회수한 뒤 재사용합니다. addBuffer는 남은 fence를 -EEXIST로 거부하며 ReuseBuffers가 fence를 회수해 주지는 않습니다. fence 없는 일반 완료에 releaseFence를 필수로 만들지 않습니다. (request.cpp 228–302, 375–404, 446–505; framebuffer.cpp 432–449)
5. 코드 위치·앵커를 찾을 수 있어야 하고, 소스 계약과 실행 미검증의 경계를 남겨야 합니다. 적어도 완료·반환과 소유권·재사용 그림의 주된 흐름, 예외 설명과 실제 코드가 맞아야 합니다. 직접 연결과 지연 연결에서 콜백 순서 보장을 일반화하면 필수 오답입니다. 노드 수는 판정 근거에서 제외합니다.
