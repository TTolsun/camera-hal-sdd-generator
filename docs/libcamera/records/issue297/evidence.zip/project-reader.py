from pathlib import Path
import hashlib
import json
import re
import sys
from urllib.parse import unquote, urljoin

from bs4 import BeautifulSoup

root = Path(__file__).parent.resolve()
manifest = json.loads((root / 'live-manifest.json').read_bytes())
base = 'https://ttolsun.github.io/libcamera-sdd/'
source = 'https://github.com/TTolsun/libcamera-sdd/blob/c19d05128f3ae1f0ebe63acb4deaca9fbb1dde78/'
selection = {
    'Q1': {'index.html': (), 'request-lifecycle.html': ('제출에서 완료까지','요청·버퍼·fence의 수명','콜백의 스레드와 재진입을 구분하기'), 'camera-requests.html': ('요청 생성과 완료','소유권과 재사용'), 'framebuffer-allocator.html': ('*',)},
    'Q2': {'index.html': (), 'request-lifecycle.html': ('제출에서 완료까지','준비 대기와 재진입을 좁히기','UVC의 장치 제출과 완료를 추적하기','버퍼 알림과 요청 반환의 내부 경계','콜백의 스레드와 재진입을 구분하기','변경 검토와 실행 확인'), 'request-diagnosis.html': ('실패 위치별 확인 순서',)},
    'Q3': {'index.html': (), 'request-lifecycle.html': ('요청·버퍼·fence의 수명','콜백의 스레드와 재진입을 구분하기','정지와 연결 해제를 구분하기','UVC 정지의 정상 경로와 실패 경계','변경 검토와 실행 확인'), 'scenarios/camera_stop.html': ('캡처를 멈추는 호출과 상태 전제','장치 종료 뒤 대기 요청을 취소하는 순서')},
}
figures = {
    'Q1': {'접수 반환과 완료 알림','버퍼 완료와 명시적 요청 완료의 경계','소유권과 두 완료 경계','정상 완료와 다음 요청 준비','타임아웃 뒤 펜스 회수','Queued 수신과 해제 시점의 책임'},
    'Q2': {'선두 요청을 전달하거나 반복을 멈추는 조건','준비 대기와 재진입을 좁히기 그림','UVC의 장치 제출과 완료를 추적하기 그림','버퍼 알림과 요청 반환의 내부 경계 그림','제출 큐의 선두 상태와 반환 순서'},
    'Q3': {'정지할 때 대기 요청을 처리하는 순서','UVC 정지의 정상 경로와 실패 경계 그림','버퍼별 취소 통지와 내부 정리','stop 반환과 별도 수신의 마지막 사용 확인','파이프라인 정지와 대기 요청 취소'},
}
question = sys.argv[1]
bundle = []
for page, selected in selection[question].items():
    raw = (root / 'baseline' / page).read_bytes()
    if hashlib.sha256(raw).hexdigest() != manifest['outputs'][page]:
        raise SystemExit(f'Hash mismatch: {page}')
    soup = BeautifulSoup(raw, 'html.parser')
    article = soup.select_one('article') or soup.select_one('main')
    parts = [f'PAGE {page} ({soup.title.get_text(strip=True)})']
    keep = True
    heading = ''
    for node in article.find_all(recursive=False):
        text = node.get_text(' ', strip=True)
        if node.name == 'h2':
            keep = (text in selected or '*' in selected) and text not in {'소스 근거','클래스 관계','관련 클래스'}
        if node.name in {'h2','h3','h4'}:
            heading = text
            if keep or node.name == 'h2':
                parts.append(f'{node.name.upper()} {text} #{node.get("id", "")}')
            continue
        if not keep or node.name == 'div' or not text:
            continue
        if node.name == 'pre' and heading not in figures[question]:
            continue
        if node.name == 'details':
            classes = node.get('class', [])
            if 'evidence-section' not in classes and (heading not in figures[question] or node.select_one('pre')):
                continue
        for a in node.select('a[href]'):
            dest = unquote(urljoin(base + page, a['href']))
            if dest.startswith(base):
                dest = dest[len(base):]
            elif dest.startswith(source):
                dest = 'CODE:' + dest[len(source):]
            if dest not in a.get_text():
                a.append(' [' + dest + ']')
        if node.name == 'pre':
            parts.append(node.get_text().strip())
        else:
            parts.append(re.sub(r'[ \t]+', ' ', node.get_text(' ', strip=True)))
    bundle.append('\n'.join(parts))
path = root / (question + '-reader-bundle.txt')
path.write_text('\n\n'.join(bundle) + '\n', encoding='utf-8')
print(question, path.stat().st_size)
