from pathlib import Path
import json
import sys
from bs4 import BeautifulSoup

root = Path(__file__).parent.resolve()
question = sys.argv[1]
scope = {
    'Q2': {
        'headings': ['동시-제출의-순서를-관찰할-경계','제출-회차별-완료-기록의-비교-계획','qbuf-호출-전-실패와-cache-반환'],
        'windows': {
            'src/libcamera/camera.cpp': [(1355, 1380)],
            'src/libcamera/request.cpp': [(275, 311), (375, 404), (537, 555)],
            'src/libcamera/pipeline_handler.cpp': [(469, 526), (584, 605)],
            'src/libcamera/v4l2_videodevice.cpp': [(1640, 1829)],
            'src/libcamera/pipeline/uvcvideo/uvcvideo.cpp': [(448, 466), (893, 904)],
        },
        'focus': '발행본에 제출 회차별 조사 계획이 별도 절로 이미 있는지 확인하고, API 진입·반환과 파이프라인 진입까지 연결하는 방법이 그 계획에 실제로 들어 있는지 판정하세요. 초기 검토의 소스 창 밖이던 fence timeout과 QBUF 호출·등록도 대조하세요.',
    },
    'Q3': {
        'headings': ['정지-api-계약과-연결-해제-todo','uvc-정지의-정상-경로와-실패-경계','동시-제출정지지연-수신의-검증-위치','정지할-때-대기-요청을-처리하는-순서'],
        'windows': {
            'src/libcamera/camera.cpp': [(677, 754), (1430, 1489)],
            'src/libcamera/pipeline_handler.cpp': [(358, 426), (483, 501), (574, 617)],
            'src/libcamera/framebuffer.cpp': [(366, 394)],
            'src/libcamera/v4l2_videodevice.cpp': [(1600, 1634), (1823, 1885), (2005, 2062)],
            'src/libcamera/pipeline/uvcvideo/uvcvideo.cpp': [(306, 330), (893, 904)],
        },
        'focus': 'STREAMOFF의 성공·실패, releaseBuffers의 오류 경계, stopDevice 호출의 반환과 이후 공통 취소 순서, 연결 해제 TODO 및 수명 근거를 초기 근거 검토보다 넓은 코드 창에서 다시 대조하세요. 공개 설명에 필수 기술 보완이 실제로 필요한지 특정하세요.',
    },
}[question]
article = BeautifulSoup((root / 'baseline/request-lifecycle.html').read_bytes(), 'html.parser').select_one('article')
doc = []
keep_level = None
for tag in article.find_all(recursive=False):
    level = int(tag.name[1]) if tag.name in ('h2', 'h3', 'h4') else None
    if level is not None and keep_level is not None and level <= keep_level:
        keep_level = None
    if tag.get('id') in scope['headings']:
        doc.append('#' + tag['id'])
        keep_level = level
    if keep_level is not None and tag.name in {'p','ul','ol','pre'}:
        doc.append(tag.get_text(' ', strip=True))
assert len([line for line in doc if line.startswith('#')]) == len(scope['headings'])
source = []
for path, ranges in scope['windows'].items():
    lines = (root / 'source' / path).read_text(encoding='utf-8').splitlines()
    for start, end in ranges:
        assert end <= len(lines), (path, end)
        source.append(f'{path}:{start}–{end}\n' + '\n'.join(f'{i}: {lines[i-1]}' for i in range(start, end+1)))
(root / (question + '-supplement-windows.json')).write_text(json.dumps(scope['windows'], indent=2) + '\n')
previous = (root / 'calls' / (question + '-baseline-review') / 'answer.md').read_text(encoding='utf-8')
lead = """공식 libcamera 커밋 c19d05128f3ae1f0ebe63acb4deaca9fbb1dde78과 공개 한국어 SDD의 추가 절을 대조하세요.
이 호출은 문서를 변경하지 않고 초기 근거 검토 입력에서 빠진 범위를 보충하는 별도 검토입니다. 읽기 응답 자체의 수행 결과는 초기 기록대로 남습니다.
파일, 도구, 웹을 사용하지 말고 제공된 자료만 사용하세요. 이전 판정에서 유지할 내용과 고쳐야 할 내용을 원문·코드 줄과 함께 짧게 제시하세요.
"""
prompt = lead + '\n' + scope['focus'] + '\n\n[추가 공개 원문]\n' + '\n\n'.join(doc)
prompt += '\n\n[공식 소스 창]\n' + '\n\n'.join(source)
prompt += '\n\n[초기 근거 검토 원문]\n' + previous
target = root / 'prompts' / (question + '-supplement-review.txt')
target.write_text(prompt, encoding='utf-8')
print(target.name, target.stat().st_size)
