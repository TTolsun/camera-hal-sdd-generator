from collections import defaultdict
from pathlib import Path
import re
import sys

root = Path(__file__).parent
question = sys.argv[1]
bundle = root / (question + '-reader-bundle.txt')
text = bundle.read_text(encoding='utf-8')
source_dir = root / 'public-code'
links = defaultdict(dict)
for match in re.finditer(r'CODE:([A-Za-z0-9_./-]+\.(?:cpp|h))#L(\d+)(?:-L(\d+))?', text):
    path, start, end = match.groups()
    if '..' in Path(path).parts or not (source_dir / path).is_file():
        continue
    links[path].setdefault(int(start), int(end or start))
snippets = ['문서가 직접 연결한 고정 소스의 링크별 발췌입니다. CODE 링크에 붙은 행 번호를 기준으로 한 경로당 최대 네 구간과 구간당 최대 12행을 제공합니다. 이 밖의 링크는 이름과 주소만 제공됩니다.']
for path, locations in links.items():
    lines = (source_dir / path).read_text(encoding='utf-8').splitlines()
    seen = set()
    count = 0
    for start, end in locations.items():
        if start in seen:
            continue
        end = min(len(lines), start + 11, max(end, start + 8))
        seen.update(range(start, end + 1))
        if end < start:
            raise ValueError((path, start))
        snippets.append(f'CODE:{path}#L{start}–{end}\n' + '\n'.join(
            f'{line}: {lines[line - 1]}' for line in range(start, end + 1)
        ))
        count += 1
        if count == 4:
            break
appendix = '\n\n'.join(snippets) + '\n'
bundle.write_text(text + '\n\n' + appendix, encoding='utf-8')
print(question, len(appendix.encode('utf-8')), bundle.stat().st_size, 'bytes')
