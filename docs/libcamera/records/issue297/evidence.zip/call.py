from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time

root = Path(__file__).parent.resolve()
name = sys.argv[1]
run = root / 'calls' / name
run.mkdir(parents=True)
is_reader = False
isolated = root / ('reader-input' if is_reader else 'isolated-cli')
isolated.mkdir(exist_ok=True)
prompt = run.parent.parent / 'prompts' / (name + '.txt')
argv = [
    shutil.which('codex'), 'exec', '--ephemeral', '--json', '--skip-git-repo-check',
    '--sandbox', 'read-only', '--ignore-user-config', '-C', str(isolated), '-m', 'gpt-6.1-terra',
    '-c', 'model_reasoning_effort="high"', '-c', 'project_doc_max_bytes=0', '-',
]
record = {'name': name, 'argv': argv, 'input_sha256': hashlib.sha256(prompt.read_bytes()).hexdigest(),
          'timeout_seconds': 240, 'started_utc': datetime.now(timezone.utc).isoformat()}
started = time.monotonic()
with prompt.open('rb') as stdin, (run / 'stdout.jsonl').open('wb') as out, (run / 'stderr.log').open('wb') as err:
    try:
        proc = subprocess.run(argv, stdin=stdin, stdout=out, stderr=err, timeout=240, cwd=isolated)
        record['exit_code'] = proc.returncode
    except (OSError, subprocess.TimeoutExpired) as exc:
        record['failure'] = str(exc)
record['wall_seconds'] = round(time.monotonic() - started, 3)
record['finished_utc'] = datetime.now(timezone.utc).isoformat()
events = []
for line in (run / 'stdout.jsonl').read_text('utf-8-sig', errors='replace').splitlines():
    try:
        events.append(json.loads(line))
    except json.JSONDecodeError:
        record['invalid_jsonl'] = True
completed = [event for event in events if event.get('type') == 'turn.completed']
items = [event.get('item', {}) for event in events if event.get('type') == 'item.completed']
messages = [item['text'] for item in items if item.get('type') == 'agent_message']
record['tool_items'] = [item.get('type') for item in items if item.get('type') not in {'reasoning', 'agent_message'}]
record['usage'] = completed[0].get('usage') if len(completed) == 1 else None
record['success'] = (
    record.get('exit_code') == 0 and len(completed) == 1 and bool(messages)
    and (is_reader or not record['tool_items']) and not record.get('invalid_jsonl')
    and not any(event.get('type') in {'error', 'turn.failed'} for event in events)
)
if messages:
    (run / 'answer.md').write_text(messages[-1] + '\n', encoding='utf-8')
(run / 'receipt.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
print(json.dumps(record))
raise SystemExit(0 if record['success'] else 1)
