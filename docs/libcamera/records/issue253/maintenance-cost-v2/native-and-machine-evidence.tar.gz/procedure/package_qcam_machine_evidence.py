"""Preserve measured public inputs and original native calls, excluding test copies."""
import gzip,hashlib,io,json,pathlib,tarfile,yaml
root=pathlib.Path(__file__).resolve().parents[2];w=root/'build/issue253/cost-followup/manuscript-run-02';out=root/'build/issue253/clarity-final/docs/libcamera/records/issue253/maintenance-cost-v2';out.mkdir(exist_ok=False);entries={};seen={};configs=set();external=[]
def add(name,p,kind):
 p=p.resolve(strict=True);assert p.is_relative_to(root.resolve()),'Unexpected external input boundary: '+str(p);assert p.is_file() and not p.is_symlink();data=p.read_bytes();h=hashlib.sha256(data).hexdigest()
 assert name not in entries;entries[name]=(data,dict(sha256=h,bytes=len(data),original_path=str(p),kind=kind));return h
for p in sorted(w.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(w)
 if any(part.startswith('pytest') or part=='__pycache__' for part in rel.parts):continue
 if 'site' in rel.parts and p.name!='site-manifest.json':continue
 add('run/'+rel.as_posix(),p,'actual-measured-run')
def snapshot(p,follow=True):
 p=p.resolve(strict=True)
 if not p.is_relative_to(root.resolve()):
  # Preserve public assets from this completed normal export, not another
  # chat's live checkout. The export copies the configured Mermaid bundle.
  assert p.is_dir() and p.name=='mermaid' and p.parent.name=='assets','Unexpected external public-input reference: '+str(p)
  actual=w/'base/site/assets/mermaid';assert actual.is_dir()
  for child in sorted(actual.rglob('*')):
   if child.is_file():
    snapshot(child);external.append(dict(original_path=str(p/child.relative_to(actual)),snapshot=seen[child.resolve()],sha256=hashlib.sha256(child.read_bytes()).hexdigest(),representation='Public vendor asset retained byte-for-byte by completed normal export; other chat live checkout not read'))
  return
 if p.is_dir():
  for child in sorted(p.rglob('*')):
   if child.is_file() and not any(k in child.parts for k in ['.git','__pycache__']):snapshot(child)
  return
 if p in seen:return
 name='resolved-inputs/'+str(len(seen)).zfill(4)+'/'+p.name;h=add(name,p,'resolved-public-input');seen[p]=name;external.append(dict(original_path=str(p),snapshot=name,sha256=h))
 if follow and p.suffix in ['.yaml','.yml']:
  d=yaml.safe_load(p.read_bytes())
  if isinstance(d,dict) and any(k in d for k in ['agent','paths','site','publication']):config(p,d)
def config(path,data=None):
 path=path.resolve(strict=True)
 if path in configs:return
 configs.add(path);data=yaml.safe_load(path.read_bytes()) if data is None else data
 def walk(value,trail):
  if isinstance(value,dict):
   for k,v in value.items():
    if not trail and k in ['source','output','agent']:continue
    walk(v,trail+[k])
  elif isinstance(value,list):
   for v in value:walk(v,trail)
  elif isinstance(value,str):
   candidate=pathlib.Path(value)
   if candidate.is_absolute() and candidate.exists():
    if trail==['publication','baseline_config']:
     snapshot(candidate,follow=False);baseline=yaml.safe_load(candidate.read_bytes())
     for key in ['sections_file','glossary_file']:
      value=baseline.get('paths',{}).get(key)
      if value and pathlib.Path(value).is_file():snapshot(pathlib.Path(value))
    else:snapshot(candidate)
 walk(data,[])
for c in ['base','head']:
 for name in ['publication-v4.yaml','review-v2.yaml']:config(w/c/name)
for name in ['run_qcam_publication_stage.py','finalize_qcam_publication_reports.py','repair_qcam_control_titles.py','run_qcam_regression.py','rerun_qcam_environment_failures.py','summarize_qcam_completed_machine.py','package_qcam_machine_evidence.py']:
 add('procedure/'+name,root/'build/issue253'/name,'recorded-procedure')
payload=json.dumps(external,ensure_ascii=False,indent=2).encode();entries['resolved-inputs/index.json']=(payload,dict(sha256=hashlib.sha256(payload).hexdigest(),bytes=len(payload),kind='input-path-relocation-bindings'))
archive=out/'native-and-machine-evidence.tar.gz'
with archive.open('wb') as stream:
 with gzip.GzipFile(filename='',fileobj=stream,mode='wb',mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w') as tar:
   for name,(data,meta) in sorted(entries.items()):
    info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
index={name:meta for name,(_,meta) in sorted(entries.items())};(out/'archive-index.json').write_text(json.dumps(index,ensure_ascii=False,indent=2),encoding='utf-8');h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
package=dict(schema=1,archive=archive.name,archive_sha256=h(archive),index_sha256=h(out/'archive-index.json'),entries=len(entries),archive_bytes=archive.stat().st_size,public_input='TTolsun/libcamera-sdd@4d656cd88c2a366dec7894e87301bf5205e98b36',runtime='efdf6cb15fb3537a427aaae8d7810913066628fa',source_base='be909e49b7cfcbf8e888b6a17928ae06fd7f9a96',source_head='293d751a814e0d4c34e85ad457ccd9d5eefd1a61',native_calls_per_condition=89,source_only='Public libcamera and public generator inputs; no person-study responses or in-house source',excluded='pytest test doubles, inherited duplicate site HTML/assets (normal manifests retained), Git objects and runtime implementation supplied by pinned commit',reproduction='Restore verified archive; resolve recorded original input paths using resolved-inputs/index.json without changing original receipts. Use pinned generator efdf and public source commits. The original extraction/build proof remains in the prior Qt supplemental package. Stored native calls certify old executions, never new CLI runs.',human_review='pending');(out/'package.json').write_text(json.dumps(package,ensure_ascii=False,indent=2),encoding='utf-8');(out/'completed-machine-result.json').write_bytes((w/'completed-machine-result.json').read_bytes());print(json.dumps(dict(entries=len(entries),resolved_inputs=len(external),archive_bytes=archive.stat().st_size)))
