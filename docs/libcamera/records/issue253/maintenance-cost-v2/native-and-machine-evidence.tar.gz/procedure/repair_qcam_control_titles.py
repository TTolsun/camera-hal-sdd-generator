"""Separate paired export recovery: restore original published figure titles."""
import copy,datetime,hashlib,json,pathlib,re,yaml
from sdd.document_metadata import split_frontmatter
root=pathlib.Path(__file__).resolve().parents[2];w=root/'build/issue253/cost-followup/manuscript-run-02';out=w/'paired-export-recovery-01';out.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda p:yaml.safe_load(p.read_bytes());original=pathlib.Path(read(w/'base/publication-v3.yaml')['visuals']['file']);visuals=read(original);before=copy.deepcopy(visuals);titles={}
for condition in ['base','head']:
 failed=json.loads((w/(condition+'-site-v3-execution.json')).read_bytes());assert failed['status']=='failed' and failed['returncode']==1
 for p in (w/condition/'manuscripts').rglob('*.md'):
  meta,body=split_frontmatter(p.read_text(encoding='utf-8'))
  for ident,title in re.findall(r'<!-- sdd:visual:([^ ]+) -->\s*\n#+ ([^\n]+)',body):
   key=(meta['section'],ident)
   if key in titles:assert titles[key]==title
   titles[key]=title
changes=[]
for section,figures in visuals['sections'].items():
 for fig in figures:
  title=titles.get((section,fig['id']))
  if title is not None and title!=fig['title']:
   changes.append(dict(section=section,id=fig['id'],old=fig['title'],restored_original_manuscript_title=title));fig['title']=title
assert changes and any(c['section']=='request-diagnosis' and c['id']=='queue-gates' for c in changes)
for section,figures in visuals['sections'].items():
 for old,new in zip(before['sections'][section],figures):assert {k:v for k,v in old.items() if k!='title'}=={k:v for k,v in new.items() if k!='title'}
visualfile=out/'visuals-restored-titles.yaml';visualfile.write_text(yaml.safe_dump(visuals,allow_unicode=True,sort_keys=False),encoding='utf-8')
for condition in ['base','head']:
 folder=w/condition;cfg=read(folder/'publication-v3.yaml');cfg['visuals']['file']=str(visualfile);oldreport=folder/'bound-prerequisites-v3/per-item-visualization.json';report=json.loads(oldreport.read_bytes());report.update(adapted_visuals_sha256=sha(visualfile),original_report_sha256=sha(oldreport),title_recovery=changes,title_recovery_scope='Only titles restored from immutable carried original manuscripts, identically in both source conditions. Nodes, edges, questions, source pins, manuscripts and fixed reader criteria are untouched. Initial adapted configuration and failed exports remain separate evidence.');newreport=out/(condition+'-per-item-visualization.json');newreport.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
 for row in cfg['publication']['reports']:
  if pathlib.Path(row['path'])==oldreport:row.update(path=str(newreport),sha256=sha(newreport))
 target=folder/'publication-v4.yaml';assert not target.exists();target.write_text(yaml.safe_dump(cfg,allow_unicode=True,sort_keys=False),encoding='utf-8')
lock=dict(frozen_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Paired recovery of benchmark adaptation mismatch, not a revised reader/effectiveness rubric or exact historical production reproduction.',original_visuals_sha256=sha(original),recovery_visuals_sha256=sha(visualfile),changes=changes,unchanged=['source commits','node/edge/evidence definitions','manuscript bytes','questions','reader rubric','CLI configuration','normal export prerequisites'],configurations={c:sha(w/c/'publication-v4.yaml') for c in ['base','head']},human_active_review_seconds=None,new_cli_calls=0);(out/'input-lock.json').write_text(json.dumps(lock,ensure_ascii=False,indent=2),encoding='utf-8');print('Restored original titles in',len(changes),'fixed diagram definitions for both conditions')
