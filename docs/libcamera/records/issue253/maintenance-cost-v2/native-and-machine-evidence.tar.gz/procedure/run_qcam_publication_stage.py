import datetime,json,pathlib,subprocess,sys,time,yaml
root=pathlib.Path(__file__).resolve().parents[2];runtime=root/'build/issue253/clarity';w=root/'build/issue253/cost-followup/manuscript-run-02';condition=sys.argv[1];name=sys.argv[2];action=name.split('-')[0];folder=w/condition;cfg=folder/(sys.argv[3] if len(sys.argv)>3 else 'review-v2.yaml' if action=='review' else 'publication-v2.yaml')
catalog=yaml.safe_load(cfg.read_text(encoding='utf-8'))['site']['english_catalog'];commands={'translate':['-m','sdd.site_localization','--config',str(cfg),'--out',catalog,'--translate'],'review':['audit-consistency'],'site':['export-site','--out',str(folder/'site')],'verify':['verify-site','--out',str(folder/'site')]}
argv=[sys.executable,*commands[action]] if action=='translate' else [sys.executable,str(runtime/'tools/run_sdd.py'),'--config',str(cfg),*commands[action]];path=w/(condition+'-'+name+'-execution.json');assert not path.exists();row=dict(stage=condition+'-'+name,argv=argv,status='running',started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),human_active_review_seconds=None,cpu_seconds=None,server_wait_seconds=None);path.write_text(json.dumps(row,indent=2),encoding='utf-8');t=time.perf_counter()
try:
 with (w/(condition+'-'+name+'.log')).open('w',encoding='utf-8') as f:p=subprocess.run(argv,cwd=runtime,stdout=f,stderr=subprocess.STDOUT,timeout=15000)
 row.update(status='completed' if p.returncode==0 else 'failed',returncode=p.returncode)
except Exception as exc:row.update(status='failed',error=repr(exc))
finally:
 row.update(ended_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),elapsed_seconds=time.perf_counter()-t);path.write_text(json.dumps(row,indent=2),encoding='utf-8');print(json.dumps(row))
sys.exit(0 if row['status']=='completed' else 1)
