"""Retain the preserved manuscript and freeze additions found by baseline audit."""
from pathlib import Path
from copy import deepcopy
import hashlib
import json
import shutil
import subprocess
import yaml

ROOT = Path(__file__).resolve().parents[4]
HERE = Path(__file__).resolve().parent
RUN = ROOT/'build/issue252/run'


def main():
    first = RUN/'draft-before-boundary-amendment.md'
    if first.exists():
        raise ValueError('Scope amendment is already frozen.')
    shutil.copyfile(RUN/'manuscripts/request-lifecycle.md',first)
    topics = yaml.safe_load((HERE/'topics.yaml').read_bytes())['topics']
    path = ROOT/'examples/libcamera/config/sections.yaml'
    text = path.read_text(encoding='utf-8')
    left = text.index('  - id: preparation-depth\n',text.index('- id: request-lifecycle\n'))
    right = text.index('  design_requirements:\n',left)
    rendered = yaml.safe_dump(topics,allow_unicode=True,sort_keys=False,width=105)
    text = text[:left]+''.join('  '+line+'\n' for line in rendered.splitlines())+text[right:]
    left,right = text.index('- id: request-lifecycle\n'),text.index('- id: request-diagnosis\n')
    current_section = yaml.safe_load(text[left:right])
    ids = {r['id'] for r in current_section[0]['design_requirements']}
    missing = [dict(id=t['id'],question=t['question']) for t in topics if t['id'] not in ids]
    rendered = yaml.safe_dump(missing,allow_unicode=True,sort_keys=False,width=105) if missing else ''
    section_text = text[left:right].replace('  reader_profile: vendor\n',
        ''.join('  '+line+'\n' for line in rendered.splitlines())+'  reader_profile: vendor\n')
    path.write_text(text[:left]+section_text+text[right:],encoding='utf-8',newline='\n')
    config = RUN/'config/sections.yaml'
    data = yaml.safe_load(config.read_bytes())
    selected = next(s for s in data['sections'] if s['id']=='request-lifecycle')
    added = {t['id']:t for t in topics}
    selected['design_topics'] = [deepcopy(added.get(t['id'],t)) for t in selected['design_topics']]
    ids = {t['id'] for t in selected['design_topics']}
    selected['design_topics'].extend(deepcopy(t) for t in topics if t['id'] not in ids)
    order = ['journey','preparation-depth','uvc-depth','resources','callback-order','callback-depth',
             'stopping','stop-depth','review','observed-callbacks']
    selected['design_topics'].sort(key=lambda t:order.index(t['id']))
    ids = {r['id'] for r in selected['design_requirements']}
    selected['design_requirements'].extend(dict(id=t['id'],question=t['question']) for t in topics if t['id'] not in ids)
    config.write_text(yaml.safe_dump(data,allow_unicode=True,sort_keys=False),encoding='utf-8')
    # Apply the same topic order without reformatting the rest of the example.
    text = path.read_text(encoding='utf-8')
    left,right = text.index('- id: request-lifecycle\n'),text.index('- id: request-diagnosis\n')
    chunk = text[left:right]
    start,end = chunk.index('  design_topics:\n')+len('  design_topics:\n'),chunk.index('  design_requirements:\n')
    import re
    positions = list(re.finditer(r'^  - id: ([a-z0-9-]+)\n',chunk[start:end],re.M))
    blocks = {m.group(1):chunk[start+m.start():start+(positions[i+1].start() if i+1<len(positions) else end-start)]
              for i,m in enumerate(positions)}
    assert set(blocks)==set(order)
    chunk = chunk[:start]+''.join(blocks[tid] for tid in order)+chunk[end:]
    path.write_text(text[:left]+chunk+text[right:],encoding='utf-8',newline='\n')
    visual_path = ROOT/'examples/libcamera/config/visuals.yaml'
    visual_text = visual_path.read_text(encoding='utf-8')
    visual_data = yaml.safe_load(visual_text)
    questions = {
        'preparation-depth':'fence 신호 또는 타임아웃에서 prepared_가 설정된 뒤 선두 준비·큐 한도를 검사하고, 재진입 전 pop하여 전달하는 흐름은 무엇입니까?',
        'uvc-depth':'UVC 제출 실패의 취소와 장치 버퍼 알림의 명시적 요청 완료는 어떻게 구분됩니까?',
        'stop-depth':'UVC STREAMOFF의 실패는 어느 반환 루프를 건너뛰며 정상 정지는 어느 순서로 버퍼를 반환합니까?',
        'callback-order':'버퍼 신호와 내부 pending_ 갱신, 요청 완료 통지 사이의 순서는 무엇입니까?',
        'callback-depth':'Auto가 현재·수신 스레드를 비교해 Direct 즉시 호출과 Queued 메시지 전달을 고르는 분기는 무엇입니까?',
    }
    plans = [dict(id=t['id']+'-flow',topic=t['id'],kind='flow',title=t['title']+' 그림',question=questions[t['id']],
                  generation='llm',max_nodes=9,prompt='조건·실패·반환 경계를 지지하는 작은 그림으로 답하세요. 본문 전체를 노드로 옮기지 마세요.') for t in topics]
    # Keep previous static figures; change only the added automatic questions.
    visual_data['sections']['request-lifecycle'] = [p for p in visual_data['sections']['request-lifecycle'] if p.get('topic') not in questions]+plans
    rendered = yaml.safe_dump(plans,allow_unicode=True,sort_keys=False,width=105)
    left,right = visual_text.index('  - id: preparation-depth-flow\n'),visual_text.index('  overview:\n')
    visual_path.write_text(visual_text[:left]+''.join('  '+line+'\n' for line in rendered.splitlines())+visual_text[right:],encoding='utf-8',newline='\n')
    (RUN/'config/visuals.yaml').write_text(yaml.safe_dump(visual_data,allow_unicode=True,sort_keys=False),encoding='utf-8')
    previous = (RUN/'scope.json').read_bytes()
    (RUN/'scope-before-amendment.json').write_bytes(previous)
    scope = json.loads(previous)
    source = ROOT/'build/issue252/source'
    file = 'src/libcamera/v4l2_device.cpp'
    raw = subprocess.check_output(['git','-C',str(source),'show',scope['source_commit']+':'+file])
    latest = subprocess.check_output(['git','-C',str(source),'show',scope['observed_official_head']+':'+file])
    assert raw==latest
    out = RUN/'source-windows'/file
    out.write_bytes(raw)
    scope['source_windows'].append(dict(file=file,line=1,end_line=len(raw.splitlines()),sha256=hashlib.sha256(raw).hexdigest(),latest_blob_equal=True))
    scope['amendment'] = dict(previous_scope_sha256=hashlib.sha256(previous).hexdigest(),
        reason='Independent baseline audit exposed ignored per-control conversion returns and same-thread reentrancy semantics; expand source coverage before generating those additions.',
        new_source=file,existing_source_reused='Documentation/thread-safety.dox',
        preserved_manuscript_sha256=hashlib.sha256(first.read_bytes()).hexdigest(),
        initial_generation='Failed visual validation; the original manuscript was preserved. Native draft responses remain in build/prompts.')
    for q in scope['questions']:
        if q['id'] in ['Q3','Q4']:
            q['topics'].append('callback-order')
    scope['generation_topics'] = [t['id'] for t in selected['design_topics']]
    (RUN/'scope.json').write_text(json.dumps(scope,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (RUN/'source-window-index.json').write_text(json.dumps(scope['source_windows'],indent=2)+'\n',encoding='utf-8')
    print('Scope amendment retained; new generation is required before review/publication.',flush=True)


if __name__=='__main__':
    main()
