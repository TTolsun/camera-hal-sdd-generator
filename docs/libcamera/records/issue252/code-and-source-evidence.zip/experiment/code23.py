import sys,json,subprocess
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root/'src'))
from sdd.config import load
from sdd.llm import Agent
from sdd.generation_run import Execution
run=root/'build/issue252/run'; previous=run/'audits/code-15'; out=run/'audits/code-23';out.mkdir()
payload=json.loads((previous/'payload.json').read_bytes())
base=subprocess.check_output(['git','merge-base','HEAD','origin/main']).decode().strip()
payload['diff']=subprocess.check_output(['git','diff',base],encoding='utf-8')
paths=list(payload['complete_changed_code'])
payload['complete_changed_code']={p:(root/p).read_text(encoding='utf-8') for p in paths}
payload['prior_findings']['code-19']=json.loads((run/'audits/code-19/review.json').read_bytes())
payload['prior_findings']['code-20']=json.loads((run/'audits/code-20/review.json').read_bytes())
payload['prior_findings']['code-21']=json.loads((run/'audits/code-21/review.json').read_bytes())
payload['prior_findings']['code-22']=json.loads((run/'audits/code-22/review.json').read_bytes())
payload['final_count_and_schema_fix']='Extraction helper explicitly asserts 135 normalized/recorded/parsed TUs and errors0; existing original facts were separately rechecked, not regenerated. Audit requires nonempty diagnostic fields and source references from exact supplied file enum. All H2/H3 anchored items are required. Current CI revealed two example integration checks; updated topic count87 and ownership projection selects actual resources summary including caller/buffer/handler contract,20 focused tests passed.'
payload['complete_changed_code']['examples/libcamera/validation/issue252/visual-amendments.yaml']=(root/'examples/libcamera/validation/issue252/visual-amendments.yaml').read_text(encoding='utf-8')
payload['complete_changed_code']['examples/libcamera/reader-paths.yaml']=(root/'examples/libcamera/reader-paths.yaml').read_text(encoding='utf-8')
payload['probe_status_fix']='Before writing verification.json, failed post-run source or library identity checks now change status to failed; process status is derived from the same recorded status. Final actual probe retained separately. Verify this straightforward correction without treating passed old postchecks as failed.'
payload['new_final_fixes']='braces now count as expression boundaries, two regression tests reproduced failure before fix. Audit supplies every actual H2/H3 outside code fences with unique required anchors and constrained visual statuses; rejects a pass if item missing, repeated, unresolved, or no reason.'
payload['last_fixes']='prepare now merges QBUF/STREAMOFF/DQBUF definitions and ENOENT alias from the current public example; audit refuses passed result with any question missing entries. Experimental enum exception remains fully withdrawn.'
payload['prior_findings']['code-15']=json.loads((previous/'review.json').read_bytes())
payload['prior_findings']['code-17']=json.loads((run/'audits/code-17/review.json').read_bytes())
payload['withdrawn_enum_exception']='The experimental enum novelty exception and its tests were fully withdrawn, backed up with hashes. src/sdd/duplicates.py and tests/test_duplicates.py equal merged main bytes. Current questions use existing qualified enum subject distinction. Do not attribute inherited subject matching to this PR.'
payload.pop('enum_mixed_claim_fix',None)
payload['tests']='Exact native enum-validity duplicate false-positive reproduced then fixed; duplicates suite 162 passed. Cross-fragment synthesized guard reproduced in two failing tests, fixed and combined visual suite 191 passed. Current source-generation clean verification included. This request does not claim remote full CI passed.'
payload.pop('topic_contracts',None)
payload['complete_changed_code']['examples/libcamera/validation/issue252/browser_test.cjs']=(root/'examples/libcamera/validation/issue252/browser_test.cjs').read_text(encoding='utf-8')
payload['actual_scope']='Pinned merge-base '+base+'; complete current changed code, tests, helper scripts. Enum-case novelty exception requires verified literal source Doxygen case description, same enum and distinct member; grounding remains mandatory. Guard matching per individual passage; legitimate multi-passage edge remains supported. No manual manuscript changes.'
payload['generation_checkout']=json.loads((run/'generation-source-verification.json').read_bytes())
payload['signal_probe']=json.loads((run/'signal-probe.json').read_bytes())
payload['signal_build']=json.loads((run.parent/'build-provenance-signal.json').read_bytes())
request=json.loads(next((previous/'prompts/calls').glob('*/*.request.json')).read_bytes())
(run/'audits/code-23/payload.json').write_text(json.dumps(payload,ensure_ascii=False),encoding='utf-8')
cfg=load(run/'independent-review.yaml');cfg.publication['operation_id']='issue252-independent-code-23'
execution=Execution(cfg,Agent(cfg.agent,out/'prompts'))
with execution.track('independent-code-review'):
 raw=execution.chat(request['system']+' Experimental enum exception was withdrawn; review the actual final diff and helpers.',json.dumps(payload,ensure_ascii=False),tag='independent-code-review-final',response_schema=request['response_schema'])
result=json.loads(raw);(out/'review.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(result,ensure_ascii=False))
