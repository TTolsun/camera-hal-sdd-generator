/* SPDX-License-Identifier: LGPL-2.1-or-later */
/*
 * Copyright (C) 2019, Google Inc.
 *
 * libcamera version
 *
 * This file is auto-generated. Do not edit.
 */

#include <libcamera/camera_manager.h>

namespace libcamera {

const std::string CameraManager::version_("v0.7.2+210-293d751a");

} /* namespace libcamera */
