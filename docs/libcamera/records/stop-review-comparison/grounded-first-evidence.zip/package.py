"""Reconcile the native receipts, blind inputs and grades before export."""
import hashlib
import json
import re
import zipfile
from study import arms, directory, read, record, root, schedule

def sha(data):
    return hashlib.sha256(data).hexdigest()

def encoded(obj):
    return (json.dumps(obj,ensure_ascii=False,indent=2)+"\n").encode()

files, ids, summary = {}, set(), []

def add(path):
    files[path.relative_to(root).as_posix()] = path.read_bytes()

def verify_call(attempt):
    r=read(attempt/"receipt.json")
    for name, digest in r["artifacts"].items():
        assert sha((attempt/name).read_bytes()) == digest
    events=[json.loads(line) for line in (attempt/"stdout.jsonl").read_bytes().splitlines()]
    assert events[0]["type"]=="thread.started" and events[0]["thread_id"] not in ids
    ids.add(events[0]["thread_id"])
    assert events[-1]["type"]=="turn.completed" and events[-2]["item"]["type"]=="agent_message"
    assert events[-2]["item"]["text"].strip()==(attempt/"final.txt").read_text("utf8").strip()
    u=events[-1]["usage"]
    usage=r["validation"]["usage"]
    assert all(usage[k]==u[k] for k in ("input_tokens","output_tokens","cached_input_tokens"))
    assert usage["total_tokens"]==u["input_tokens"]+u["output_tokens"]
    assert (r["outcome"]=="valid")== (not r["validation"]["issues"])
    for p in attempt.iterdir():
        if p.is_file():add(p)
    return usage

def verify_proof(run,proof):
    a=run/proof["attempt"]
    assert sha((a/"receipt.json").read_bytes())==proof["receipt_sha256"]
    assert sha((a/"stdin.txt").read_bytes())==proof["request_sha256"]
    assert read(a/"receipt.json")["request_key"]==proof["request_key"]
    assert sha((a/"final.txt").read_bytes())==proof["output_sha256"]
    return a/"final.txt"

parent=root/"verified-parent"
ctrl=root/"control"
discarded=root/"parent"
aborted_usage=[verify_call(p.parent) for p in sorted((discarded/"baseline/attempts/review").glob("*/*/receipt.json"))]
add(discarded/"report.json")
add(ctrl/"preparation-correction.txt")
add(ctrl/"historical-replay.json")
with zipfile.ZipFile(record/"evidence.zip") as archive:
    prior=json.loads(archive.read("sha256.json"))
    raw=archive.read("control/grading-request.txt")
    oracle=json.loads(raw[raw.index(b"\n{")+1:])
    del oracle["blinded"]
    for n in ("baseline/candidates.json","sources.json"):
        assert sha((parent/n).read_bytes())==prior["run/"+n]
    for d in read(parent/"baseline/candidates.json").values():
        verify_proof(parent,d)
        assert d["output_sha256"]==prior["run/"+d["attempt"]+"/final.txt"]
parents=read(parent/"baseline/assessments.json")
pu=[verify_call(p.parent) for p in sorted((parent/"baseline/attempts/review").glob("*/*/receipt.json"))]
for proof in parents.values(): verify_proof(parent,proof)
source_units=read(parent/"sources.json")["child"]["units"]
expected_scope={u:{f["path"]:[w["name"] for w in f["windows"]] for f in fs} for u,fs in source_units.items()}
keys={}
for p in [parent/"sources.json",parent/"run.json",parent/"report.json",parent/"baseline/candidates.json",parent/"baseline/assessments.json"]:
    add(p)
for b,order in enumerate(schedule,1):
    gr=root/f"grade{b}"
    mapping,grades=read(gr/"map.json"),read(gr/"final.txt")
    assert set(mapping.values())==set(arms) and read(gr/"execution.json")["exit"]==0
    gev=[json.loads(s) for s in (gr/"stdout.jsonl").read_bytes().splitlines()]
    assert [g["type"] for g in gev]==["thread.started","turn.started","item.completed","turn.completed"]
    assert gev[-2]["item"]["text"].strip()==(gr/"final.txt").read_text("utf8").strip()
    prompt=(gr/"prompt.txt").read_bytes()
    submitted=json.loads(prompt[prompt.index(b"\n{")+1:])
    blind=submitted.pop("blinded")
    scope=submitted.pop("scope_per_unit")
    assert submitted==oracle and scope==expected_scope
    for arm in order:
        phase=arms[arm][0]
        run=directory(b,arm)
        report=read(run/"report.json")["phases"][phase]
        assert report["status"]=="complete" and set(report["decisions"])==set("SABR")
        assert sha((run/"sources.json").read_bytes())==prior["run/sources.json"]
        label=next(l for l in mapping if mapping[l]==arm)
        for unit,d in report["decisions"].items():
            out=verify_proof(run,d["proof"])
            assert read(out)==blind[label][unit]
            assert keys.setdefault(unit,d["request_key"])==d["request_key"]==d["proof"]["request_key"]
            if d["mode"]=="reused":
                assert phase=="incremental" and d["proof"]==parents[unit]
                assert read(out)["verdict"]=="supported_complete"
            else:
                assert d["mode"]=="fresh" and d["proof"]["attempt"].startswith(phase+"/")
        usage=[verify_call(run/a["attempt"]) for a in report["attempts"]]
        assert len(usage)==report["new_calls"] and report["valid_calls"]+report["invalid_calls"]==len(usage)
        assert all(sum(v[k] for v in usage)==t for k,t in report["tokens"].items())
        for p in (run/phase).rglob("*"):
            if p.is_file():add(p)
        add(run/"report.json");add(run/"run.json")
        grade=grades[label]
        summary.append(dict(block=b,arm=arm,seconds=report["wall_elapsed_seconds"],tokens=report["tokens"],
                            calls=report["new_calls"],invalid=report["invalid_calls"],reused=sorted(report["original_receipts_used"]),
                            criteria={k:grade[k]["grade"] for k in ("D1","D2","I1")},korean=grade["korean"],
                            stop_attribution=grade["stop_attribution"]))
    for p in gr.iterdir():
        if p.is_file():add(p)
evidence=dict(discarded_preparation_calls=len(aborted_usage),
              discarded_preparation_tokens=sum(v["total_tokens"] for v in aborted_usage),
              common_parent_calls=len(pu),common_parent_tokens=sum(v["total_tokens"] for v in pu),arms=summary)
(ctrl/"summary.json").write_bytes(encoded(evidence))
for p in [ctrl/"summary.json",ctrl/"preregistration.txt",root/"study.py",root/"package.py"]:add(p)
files["provenance.json"]=encoded(dict(previous_archive_sha256=sha((record/"repeat-evidence.zip").read_bytes()),
    original_archive_sha256=sha((record/"evidence.zip").read_bytes()),implementation_model="gpt-6.2-sol",
    reviewer_model="gpt-6.1-terra",reasoning_effort="high",generator_base="1a06cbe4e1112e65b17af3769c7d5fd464a20743",
    implementation_native_usage=json.loads((ctrl/"sol.events").read_bytes().splitlines()[-1])["usage"],
    parent_policy=read(parent/"grounded-parent.json"),public_build=read(ctrl/"deployed-manifest.json")["build_id"],
    receipts=len(ids)))
guard=rb"(?:[A-Za-z]:[\\/]+Users[\\/]|/mnt/[a-z]/Users/|/home/[A-Za-z0-9._-]+/|gh[pousr]_[a-zA-Z0-9]{20,}|sk-proj-[A-Za-z0-9_-]{20,}|Authorization: Bearer )"
for name,data in files.items():
    if name!="package.py" and re.search(guard,data,re.I):raise ValueError(name)
files["sha256.json"]=encoded({n:sha(v) for n,v in sorted(files.items())})
target=record/"grounded-evidence.zip"
with zipfile.ZipFile(target,"w",compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for n,v in sorted(files.items()):z.writestr(n,v)
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None and all(sha(z.read(n))==v for n,v in json.loads(z.read("sha256.json")).items())
print("Verified",len(ids),"independent review calls and",len(files),"files")
