"""Run the preregistered three blocks and blind their quality assessment."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import secrets
import shutil
import subprocess
import sys
import time
import zipfile

root = Path(__file__).resolve().parent
repo = root.parents[1]
ctrl = root / "control"
schedule = [("PI", "PF"), ("PF", "PI"), ("PI", "PF")]
arms = {"PI": ("incremental", 2), "PF": ("full", 2)}
record = repo / "docs/libcamera/records/stop-review-comparison"
adapter = repo / "examples/libcamera/validation/stop_review/grounded.py"
old = repo / "build/stop-review-evidence"

def read(path):
    return json.loads(path.read_bytes())

def write(path, obj):
    path.write_bytes((json.dumps(obj, ensure_ascii=False, indent=2) + "\n").encode())

def directory(block, arm):
    return root / f"block{block}" / arm

def invoke(out, baseline, options, phase):
    args = [sys.executable, str(adapter), "--original-script", str(old/"paired_review.py"),
            "--baseline-run", str(baseline), "--git", str(old.parent/"libcamera-history.git"),
            "--out", str(out), *options]
    while True:
        rc = subprocess.run(args + (["--resume"] if out.exists() else [])).returncode
        if rc == 0:
            return
        attempts = list((out/phase/"attempts"/"review").glob("*/attempt-*/receipt.json"))
        bad = [p for p in attempts if read(p)["outcome"] != "valid"]
        if not bad or any(sum(p.parent.parent == q.parent.parent for q in bad) >= 3 for p in bad):
            raise RuntimeError(f"{phase} failed at {out} (exit {rc})")
        completed = sorted(str(p.relative_to(out)) for p in attempts)
        if completed == getattr(invoke,"last",None):
            raise RuntimeError("Retry produced no new receipt")
        invoke.last = completed

def reviews():
    parent = root/"verified-parent"
    invoke(parent,old/"run",["--prepare-parent"],"baseline")
    for block,order in enumerate(schedule,1):
        for arm in order:
            out=directory(block,arm)
            phase,workers=arms[arm]
            print(f"Block {block} {arm} starting", flush=True)
            invoke(out,parent,["--arm",phase,"--workers",str(workers)],phase)
            p=read(out/"report.json")["phases"][phase]
            print(f"Block {block} {arm} {p['tokens']} {p['wall_elapsed_seconds']} s",flush=True)

def grade():
    (root/"empty").mkdir(exist_ok=True)
    with zipfile.ZipFile(record / "evidence.zip") as z:
        raw = z.read("control/grading-request.txt")
        assert hashlib.sha256(raw).hexdigest() == json.loads(z.read("sha256.json"))["control/grading-request.txt"]
    cut = raw.index(b"\n{") + 1
    instruction = ("Return compact JSON keyed L and M. For each set output D1,D2,I1 objects with "
                   "grade (full/partial/absent), evidence (actual review claim indices and brief quotes), explanation. "
                   "Independently audit all natural-language claim/correction/consequence fields per unit. "
                   "Provide korean={S:pass/fail,A:pass/fail,B:pass/fail,R:pass/fail} and a concise reason for any fail. "
                   "Check every stop (S) finding against the verbatim candidate; does it attribute to the candidate a "
                   "function, direct call, order, condition or specific implementation the candidate did not claim, "
                   "including when classifying a missing detail as an explicit contradiction? Read all fields, not just "
                   "the quote. Provide stop_attribution={grade:pass/fail,evidence:brief claim indices plus original "
                   "candidate and review quotes supporting the verdict}. Distinguish documenting an earlier source "
                   "path or a suggested correction from claiming it appeared in the draft. Never award a pass just "
                   "because a quote is a substring. Flag other material quality problems separately. scope_per_unit "
                   "lists exactly the function windows each reviewer received; do not infer it saw the union. "
                   "Grade each set independently. Write explanations in Korean.\n").encode()
    def grade_block(block):
        d = root / f"grade{block}"
        if d.exists() and (d / "execution.json").exists() and read(d / "execution.json")["exit"] == 0:
            return
        d.mkdir(exist_ok=False)
        labels = list(arms)
        secrets.SystemRandom().shuffle(labels)
        mapping = dict(zip("LM", labels))
        write(d / "map.json", mapping)
        data = json.loads(raw[cut:])
        data["blinded"] = {}
        for label, arm in mapping.items():
            phase = arms[arm][0]
            run = directory(block, arm)
            verdicts = {}
            for unit in "SABR":
                decision = read(run / phase / "decisions" / f"{unit}.json")
                proof = decision["proof"]
                final = (run / proof["attempt"] / "final.txt").read_bytes()
                assert hashlib.sha256(final).hexdigest() == proof["output_sha256"]
                verdicts[unit] = json.loads(final)
            data["blinded"][label] = verdicts
        windows = read(directory(block,"PI")/"sources.json")["child"]["units"]
        data["scope_per_unit"] = {u:{f["path"]:[w["name"] for w in f["windows"]] for f in fs} for u,fs in windows.items()}
        header = raw[:cut]
        prompt = header + instruction + json.dumps(data, ensure_ascii=False,separators=(",", ":")).encode()
        (d / "prompt.txt").write_bytes(prompt)
        cmd = [shutil.which("codex.exe") or shutil.which("codex"), "exec", "--ephemeral", "--json",
               "--skip-git-repo-check", "-s", "read-only", "-m", "gpt-6.1-terra", "-c",
               'model_reasoning_effort="high"', "-c", "project_doc_max_bytes=0", "-o", str(d / "final.txt"), "-"]
        start = time.perf_counter()
        result = subprocess.run(cmd, cwd=root/"empty", input=prompt, capture_output=True)
        (d/"stdout.jsonl").write_bytes(result.stdout)
        (d/"stderr.txt").write_bytes(result.stderr)
        write(d/"execution.json", dict(model="gpt-6.1-terra",effort="high",exit=result.returncode,seconds=time.perf_counter()-start))
        result.check_returncode()
        print(f"Block {block} blinded grading complete",flush=True)

    with ThreadPoolExecutor(max_workers=3) as graders:
        list(graders.map(grade_block, range(1, 4)))

if __name__ == "__main__":
    if sys.argv[1] == "reviews":
        reviews()
    elif sys.argv[1] == "grade":
        grade()
