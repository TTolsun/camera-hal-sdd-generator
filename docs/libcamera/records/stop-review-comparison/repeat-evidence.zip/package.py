"""Verify new receipts against the published follow-up before assembling public evidence."""
import json
import hashlib
import re
import zipfile
from study import *

def sha(b):
    return hashlib.sha256(b).hexdigest()

def encoded(x):
    return (json.dumps(x,ensure_ascii=False,indent=2) + "\n").encode()

files = {}
table = []
seen = set()
with zipfile.ZipFile(record/"followup-evidence.zip") as z:
    historic = json.loads(z.read("sha256.json"))
    before = json.loads(z.read("run/report.json"))["phases"]
    previous = z.read("control/grading-request.txt")
    oracle = json.loads(previous[previous.index(b"\n{")+1:])
    del oracle["blinded"]
for block, order in enumerate(schedule,1):
    gr = root/f"grade{block}"
    mapping = read(gr/"map.json")
    grades = read(gr/"final.txt")
    raw = (gr/"prompt.txt").read_bytes()
    submitted = json.loads(raw[raw.index(b"\n{")+1:])
    blinded = submitted.pop("blinded")
    assert submitted == oracle
    grlines = [json.loads(s) for s in (gr/"stdout.jsonl").read_bytes().splitlines()]
    assert read(gr/"execution.json")["exit"] == 0
    assert [s["type"] for s in grlines] == ["thread.started","turn.started","item.completed","turn.completed"]
    assert grlines[-2]["item"]["text"].strip() == (gr/"final.txt").read_text("utf8").strip()
    assert set(mapping.values()) == set(arms)
    for arm in order:
        phase,workers = arms[arm]
        run = directory(block,arm)
        report = read(run/"report.json")
        res = report["phases"][phase]
        assert sha((run/"sources.json").read_bytes()) == historic["run/sources.json"]
        assert res["status"] == "complete" and res["valid_calls"] == (4 if arm=="PF" else 2)
        assert res["new_calls"] == res["valid_calls"] + res["invalid_calls"]
        assert res["invalid_calls"] == res["call_retries"]
        sums = dict(input_tokens=0,output_tokens=0,cached_input_tokens=0)
        times = []
        lab = next(l for l in mapping if mapping[l]==arm)
        for unit,dec in res["decisions"].items():
            proof = dec["proof"]
            a = run/proof["attempt"]
            receipt = read(a/"receipt.json")
            assert sha((a/"receipt.json").read_bytes()) == proof["receipt_sha256"]
            assert sha((a/"final.txt").read_bytes()) == proof["output_sha256"]
            assert read(a/"final.txt") == blinded[lab][unit]
            assert sha((a/"stdin.txt").read_bytes()) == before["full"]["decisions"][unit]["proof"]["request_sha256"]
            assert proof["request_key"] == dec["request_key"] == before["full"]["decisions"][unit]["request_key"]
            for name,digest in receipt["artifacts"].items():
                assert sha((a/name).read_bytes()) == digest
            assert (dec["mode"]=="reused") == (phase=="incremental" and unit in "BR")
            if dec["mode"]=="reused":
                assert proof == before["incremental"]["decisions"][unit]["proof"]
                assert (run/phase/"reused-verdicts"/(unit+".json")).read_bytes() == (a/"final.txt").read_bytes()
                continue
            events = [json.loads(line) for line in (a/"stdout.jsonl").read_bytes().splitlines()]
            assert [s["type"] for s in events] == ["thread.started","turn.started","item.completed","turn.completed"]
            assert events[0]["thread_id"] not in seen
            seen.add(events[0]["thread_id"])
            assert events[-2]["item"]["text"].strip() == (a/"final.txt").read_text("utf8").strip()
            assert receipt["outcome"]=="valid" and not receipt["validation"]["issues"]
            for k in sums:
                sums[k] += events[-1]["usage"][k]
            times.append([unit,receipt["start_utc"],receipt["end_utc"],receipt["elapsed_ns"]/1e9])
        for attempt in res["attempts"]:
            if attempt["outcome"]=="invalid":
                a = run/attempt["attempt"]
                receipt=read(a/"receipt.json")
                assert receipt["validation"]["issues"]
                for name,digest in receipt["artifacts"].items():
                    assert sha((a/name).read_bytes()) == digest
                events = [json.loads(line) for line in (a/"stdout.jsonl").read_bytes().splitlines()]
                assert events[0]["thread_id"] not in seen and events[-1]["type"]=="turn.completed"
                seen.add(events[0]["thread_id"])
                for k in sums:
                    sums[k] += events[-1]["usage"][k]
        assert all(v == res["tokens"][k] for k,v in sums.items())
        assert sum(sums[k] for k in ("input_tokens","output_tokens")) == res["tokens"]["total_tokens"]
        quality = {k:grades[lab][k]["grade"] for k in ("D1","D2","I1")}
        assert set(quality.values()) <= {"full","partial","absent"}
        table.append(dict(block=block,arm=arm,phase=phase,workers=workers,grade=quality,
                          seconds=res["wall_elapsed_seconds"],tokens=res["tokens"],calls=res["new_calls"],
                          invalid_calls=res["invalid_calls"], active_seconds=res["active_elapsed_ns"]/1e9,
                          times=times))
        for p in [run/"report.json",run/"run.json",*sorted((run/phase).rglob("*"))]:
            if p.is_file():
                files[p.relative_to(root).as_posix()] = p.read_bytes()
    for p in gr.iterdir():
        if p.is_file():
            files[p.relative_to(root).as_posix()] = p.read_bytes()
assert len(seen)==sum(r["calls"] for r in table) and len(table)==9
write(ctrl/"summary.json",table)
files["control/summary.json"]=encoded(table)
for p in [ctrl/"preregistration.txt",root/"study.py",root/"package.py"]:
    files[p.relative_to(root).as_posix()]=p.read_bytes()
files["provenance.json"]=encoded(dict(
    original_archive_sha256=sha((record/"evidence.zip").read_bytes()),
    prior_archive_sha256=sha((record/"followup-evidence.zip").read_bytes()),
    implementation_model="gpt-6.2-sol", implementation_attempt_usage=[
        json.loads((ctrl/name).read_bytes().splitlines()[-1])["usage"] for name in ("sol.events","sol-retry.events")],
    reviewer_model="gpt-6.1-terra", reasoning_effort="high",
    adapter_sha256=sha(adapter.read_bytes()),
    public_build=read(ctrl/"deployed-manifest.json")["build_id"],
    child=report["child"],parent=report["parent"]))
guard = rb"(?:[A-Za-z]:[\\/]+Users[\\/]|/mnt/[a-z]/Users/|/home/[A-Za-z0-9._-]+/|gh[pousr]_[a-zA-Z0-9]{20,}|sk-proj-[A-Za-z0-9_-]{20,}|Authorization: Bearer )"
for name,b in files.items():
    if name!="package.py" and re.search(guard,b,re.I):
        raise ValueError(f"Local path or credential in {name}")
files["sha256.json"]=encoded({k:sha(v) for k,v in sorted(files.items())})
destination=record/"repeat-evidence.zip"
with zipfile.ZipFile(destination,"w",compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for k,v in sorted(files.items()):
        z.writestr(k,v)
with zipfile.ZipFile(destination) as z:
    assert z.testzip() is None and all(sha(z.read(k))==v for k,v in json.loads(z.read("sha256.json")).items())
print(f"{len(table)} arms, {len(seen)} distinct native reviews, {len(files)} files verified")
