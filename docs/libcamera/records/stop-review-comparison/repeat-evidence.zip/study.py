"""Run the preregistered three blocks and blind their quality assessment."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import secrets
import shutil
import subprocess
import sys
import time
import zipfile

root = Path(__file__).resolve().parent
repo = root.parents[1]
ctrl = root / "control"
schedule = [("SI", "PI", "PF"), ("PI", "PF", "SI"), ("PF", "SI", "PI")]
arms = {"SI": ("incremental", 1), "PI": ("incremental", 2), "PF": ("full", 2)}
record = repo / "docs/libcamera/records/stop-review-comparison"
adapter = repo / "examples/libcamera/validation/stop_review/followup.py"
old = repo / "build/stop-review-evidence"

def read(path):
    return json.loads(path.read_bytes())

def write(path, obj):
    path.write_bytes((json.dumps(obj, ensure_ascii=False, indent=2) + "\n").encode())

def directory(block, arm):
    return root / f"block{block}" / arm

def reviews():
    for block, order in enumerate(schedule, 1):
        for arm in order:
            out = directory(block, arm)
            phase, workers = arms[arm]
            # Only completed arms from this isolated study may be skipped on resume.
            if (out / "report.json").exists() and read(out / "report.json")["phases"][phase]["status"] == "complete":
                continue
            args = [sys.executable, str(adapter), "--original-script", str(old / "paired_review.py"),
                    "--baseline-run", str(old / "run"), "--git", str(old.parent / "libcamera-history.git"),
                    "--out", str(out), "--workers", str(workers), "--arm", phase]
            if out.exists():
                args.append("--resume")
            print(f"Block {block} {arm} start", flush=True)
            subprocess.run(args, check=True)
            p = read(out / "report.json")["phases"][phase]
            print(f"Block {block} {arm} {p['status']} {p['tokens']} {p['wall_elapsed_seconds']} s", flush=True)

def grade():
    (root/"empty").mkdir(exist_ok=True)
    with zipfile.ZipFile(record / "evidence.zip") as z:
        raw = z.read("control/grading-request.txt")
        assert hashlib.sha256(raw).hexdigest() == json.loads(z.read("sha256.json"))["control/grading-request.txt"]
    cut = raw.index(b"\n{") + 1
    # Same frozen gold and grading instructions, with a third blind label and explicit output keys.
    instruction = ("Return a JSON object with top-level keys L, M, N. Each contains D1, D2, I1 "
                   "with fields grade (full/partial/absent), evidence (brief verbatim Korean "
                   "claim fragments and indices), and explanation; flag unsupported statements separately. "
                   "Treat each blinded set independently.\n").encode()
    def grade_block(block):
        d = root / f"grade{block}"
        if d.exists() and (d / "execution.json").exists() and read(d / "execution.json")["exit"] == 0:
            return
        d.mkdir(exist_ok=False)
        labels = list(arms)
        secrets.SystemRandom().shuffle(labels)
        mapping = dict(zip("LMN", labels))
        write(d / "map.json", mapping)
        data = json.loads(raw[cut:])
        data["blinded"] = {}
        for label, arm in mapping.items():
            phase = arms[arm][0]
            run = directory(block, arm)
            verdicts = {}
            for unit in "SABR":
                decision = read(run / phase / "decisions" / f"{unit}.json")
                proof = decision["proof"]
                final = (run / proof["attempt"] / "final.txt").read_bytes()
                assert hashlib.sha256(final).hexdigest() == proof["output_sha256"]
                verdicts[unit] = json.loads(final)
            data["blinded"][label] = verdicts
        header = raw[:cut].replace(b"two blinded sets", b"three blinded sets", 1)
        prompt = header + instruction + json.dumps(data, ensure_ascii=False,separators=(",", ":")).encode()
        (d / "prompt.txt").write_bytes(prompt)
        cmd = [shutil.which("codex.exe") or shutil.which("codex"), "exec", "--ephemeral", "--json",
               "--skip-git-repo-check", "-s", "read-only", "-m", "gpt-6.1-terra", "-c",
               'model_reasoning_effort="high"', "-c", "project_doc_max_bytes=0", "-o", str(d / "final.txt"), "-"]
        start = time.perf_counter()
        result = subprocess.run(cmd, cwd=root/"empty", input=prompt, capture_output=True)
        (d/"stdout.jsonl").write_bytes(result.stdout)
        (d/"stderr.txt").write_bytes(result.stderr)
        write(d/"execution.json", dict(model="gpt-6.1-terra",effort="high",exit=result.returncode,seconds=time.perf_counter()-start))
        result.check_returncode()
        print(f"Block {block} blinded grading complete",flush=True)

    with ThreadPoolExecutor(max_workers=3) as graders:
        list(graders.map(grade_block, range(1, 4)))

if __name__ == "__main__":
    if sys.argv[1] == "reviews":
        reviews()
    elif sys.argv[1] == "grade":
        grade()
