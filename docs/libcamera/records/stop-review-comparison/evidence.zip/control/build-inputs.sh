set -euo pipefail
workspace="$PWD/build/review-ab/control"
work=$(mktemp -d /tmp/libcamera-review-731a340c-XXXXXX)
printf '%s\n' "$work" > "$workspace/linux-work.txt"
for revision in 517b863bae2db2dd0c56366119318d6b2fb9ad52 731a340c8064843075cb9a41e22908eadadbf1bd; do
    source_dir="$work/$revision"
    git clone -q --no-checkout --no-hardlinks "$PWD/build/libcamera-history.git" "$source_dir"
    git -C "$source_dir" checkout -q --detach "$revision"
    out="$source_dir/out"
    meson setup "$out" "$source_dir" -Dpipelines=uvcvideo -Dipas=[] -Dcam=disabled -Dqcam=disabled -Ddocumentation=disabled -Dgstreamer=disabled -Dtest=false -Dpycamera=disabled -Dwerror=false > "$workspace/$revision-meson.log" 2>&1
    ninja -C "$out" -t targets all | awk '/(camera\.cpp|pipeline_handler\.cpp|request\.cpp)\.o:/{print $1}' | tr -d ':' | grep -E 'libcamera\.so[^/]*/(camera|pipeline_handler|request)\.cpp\.o$' > "$workspace/$revision-targets.txt"
    test "$(wc -l < "$workspace/$revision-targets.txt")" -eq 3
    mapfile -t targets < "$workspace/$revision-targets.txt"
    ninja -C "$out" -j3 "${targets[@]}" > "$workspace/$revision-build.log" 2>&1
    cp "$out/compile_commands.json" "$workspace/$revision-compile-db.json"
    cp "$out/meson-info/intro-buildoptions.json" "$workspace/$revision-buildoptions.json"
    printf '%s three object targets built\n' "$revision"
done
