set -euo pipefail
control="$PWD/build/review-ab/control"
work=$(cat "$control/linux-work.txt")
runner=${SDD_PYTHON:?Set SDD_PYTHON to a Linux Python with project dependencies}
for rev in 517b863bae2db2dd0c56366119318d6b2fb9ad52 731a340c8064843075cb9a41e22908eadadbf1bd; do
    src="$work/$rev"
    folder="$control/scenario-facts-$rev"
    mkdir -p "$folder"
    "$runner" examples/libcamera/prepare_compdb.py --build-dir "$src/out" --out "$folder/normalized.json"
    "$runner" -c 'import json,sys,pathlib; p=pathlib.Path(sys.argv[1]); paths={str(pathlib.Path(sys.argv[2])/"src/libcamera"/(name+".cpp")) for name in ("camera","pipeline_handler","request")}; units=[x for x in json.loads((p/"normalized.json").read_bytes()) if x["file"] in paths]; assert len(units)==3; (p/"selected.json").write_text(json.dumps(units))' "$folder" "$src"
    printf 'source:\n  root: %s\n  compile_commands: %s/selected.json\n  exclude: ["out/**","subprojects/**"]\noutput:\n  facts_dir: %s\ntools:\n  clang_uml: none\npaths:\n  config: .\n' "$src" "$folder" "$folder" > "$folder/sdd.yaml"
    printf 'scenarios:\n  - id: stop\n    from: "Camera::stop()"\n    title: "Camera stop"\n  - id: pipeline_stop\n    from: "PipelineHandler::stop(Camera *)"\n    title: "Pipeline stop"\n' > "$folder/scenarios.yaml"
    printf 'sections: []\n' > "$folder/sections.yaml"
    "$runner" tools/run_sdd.py --config "$folder/sdd.yaml" extract > "$folder/extraction.log" 2>&1
    sha256sum "$folder/facts.json"
done
