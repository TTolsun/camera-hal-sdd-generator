---
generated_at: 2026-11-03T17:21:04+00:00
source_commit: 293d751a814e0d4c34e85ad457ccd9d5eefd1a61
status: ok
section: pipeline-handler
generation_method: facts-and-llm
evidence_fingerprint: 8502a1d065262062d1636642143ee4ed0d5f97a7165672967ef1a9550015937e
semantic_review: human-review-required
agent: cli/codex/gpt-6.1-terra
generated_design: {"schema": 1, "input_fingerprint": "8502a1d065262062d1636642143ee4ed0d5f97a7165672967ef1a9550015937e", "answers": {"responsibility": [{"text": "`PipelineHandler`는 `DeviceEnumerator`의 미디어 장치를 지원하는 파이프라인과 대조해 `Camera`를 생성·관리하며, 수동 생성하지 않고 `PipelineHandlerFactoryBase::create()`로 생성해야 하고 `std::shared_ptr`로 참조 계수되며 `std::enable_shared_from_this`를 구현합니다. match()는 한 파이프라인에 필요한 장치를 모두 확보하면 `Camera`를 생성해 내부에 저장하고 `CameraManager`에 등록한 뒤 true를 반환하며, 그렇지 않으면 장치를 확보하지 않거나 확보한 장치를 모두 해제하고 false를 반환합니다. acquireMediaDevice()가 확보한 장치는 호출자가 직접 해제하지 않아야 하며 핸들러 소멸 시 자동 해제됩니다. acquire()는 같은 프로세스에서 재귀적으로 가능하고 성공할 때마다 release()와 짝을 지어야 하며 `Camera`가 호출을 관리합니다. 장치 lock 실패 시 unlockMediaDevices()로 잠금을 풀고 false를 반환하며, acquireDevice() 실패 시에는 useCount가 0이면 잠금을 풀고 false를 반환하고, 여러 카메", "evidence": ["handler", "acquisition"], "covers": ["responsibility"], "kind": "behavior", "quote": "\\class PipelineHandler\n * \\brief Create and manage cameras based on a set of media devices\n *\n * The PipelineHandler matches the media devices provided by a DeviceEnumerator\n * with the pipelines it supports and creates corresponding Camera devices.\n *\n * Pipeline handler instances are reference-counted through std::shared_ptr<>.\n * They implement std::enable_shared_from_this<> in order to create new\n * std::shared_ptr<> in code paths originating from member functions of the\n * PipelineHandler class where only the 'this' pointer is available.\n */\n\n/**\n * \\brief Construct a PipelineHandler instance\n * \\param[in] manager The camera manager\n * \\param[in] maxQueuedRequestsDevice The maximum number of requests queued to\n * the device\n *\n * In order to honour the std::enable_shared_from_this<> contract,\n * PipelineHandler instances shall never be constructed manually, but always\n * through the PipelineHandlerFactoryBase::create() function.\n */\nPipelineHandler::PipelineHandler(CameraManager *manager,\n\t\t\t\t unsigned int maxQueuedRequestsDevice)\n\t: manager_(manager), maxQueuedRequestsDevice_(maxQueuedRequestsDevice),\n\t  useCount_(0)\n{\n}\n\nPipelineHandler::~PipelineHandler()\n{\n\tfor (std::shared_ptr<MediaDevice> &media : mediaDevices_)\n\t\tmedia->release();\n}\n\n/**\n * \\fn PipelineHandler::match(DeviceEnumerator *enumerator)\n * \\brief Match media devices and create camera instances\n * \\param[in] enumerator The enumerator providing all media devices found in the\n * system\n *\n * This function is the main entry point of the pipeline handler. It is called\n * by the camera manager with the \\a enumerator passed as an argument. It shall\n * acquire from the \\a enumerator all the media devices it needs for a single\n * pipeline, create one or multiple Camera instances and register them with the\n * camera manager.\n *\n * If all media devices needed by the pipeline handler are found, they must all\n * be acquired by a call to MediaDevice::acquire(). This function shall then\n * create the corresponding Camera instances, store them internally, and return\n * true. Otherwise it shall not acquire any media device (or shall release all\n * the media devices is has acquired by calling MediaDevice::release()) and\n * return false.\n *\n * If multiple instances of a pipeline are available in the system, the\n * PipelineHandler class will be instantiated once per instance, and its match()\n * function called for every instance. Each call shall acquire media devices for\n * one pipeline instance, until all compatible media devices are exhausted.\n *\n * If this function returns true, a new instance of the pipeline handler will\n * be created and its match() function called.\n *\n * \\context This function is called from the CameraManager thread.\n *\n * \\return true if media devices have been acquired and camera instances\n * created, or false otherwise\n */\n\n/**\n * \\brief Search and acquire a MediaDevice"}], "configuration": [{"text": "generateConfiguration()에서 호출자는 기본 구성을 얻고자 하는 사용 사례로 roles를 채워야 하며, 요청한 역할을 충족할 수 있으면 유효한 `CameraConfiguration`을, 그렇지 않으면 null 포인터를 반환합니다. 이 함수는 어느 스레드에서나 호출될 수 있고 스레드 안전해야 하며, 파이프라인 핸들러에서 camera의 상태를 변경해서는 안 됩니다. configure()는 애플리케이션에서 적용할 구성을 받은 `Camera` 클래스가 호출하도록 의도되며, `CameraConfiguration::validate()`로 검증된 구성을 받는 것이 보장되므로 구현은 추가 검증을 수행해서는 안 되고 파생 구성 클래스의 사용자 정의 필드를 신뢰할 수 있습니다. 구현은 각 `StreamConfiguration` 항목에 `StreamConfiguration::setStream()`으로 `Stream` 인스턴스를 연결해야 하며, configure()는 성공 시 0을, 그 외에는 음수 오류 코드를 반환합니다.", "evidence": ["configuration"], "covers": ["configuration"], "kind": "behavior", "quote": "\\fn PipelineHandler::generateConfiguration()\n * \\brief Generate a camera configuration for a specified camera\n * \\param[in] camera The camera to generate a default configuration for\n * \\param[in] roles A list of stream roles\n *\n * Generate a default configuration for the \\a camera for a specified list of\n * stream roles. The caller shall populate the \\a roles with the use-cases it\n * wishes to fetch the default configuration for. The returned configuration\n * can then be examined by the caller to learn about the selected streams and\n * their default parameters.\n *\n * The intended companion to this is \\a configure() which can be used to change\n * the group of streams parameters.\n *\n * \\context This function may be called from any thread and shall be\n * \\threadsafe. It shall not modify the state of the \\a camera in the pipeline\n * handler.\n *\n * \\return A valid CameraConfiguration if the requested roles can be satisfied,\n * or a null pointer otherwise.\n */\n\n/**\n * \\fn PipelineHandler::configure()\n * \\brief Configure a group of streams for capture\n * \\param[in] camera The camera to configure\n * \\param[in] config The camera configurations to setup\n *\n * Configure the specified group of streams for \\a camera according to the\n * configuration specified in \\a config. The intended caller of this interface\n * is the Camera class which will receive configuration to apply from the\n * application.\n *\n * The configuration is guaranteed to have been validated with\n * CameraConfiguration::validate(). The pipeline handler implementation shall\n * not perform further validation and may rely on any custom field stored in its\n * custom CameraConfiguration derived class.\n *\n * When configuring the camera the pipeline handler shall associate a Stream\n * instance to each StreamConfiguration entry in the CameraConfiguration using\n * the StreamConfiguration::setStream() function.\n *\n * \\context This function is called from the CameraManager thread.\n *\n * \\return 0 on success or a negative error code otherwise"}], "shutdown": [{"text": "`PipelineHandler::stop`은 `waitingRequests_`의 모든 대기 요청을 로컬 큐와 교환하여 분리합니다. 이는 stopDevice() 내부에서 completeRequest()가 호출될 때 대기 요청이 다시 큐에 들어가지 않도록 하기 위함입니다. 그 직후 장치 정지 함수인 stopDevice(camera)를 호출합니다.", "evidence": ["stop"], "covers": ["shutdown"], "kind": "behavior", "quote": "\\brief Stop capturing from all running streams and cancel pending requests\n * \\param[in] camera The camera to stop\n *\n * This function stops capturing and processing requests immediately. All\n * pending requests are cancelled and complete immediately in an error state.\n *\n * \\context This function is called from the CameraManager thread.\n */\nvoid PipelineHandler::stop(Camera *camera)\n{\n\t/*\n\t * Take all waiting requests so that they are not requeued in response\n\t * to completeRequest() being called inside stopDevice(). Cancel them\n\t * after the device to keep them in order.\n\t */\n\tCamera::Private *data = camera->_d();\n\tstd::queue<Request *> waitingRequests;\n\twaitingRequests.swap(data->waitingRequests_);\n\n\t/* Stop the pipeline handler and let the queued requests complete. */\n\tstopDevice(camera);\n\n\t/* Cancel and signal as complete all waiting requests. */\n\twhile (!waitingRequests.empty()) {\n\t\tRequest *request = waitingRequests.front();\n\t\twaitingRequests.pop();\n\n\t\t/*\n\t\t * Cancel all requests by marking them as cancelled and calling\n\t\t * doQueueRequest() instead of cancelRequest(). This ensures\n\t\t * that the requests get a sequence number and are temporarily\n\t\t * added to queuedRequests_ so they can be properly completed in\n\t\t * completeRequest().\n\t\t */\n\t\trequest->_d()->cancel();\n\t\tdoQueueRequest(request);\n\t}\n\n\t/* Make sure no requests are pending. */\n\tASSERT(data->queuedRequests_.empty());\n\tASSERT(data->waitingRequests_.empty());\n\n\tdata->requestSequence_ = 0;\n}\n\n/**\n * \\fn PipelineHandler::stopDevice()\n * \\brief Stop capturing from all running streams\n * \\param[in] camera The camera to stop\n *\n * This function stops capturing and processing requests immediately. All\n * pending requests are cancelled and complete immediately in an error state.\n */\n\n/**\n * \\brief Determine if the camera has any requests pending", "part_id": "detach"}, {"text": "stopDevice가 반환하면 분리해 둔 대기 요청을 앞에서부터 하나씩 꺼내 취소 상태로 표시한 뒤 doQueueRequest를 호출하여 완료 처리합니다.", "evidence": ["stop", "cancelled-dispatch"], "covers": ["shutdown"], "kind": "behavior", "quote": "\\brief Stop capturing from all running streams and cancel pending requests\n * \\param[in] camera The camera to stop\n *\n * This function stops capturing and processing requests immediately. All\n * pending requests are cancelled and complete immediately in an error state.\n *\n * \\context This function is called from the CameraManager thread.\n */\nvoid PipelineHandler::stop(Camera *camera)\n{\n\t/*\n\t * Take all waiting requests so that they are not requeued in response\n\t * to completeRequest() being called inside stopDevice(). Cancel them\n\t * after the device to keep them in order.\n\t */\n\tCamera::Private *data = camera->_d();\n\tstd::queue<Request *> waitingRequests;\n\twaitingRequests.swap(data->waitingRequests_);\n\n\t/* Stop the pipeline handler and let the queued requests complete. */\n\tstopDevice(camera);\n\n\t/* Cancel and signal as complete all waiting requests. */\n\twhile (!waitingRequests.empty()) {\n\t\tRequest *request = waitingRequests.front();\n\t\twaitingRequests.pop();\n\n\t\t/*\n\t\t * Cancel all requests by marking them as cancelled and calling\n\t\t * doQueueRequest() instead of cancelRequest(). This ensures\n\t\t * that the requests get a sequence number and are temporarily\n\t\t * added to queuedRequests_ so they can be properly completed in\n\t\t * completeRequest().\n\t\t */\n\t\trequest->_d()->cancel();\n\t\tdoQueueRequest(request);\n\t}\n\n\t/* Make sure no requests are pending. */\n\tASSERT(data->queuedRequests_.empty());\n\tASSERT(data->waitingRequests_.empty());\n\n\tdata->requestSequence_ = 0;\n}\n\n/**\n * \\fn PipelineHandler::stopDevice()\n * \\brief Stop capturing from all running streams\n * \\param[in] camera The camera to stop\n *\n * This function stops capturing and processing requests immediately. All\n * pending requests are cancelled and complete immediately in an error state.\n */\n\n/**\n * \\brief Determine if the camera has any requests pending", "part_id": "pending"}, {"text": "stopDevice 구현자는 실행 중인 모든 스트림의 캡처와 요청 처리를 즉시 중단하고, 대기 중인 모든 요청을 취소하여 즉시 오류 상태로 완료해야 합니다.", "evidence": ["stop"], "covers": ["shutdown"], "kind": "behavior", "quote": "\\brief Stop capturing from all running streams and cancel pending requests\n * \\param[in] camera The camera to stop\n *\n * This function stops capturing and processing requests immediately. All\n * pending requests are cancelled and complete immediately in an error state.\n *\n * \\context This function is called from the CameraManager thread.\n */\nvoid PipelineHandler::stop(Camera *camera)\n{\n\t/*\n\t * Take all waiting requests so that they are not requeued in response\n\t * to completeRequest() being called inside stopDevice(). Cancel them\n\t * after the device to keep them in order.\n\t */\n\tCamera::Private *data = camera->_d();\n\tstd::queue<Request *> waitingRequests;\n\twaitingRequests.swap(data->waitingRequests_);\n\n\t/* Stop the pipeline handler and let the queued requests complete. */\n\tstopDevice(camera);\n\n\t/* Cancel and signal as complete all waiting requests. */\n\twhile (!waitingRequests.empty()) {\n\t\tRequest *request = waitingRequests.front();\n\t\twaitingRequests.pop();\n\n\t\t/*\n\t\t * Cancel all requests by marking them as cancelled and calling\n\t\t * doQueueRequest() instead of cancelRequest(). This ensures\n\t\t * that the requests get a sequence number and are temporarily\n\t\t * added to queuedRequests_ so they can be properly completed in\n\t\t * completeRequest().\n\t\t */\n\t\trequest->_d()->cancel();\n\t\tdoQueueRequest(request);\n\t}\n\n\t/* Make sure no requests are pending. */\n\tASSERT(data->queuedRequests_.empty());\n\tASSERT(data->waitingRequests_.empty());\n\n\tdata->requestSequence_ = 0;\n}\n\n/**\n * \\fn PipelineHandler::stopDevice()\n * \\brief Stop capturing from all running streams\n * \\param[in] camera The camera to stop\n *\n * This function stops capturing and processing requests immediately. All\n * pending requests are cancelled and complete immediately in an error state.\n */\n\n/**\n * \\brief Determine if the camera has any requests pending", "part_id": "device-duty"}, {"text": "stop의 마지막에서 ASSERT는 `queuedRequests_`와 `waitingRequests_`가 각각 비어 있는지 확인합니다. 이후 `requestSequence_`를 0으로 초기화합니다.", "evidence": ["stop"], "covers": ["shutdown"], "kind": "behavior", "quote": "\\brief Stop capturing from all running streams and cancel pending requests\n * \\param[in] camera The camera to stop\n *\n * This function stops capturing and processing requests immediately. All\n * pending requests are cancelled and complete immediately in an error state.\n *\n * \\context This function is called from the CameraManager thread.\n */\nvoid PipelineHandler::stop(Camera *camera)\n{\n\t/*\n\t * Take all waiting requests so that they are not requeued in response\n\t * to completeRequest() being called inside stopDevice(). Cancel them\n\t * after the device to keep them in order.\n\t */\n\tCamera::Private *data = camera->_d();\n\tstd::queue<Request *> waitingRequests;\n\twaitingRequests.swap(data->waitingRequests_);\n\n\t/* Stop the pipeline handler and let the queued requests complete. */\n\tstopDevice(camera);\n\n\t/* Cancel and signal as complete all waiting requests. */\n\twhile (!waitingRequests.empty()) {\n\t\tRequest *request = waitingRequests.front();\n\t\twaitingRequests.pop();\n\n\t\t/*\n\t\t * Cancel all requests by marking them as cancelled and calling\n\t\t * doQueueRequest() instead of cancelRequest(). This ensures\n\t\t * that the requests get a sequence number and are temporarily\n\t\t * added to queuedRequests_ so they can be properly completed in\n\t\t * completeRequest().\n\t\t */\n\t\trequest->_d()->cancel();\n\t\tdoQueueRequest(request);\n\t}\n\n\t/* Make sure no requests are pending. */\n\tASSERT(data->queuedRequests_.empty());\n\tASSERT(data->waitingRequests_.empty());\n\n\tdata->requestSequence_ = 0;\n}\n\n/**\n * \\fn PipelineHandler::stopDevice()\n * \\brief Stop capturing from all running streams\n * \\param[in] camera The camera to stop\n *\n * This function stops capturing and processing requests immediately. All\n * pending requests are cancelled and complete immediately in an error state.\n */\n\n/**\n * \\brief Determine if the camera has any requests pending", "part_id": "assertions"}, {"text": "정상 완료 시 completeRequest는 끝에서 doQueueRequests를 호출하며, `waitingRequests_`가 비어 있지 않고 장치에 큐된 요청 수가 한도에 도달하지 않았으며 대기 큐의 맨 앞 요청이 준비된 경우에 해당 요청을 전달합니다. 정지 시 stop은 `waitingRequests_`를 먼저 분리하므로 stopDevice 안에서 완료 처리에 재진입해도 원래 대기 요청이 다시 제출되지 않습니다.", "evidence": ["completion", "stop", "waiting-dispatch"], "covers": ["shutdown"], "kind": "behavior", "quote": "\\brief Stop capturing from all running streams and cancel pending requests\n * \\param[in] camera The camera to stop\n *\n * This function stops capturing and processing requests immediately. All\n * pending requests are cancelled and complete immediately in an error state.\n *\n * \\context This function is called from the CameraManager thread.\n */\nvoid PipelineHandler::stop(Camera *camera)\n{\n\t/*\n\t * Take all waiting requests so that they are not requeued in response\n\t * to completeRequest() being called inside stopDevice(). Cancel them\n\t * after the device to keep them in order.\n\t */\n\tCamera::Private *data = camera->_d();\n\tstd::queue<Request *> waitingRequests;\n\twaitingRequests.swap(data->waitingRequests_);\n\n\t/* Stop the pipeline handler and let the queued requests complete. */\n\tstopDevice(camera);\n\n\t/* Cancel and signal as complete all waiting requests. */\n\twhile (!waitingRequests.empty()) {\n\t\tRequest *request = waitingRequests.front();\n\t\twaitingRequests.pop();\n\n\t\t/*\n\t\t * Cancel all requests by marking them as cancelled and calling\n\t\t * doQueueRequest() instead of cancelRequest(). This ensures\n\t\t * that the requests get a sequence number and are temporarily\n\t\t * added to queuedRequests_ so they can be properly completed in\n\t\t * completeRequest().\n\t\t */\n\t\trequest->_d()->cancel();\n\t\tdoQueueRequest(request);\n\t}\n\n\t/* Make sure no requests are pending. */\n\tASSERT(data->queuedRequests_.empty());\n\tASSERT(data->waitingRequests_.empty());\n\n\tdata->requestSequence_ = 0;\n}\n\n/**\n * \\fn PipelineHandler::stopDevice()\n * \\brief Stop capturing from all running streams\n * \\param[in] camera The camera to stop\n *\n * This function stops capturing and processing requests immediately. All\n * pending requests are cancelled and complete immediately in an error state.\n */\n\n/**\n * \\brief Determine if the camera has any requests pending", "part_id": "reentry"}], "input-search-boundary": [{"text": "minIfWidth는 입력 너비에서 kIFMaxCropWidth를 뺀 값과 kIFMaxCropWidth 중 큰 값입니다. minIfHeight는 입력 높이에서 kIFMaxCropHeight를 뺀 값과 kIFMaxCropHeight 중 큰 값입니다.", "evidence": ["search"], "covers": ["input-search-boundary"], "kind": "behavior", "quote": "float bdsSF = static_cast<float>(in.width) / gdc.width;\n\tfloat sf = findScaleFactor(bdsSF, bdsScalingFactors, true);\n\n\t/*\n\t * Populate the configurations vector by scaling width and height.\n\t *\n\t * calculateBDSHeight() crops up to kIFMaxCropHeight lines from the IF\n\t * height, so don't go below that, or its minimum IF height wraps.\n\t */\n\tunsigned int ifWidth = utils::alignUp(in.width, ImgUDevice::kIFAlignWidth);\n\tunsigned int ifHeight = utils::alignUp(in.height, ImgUDevice::kIFAlignHeight);\n\tunsigned int minIfWidth = std::max(in.width - ImgUDevice::kIFMaxCropWidth,\n\t\t\t\t\t   ImgUDevice::kIFMaxCropWidth);\n\tunsigned int minIfHeight = std::max(in.height - ImgUDevice::kIFMaxCropHeight,\n\t\t\t\t\t    ImgUDevice::kIFMaxCropHeight);\n\twhile (ifWidth >= minIfWidth) {\n\t\twhile (ifHeight >= minIfHeight) {\n\t\t\tSize iif{ ifWidth, ifHeight };\n\t\t\tcalculateBDS(pipe, iif, gdc, sf);\n\t\t\tifHeight -= ImgUDevice::kIFAlignHeight;\n\t\t}\n\n\t\tifWidth -= ImgUDevice::kIFAlignWidth;\n\t}\n\n\t/* Repeat search by scaling width first. */\n\tifWidth = utils::alignUp(in.width, ImgUDevice::kIFAlignWidth);\n\tifHeight = utils::alignUp(in.height, ImgUDevice::kIFAlignHeight);\n\twhile (ifHeight >= minIfHeight) {\n\t\t/*\n\t\t * \\todo This procedure is probably broken:\n\t\t * https://github.com/intel/intel-ipu3-pipecfg/issues/2\n\t\t */\n\t\twhile (ifWidth >= minIfWidth) {\n\t\t\tSize iif{ ifWidth, ifHeight };\n\t\t\tcalculateBDS(pipe, iif, gdc, sf);\n\t\t\tifWidth -= ImgUDevice::kIFAlignWidth;\n\t\t}\n\n\t\tifHeight -= ImgUDevice::kIFAlignHeight;\n\t}\n\n\tif (pipeConfigs.size() == 0) {", "part_id": "bounds"}, {"text": "첫 탐색은 폭을 바깥 반복, 높이를 안쪽 반복으로 두고, 두 번째 탐색은 높이를 바깥 반복, 폭을 안쪽 반복으로 두며, 각각 minIfWidth와 minIfHeight 이상인 동안 반복합니다. 두 번째 탐색 전에 폭과 높이를 alignUp으로 다시 초기화하며, 폭은 kIFAlignWidth만큼, 높이는 kIFAlignHeight만큼 감소합니다. calculateBDSHeight는 입력 포매터 높이에서 최대 kIFMaxCropHeight줄을 자르므로, 높이가 이 값보다 작으면 부호 없는 최소 높이 차감값이 감깁니다.", "evidence": ["search", "height-bound"], "covers": ["input-search-boundary"], "kind": "behavior", "quote": "float bdsSF = static_cast<float>(in.width) / gdc.width;\n\tfloat sf = findScaleFactor(bdsSF, bdsScalingFactors, true);\n\n\t/*\n\t * Populate the configurations vector by scaling width and height.\n\t *\n\t * calculateBDSHeight() crops up to kIFMaxCropHeight lines from the IF\n\t * height, so don't go below that, or its minimum IF height wraps.\n\t */\n\tunsigned int ifWidth = utils::alignUp(in.width, ImgUDevice::kIFAlignWidth);\n\tunsigned int ifHeight = utils::alignUp(in.height, ImgUDevice::kIFAlignHeight);\n\tunsigned int minIfWidth = std::max(in.width - ImgUDevice::kIFMaxCropWidth,\n\t\t\t\t\t   ImgUDevice::kIFMaxCropWidth);\n\tunsigned int minIfHeight = std::max(in.height - ImgUDevice::kIFMaxCropHeight,\n\t\t\t\t\t    ImgUDevice::kIFMaxCropHeight);\n\twhile (ifWidth >= minIfWidth) {\n\t\twhile (ifHeight >= minIfHeight) {\n\t\t\tSize iif{ ifWidth, ifHeight };\n\t\t\tcalculateBDS(pipe, iif, gdc, sf);\n\t\t\tifHeight -= ImgUDevice::kIFAlignHeight;\n\t\t}\n\n\t\tifWidth -= ImgUDevice::kIFAlignWidth;\n\t}\n\n\t/* Repeat search by scaling width first. */\n\tifWidth = utils::alignUp(in.width, ImgUDevice::kIFAlignWidth);\n\tifHeight = utils::alignUp(in.height, ImgUDevice::kIFAlignHeight);\n\twhile (ifHeight >= minIfHeight) {\n\t\t/*\n\t\t * \\todo This procedure is probably broken:\n\t\t * https://github.com/intel/intel-ipu3-pipecfg/issues/2\n\t\t */\n\t\twhile (ifWidth >= minIfWidth) {\n\t\t\tSize iif{ ifWidth, ifHeight };\n\t\t\tcalculateBDS(pipe, iif, gdc, sf);\n\t\t\tifWidth -= ImgUDevice::kIFAlignWidth;\n\t\t}\n\n\t\tifHeight -= ImgUDevice::kIFAlignHeight;\n\t}\n\n\tif (pipeConfigs.size() == 0) {", "part_id": "search-order"}]}, "topic_inputs": {"responsibility": "eef85d8be6f542cdf13d8cebca75d8215053988f4499d4ef6551adaf2b83b09e", "configuration": "84d2c72cbd64ff89f146a708786edf69af77864bf2d8ad9b4058e5619496f837", "shutdown": "db960bad94ed71a4bb80c5ab493d6cc3a897675fc44bcc962d2a6725534f636b", "input-search-boundary": "9e6faef2f976a4c90dc303dcdcd026a5b21f561727c778fe5acc67cafcd2552a"}, "reused_topics": [], "replayed_units": [], "generated_topics": ["responsibility", "configuration", "shutdown", "input-search-boundary"], "topic_agents": {"responsibility": "cli/codex/gpt-6.1-terra", "configuration": "cli/codex/gpt-6.1-terra", "shutdown": "cli/codex/gpt-6.1-terra", "input-search-boundary": "cli/codex/gpt-6.1-terra"}, "grounding_review": "not-run", "grounding_policy": null, "validation_policy": {"manuscript": "367d18b95f8f0d01a15ae0f4d1b70f7e13e4d0298df4215e2c449ac4905db6f9", "semantic": "571896e4854c21322a1ce4580107c235cae5a9f94e71adc8c97a7e2897405968", "duplicates": "93f0e8b5bdc1b40bf4ab38168e92c2772aa36747bec6add25921fbb90b909e38", "design_contracts": "9f54ecddce57c7a9caa6c02af77904b57eff2471f2a052951c1cffd18256a4f0", "validate": "78d29ffd1bf6235067edf5a0c7d9b1290f1f11e90599605a0e192e90be5f3372", "reader_profiles": "ad9005d08295212371f59e8934ace86786c0683f7a4c416301ee0e0cadc8b797", "contract_schema": "2f593eec0430a4e6b5822e642c0a7a1227fc150a0b27d8a71f521acf93b6439e", "answer_contracts": "1e0d24e0cf26ded53ecec2e5a6fbc51836bac6e17530318a9fa7cffaa936c00b", "reader_scope": "1b9c26b10b74ae8cf034f5863cbac2114e1d844e5d8332eb1f10562a18371782", "product_context": "57cc3233cfdcf429751f31081ffca06a8f8b53fb15fb1e3a5256aa7998a8ceb4", "design_response": "deb70dda7ad27f001267e4a9712c5b0dc1fe9fa67acd13bedbfefaaad0ad83c8", "design_validation": "0613b830b96fd2828171dea499807c3366edd72208ed814a95e5228dd106dd73"}, "validation_model": "6de3b1c1e9b26febdd619404dccbe52a0e1c262185462f092ef089e4468fdb2f", "style_policy": {"fluent-korean.md": "ce5aa71e58371e3fc02ff8cb165e07c9234f5166f6541423a91cc4cb40878975", "i-have-adhd.md": "3170b16ace00aecb0dd7feb54c0b5aa642e7502acda06ecd24fd89a11c7127e9", "README.md": "b87a84b1bc31079837dc4dc4527ce02c9dc2cbc3a26ff7e99e0872941d213995"}, "checkpoint_units": [{"checkpoint": "1bec08b0cc1b8c2760f0a4c9602ec255ce2c9dc3445d065cd46a017a778a1405.json", "topic": "responsibility", "part": null, "subpart": null, "revalidated": false, "new_grounding_review": false, "receipts": ["66d32ce686f948cda91ece8956c80b73/001.receipt.json"]}, {"checkpoint": "f74e3d103afe4e3e8933646e214aeeab95e921a1732939af185253c2a84ca6ce.json", "topic": "configuration", "part": null, "subpart": null, "revalidated": false, "new_grounding_review": false, "receipts": ["66d32ce686f948cda91ece8956c80b73/002.receipt.json"]}, {"checkpoint": "0aa132eb0468d91def455bfc2d01994e2bbb3bf82e98125eacbb74b73bc5630f.json", "topic": "shutdown", "part": "detach", "subpart": null, "revalidated": false, "new_grounding_review": false, "receipts": ["66d32ce686f948cda91ece8956c80b73/003.receipt.json"]}, {"checkpoint": "e7dd2a4e3daf4e6eec21e118894e6916ac5f9cf7d9cd3d2ef0c2169b67bdf7c8.json", "topic": "shutdown", "part": "pending", "subpart": null, "revalidated": false, "new_grounding_review": false, "receipts": ["66d32ce686f948cda91ece8956c80b73/004.receipt.json"]}, {"checkpoint": "72b3898c4f83eb92e26839de17c3e08a3b767415794c1afa7ee42476b7f50ddf.json", "topic": "shutdown", "part": "device-duty", "subpart": null, "revalidated": false, "new_grounding_review": false, "receipts": ["66d32ce686f948cda91ece8956c80b73/005.receipt.json"]}, {"checkpoint": "c92f1551650cc13ce7964fb92c9eb5e931e0b27c47dd2cc9b9004d502a7a128d.json", "topic": "shutdown", "part": "assertions", "subpart": null, "revalidated": false, "new_grounding_review": false, "receipts": ["66d32ce686f948cda91ece8956c80b73/006.receipt.json"]}, {"checkpoint": "093aab436760cb3f5a3806ad86f8f768b360de04fee201126f910b2cd3e66c89.json", "topic": "shutdown", "part": "reentry", "subpart": null, "revalidated": false, "new_grounding_review": false, "receipts": ["66d32ce686f948cda91ece8956c80b73/007.receipt.json"]}, {"checkpoint": "7cc06fae02adf62d8dfcd5f9c2d3f882af901481e0791f1baadd0b2838791a77.json", "topic": "input-search-boundary", "part": "bounds", "subpart": null, "revalidated": false, "new_grounding_review": false, "receipts": ["69f7f92924bc4e4c8291ea931f12e853/001.receipt.json"]}, {"checkpoint": "916281209e7ab4be6d6db332539849928413b93d4b572de01a1fa3f7e7f6b063.json", "topic": "input-search-boundary", "part": "search-order", "subpart": null, "revalidated": false, "new_grounding_review": false, "receipts": ["69f7f92924bc4e4c8291ea931f12e853/002.receipt.json"]}], "body_sha256": "a04630c022eb1987324d4d5f925ed06b9ef7aa840a39b0d2d2cb987fb18150b9"}
generated_visuals: {"schema": 1, "records": {"stop-waiting-requests": {"input_fingerprint": "447b9ca623230440c01f27f51d6cc1ba4b767f5901fff833982ce7d28bb50875", "draft": {"nodes": [{"id": "waiting", "symbol": "waitingRequests_", "label": "waitingRequests_를 지역 waitingRequests와 swap해 대기 요청을 분리합니다.", "label_en": "Swap waitingRequests_ into local waitingRequests to separate the waiting requests.", "shape": "process", "quote_ids": ["stop:0"]}, {"id": "stop", "symbol": "stopDevice", "label": "stopDevice는 모든 실행 중인 스트림의 캡처와 요청 처리를 즉시 중단하고, 제출된 요청을 취소해 오류 상태로 즉시 완료해야 합니다.", "label_en": "stopDevice must immediately stop capture on all running streams and request processing, and cancel and immediately complete submitted requests in error.", "shape": "process", "quote_ids": ["stop:1", "stop:6"]}, {"id": "check", "symbol": "waitingRequests", "label": "지역 waitingRequests에 요청이 남았는지 확인합니다.", "label_en": "Check whether local waitingRequests has requests left.", "shape": "decision", "quote_ids": ["stop:2"]}, {"id": "cancel", "symbol": "cancel", "label": "지역 큐의 앞 요청을 꺼내 cancel로 취소 표시합니다.", "label_en": "Pop the front request from the local queue and mark it cancelled with cancel.", "shape": "process", "quote_ids": ["stop:2", "stop:3"]}, {"id": "queue", "symbol": "doQueueRequest", "label": "doQueueRequest는 요청을 queuedRequests_에 추가한 뒤 순번을 부여합니다.", "label_en": "doQueueRequest adds the request to queuedRequests_, then assigns a sequence number.", "shape": "process", "quote_ids": ["cancelled-dispatch:0", "cancelled-dispatch:1", "cancelled-dispatch:2"]}, {"id": "complete", "symbol": "completeRequest", "label": "completeRequest는 앱에 제출 순서로 알립니다. 반환 후 핸들러는 요청을 더 이상 관리하지 않으며 접근하면 안 됩니다.", "label_en": "completeRequest notifies the app in submission order; after this call returns, the handler no longer manages the request and no handler access is allowed.", "shape": "process", "quote_ids": ["completion:1"]}, {"id": "end", "symbol": "ASSERT", "label": "두 큐가 비었는지 ASSERT로 확인하고 requestSequence_를 0으로 초기화합니다.", "label_en": "ASSERT that both queues are empty, then reset requestSequence_ to 0.", "shape": "process", "quote_ids": ["stop:4", "stop:5"]}], "edges": [{"from": "waiting", "to": "stop", "label": "지역 큐를 분리한 뒤 장치를 정지합니다.", "label_en": "Stop the device after separating the local queue.", "condition_ref": "always", "quote_ids": ["stop:0", "stop:1"]}, {"from": "stop", "to": "check", "label": "stopDevice가 반환하면 지역 큐를 확인합니다.", "label_en": "Check the local queue after stopDevice returns.", "condition_ref": "always", "quote_ids": ["stop:1", "stop:2"]}, {"from": "check", "to": "cancel", "label": "요청이 남아 있으면 꺼내 취소 표시합니다.", "label_en": "Pop and mark the request cancelled if one remains.", "condition_ref": "c1:true", "quote_ids": ["stop:2", "stop:3"]}, {"from": "check", "to": "end", "label": "지역 큐가 비면 두 큐를 확인합니다.", "label_en": "If the local queue is empty, check both queues.", "condition_ref": "c1:false", "quote_ids": ["stop:2", "stop:4"]}, {"from": "cancel", "to": "queue", "label": "취소 표시 후 doQueueRequest를 호출합니다.", "label_en": "Call doQueueRequest after marking the request cancelled.", "condition_ref": "always", "quote_ids": ["stop:3"]}, {"from": "queue", "to": "complete", "label": "취소된 요청을 완료하고 장치 제출을 건너뜁니다.", "label_en": "Complete cancelled request; skip device submission.", "condition_ref": "c3:true", "quote_ids": ["cancelled-dispatch:0", "cancelled-dispatch:3", "cancelled-dispatch:4"]}, {"from": "complete", "to": "check", "label": "completeRequest와 doQueueRequest가 반환하면 다시 확인합니다.", "label_en": "After both calls return, check the local queue again.", "condition_ref": "always", "quote_ids": ["cancelled-dispatch:0", "cancelled-dispatch:3", "stop:2", "stop:3"]}]}, "graph": {"id": "stop-waiting-requests", "topic": "shutdown", "kind": "flow", "title": "정지할 때 대기 요청을 분리하고 완료하는 순서", "question": "정지 함수는 지역 대기 큐의 요청을 어떤 순서로 취소·완료하고 마지막 큐 검사와 순번 초기화를 마칩니까?", "condition_display": "evidence", "nodes": [{"id": "waiting", "label": "waitingRequests_를 지역 waitingRequests와 swap해 대기 요청을 분리합니다.", "label_en": "Swap waitingRequests_ into local waitingRequests to separate the waiting requests.", "shape": "box", "evidence": [{"source": "shutdown/stop", "sha256": "108b1bea5a8314ba57213d15c1e3ba01abe2b3f8a9e0e1e1281864b5492c7304", "quote": "\\brief Stop capturing from all running streams and cancel pending requests\n * \\param[in] camera The camera to stop\n *\n * This function stops capturing and processing requests immediately. All\n * pending requests are cancelled and complete immediately in an error state.\n *\n * \\context This function is called from the CameraManager thread.\n */\nvoid PipelineHandler::stop(Camera *camera)\n{\n\t/*\n\t * Take all waiting requests so that they are not requeued in response\n\t * to completeRequest() being called inside stopDevice(). Cancel them\n\t * after the device to keep them in order.\n\t */\n\tCamera::Private *data = camera->_d();\n\tstd::queue<Request *> waitingRequests;\n\twaitingRequests.swap(data->waitingRequests_);"}]}, {"id": "stop", "label": "stopDevice는 모든 실행 중인 스트림의 캡처와 요청 처리를 즉시 중단하고, 제출된 요청을 취소해 오류 상태로 즉시 완료해야 합니다.", "label_en": "stopDevice must immediately stop capture on all running streams and request processing, and cancel and immediately complete submitted requests in error.", "shape": "box", "evidence": [{"source": "shutdown/stop", "sha256": "108b1bea5a8314ba57213d15c1e3ba01abe2b3f8a9e0e1e1281864b5492c7304", "quote": "/* Stop the pipeline handler and let the queued requests complete. */\n\tstopDevice(camera);"}, {"source": "shutdown/stop", "sha256": "108b1bea5a8314ba57213d15c1e3ba01abe2b3f8a9e0e1e1281864b5492c7304", "quote": "/**\n * \\fn PipelineHandler::stopDevice()\n * \\brief Stop capturing from all running streams\n * \\param[in] camera The camera to stop\n *\n * This function stops capturing and processing requests immediately. All\n * pending requests are cancelled and complete immediately in an error state.\n */"}]}, {"id": "check", "label": "지역 waitingRequests에 요청이 남았는지 확인합니다.", "label_en": "Check whether local waitingRequests has requests left.", "shape": "decision", "evidence": [{"source": "shutdown/stop", "sha256": "108b1bea5a8314ba57213d15c1e3ba01abe2b3f8a9e0e1e1281864b5492c7304", "quote": "/* Cancel and signal as complete all waiting requests. */\n\twhile (!waitingRequests.empty()) {\n\t\tRequest *request = waitingRequests.front();\n\t\twaitingRequests.pop();"}]}, {"id": "cancel", "label": "지역 큐의 앞 요청을 꺼내 cancel로 취소 표시합니다.", "label_en": "Pop the front request from the local queue and mark it cancelled with cancel.", "shape": "box", "evidence": [{"source": "shutdown/stop", "sha256": "108b1bea5a8314ba57213d15c1e3ba01abe2b3f8a9e0e1e1281864b5492c7304", "quote": "/* Cancel and signal as complete all waiting requests. */\n\twhile (!waitingRequests.empty()) {\n\t\tRequest *request = waitingRequests.front();\n\t\twaitingRequests.pop();"}, {"source": "shutdown/stop", "sha256": "108b1bea5a8314ba57213d15c1e3ba01abe2b3f8a9e0e1e1281864b5492c7304", "quote": "/*\n\t\t * Cancel all requests by marking them as cancelled and calling\n\t\t * doQueueRequest() instead of cancelRequest(). This ensures\n\t\t * that the requests get a sequence number and are temporarily\n\t\t * added to queuedRequests_ so they can be properly completed in\n\t\t * completeRequest().\n\t\t */\n\t\trequest->_d()->cancel();\n\t\tdoQueueRequest(request);\n\t}"}]}, {"id": "queue", "label": "doQueueRequest는 요청을 queuedRequests_에 추가한 뒤 순번을 부여합니다.", "label_en": "doQueueRequest adds the request to queuedRequests_, then assigns a sequence number.", "shape": "box", "evidence": [{"source": "shutdown/cancelled-dispatch", "sha256": "fbd3ed6fe295b1cdd82d6ce420a30695986e43199347f92ac2545fe0e7831da8", "quote": "void PipelineHandler::doQueueRequest(Request *request)\n{\n\tLIBCAMERA_TRACEPOINT(request_device_queue, request);"}, {"source": "shutdown/cancelled-dispatch", "sha256": "fbd3ed6fe295b1cdd82d6ce420a30695986e43199347f92ac2545fe0e7831da8", "quote": "Camera *camera = request->_d()->camera();\n\tCamera::Private *data = camera->_d();\n\tdata->queuedRequests_.push_back(request);"}, {"source": "shutdown/cancelled-dispatch", "sha256": "fbd3ed6fe295b1cdd82d6ce420a30695986e43199347f92ac2545fe0e7831da8", "quote": "request->_d()->sequence_ = data->requestSequence_++;"}]}, {"id": "complete", "label": "completeRequest는 앱에 제출 순서로 알립니다. 반환 후 핸들러는 요청을 더 이상 관리하지 않으며 접근하면 안 됩니다.", "label_en": "completeRequest notifies the app in submission order; after this call returns, the handler no longer manages the request and no handler access is allowed.", "shape": "box", "evidence": [{"source": "shutdown/completion", "sha256": "514288cc958de9ff5fd19d46393cec3bb3088f4f08486528d4559071138638c9", "quote": "/**\n * \\brief Signal request completion\n * \\param[in] request The request that has completed\n *\n * The pipeline handler shall call this function to notify the \\a camera that\n * the request has completed. The request is no longer managed by the pipeline\n * handler and shall not be accessed once this function returns.\n *\n * This function ensures that requests will be returned to the application in\n * submission order, the pipeline handler may call it on any complete request\n * without any ordering constraint.\n *\n * \\context This function shall be called from the CameraManager thread.\n */\nvoid PipelineHandler::completeRequest(Request *request)\n{\n\tCamera *camera = request->_d()->camera();"}]}, {"id": "end", "label": "두 큐가 비었는지 ASSERT로 확인하고 requestSequence_를 0으로 초기화합니다.", "label_en": "ASSERT that both queues are empty, then reset requestSequence_ to 0.", "shape": "box", "evidence": [{"source": "shutdown/stop", "sha256": "108b1bea5a8314ba57213d15c1e3ba01abe2b3f8a9e0e1e1281864b5492c7304", "quote": "/* Make sure no requests are pending. */\n\tASSERT(data->queuedRequests_.empty());\n\tASSERT(data->waitingRequests_.empty());"}, {"source": "shutdown/stop", "sha256": "108b1bea5a8314ba57213d15c1e3ba01abe2b3f8a9e0e1e1281864b5492c7304", "quote": "data->requestSequence_ = 0;\n}"}]}], "edges": [{"from": "waiting", "to": "stop", "label": "지역 큐를 분리한 뒤 장치를 정지합니다.", "label_en": "Stop the device after separating the local queue.", "evidence": [{"source": "shutdown/stop", "sha256": "108b1bea5a8314ba57213d15c1e3ba01abe2b3f8a9e0e1e1281864b5492c7304", "quote": "\\brief Stop capturing from all running streams and cancel pending requests\n * \\param[in] camera The camera to stop\n *\n * This function stops capturing and processing requests immediately. All\n * pending requests are cancelled and complete immediately in an error state.\n *\n * \\context This function is called from the CameraManager thread.\n */\nvoid PipelineHandler::stop(Camera *camera)\n{\n\t/*\n\t * Take all waiting requests so that they are not requeued in response\n\t * to completeRequest() being called inside stopDevice(). Cancel them\n\t * after the device to keep them in order.\n\t */\n\tCamera::Private *data = camera->_d();\n\tstd::queue<Request *> waitingRequests;\n\twaitingRequests.swap(data->waitingRequests_);"}, {"source": "shutdown/stop", "sha256": "108b1bea5a8314ba57213d15c1e3ba01abe2b3f8a9e0e1e1281864b5492c7304", "quote": "/* Stop the pipeline handler and let the queued requests complete. */\n\tstopDevice(camera);"}]}, {"from": "stop", "to": "check", "label": "stopDevice가 반환하면 지역 큐를 확인합니다.", "label_en": "Check the local queue after stopDevice returns.", "evidence": [{"source": "shutdown/stop", "sha256": "108b1bea5a8314ba57213d15c1e3ba01abe2b3f8a9e0e1e1281864b5492c7304", "quote": "/* Stop the pipeline handler and let the queued requests complete. */\n\tstopDevice(camera);"}, {"source": "shutdown/stop", "sha256": "108b1bea5a8314ba57213d15c1e3ba01abe2b3f8a9e0e1e1281864b5492c7304", "quote": "/* Cancel and signal as complete all waiting requests. */\n\twhile (!waitingRequests.empty()) {\n\t\tRequest *request = waitingRequests.front();\n\t\twaitingRequests.pop();"}]}, {"from": "check", "to": "cancel", "label": "요청이 남아 있으면 꺼내 취소 표시합니다. · !waitingRequests.empty() [true]", "label_en": "Pop and mark the request cancelled if one remains. · !waitingRequests.empty() [true]", "evidence": [{"source": "shutdown/stop", "sha256": "108b1bea5a8314ba57213d15c1e3ba01abe2b3f8a9e0e1e1281864b5492c7304", "quote": "/* Cancel and signal as complete all waiting requests. */\n\twhile (!waitingRequests.empty()) {\n\t\tRequest *request = waitingRequests.front();\n\t\twaitingRequests.pop();"}, {"source": "shutdown/stop", "sha256": "108b1bea5a8314ba57213d15c1e3ba01abe2b3f8a9e0e1e1281864b5492c7304", "quote": "/*\n\t\t * Cancel all requests by marking them as cancelled and calling\n\t\t * doQueueRequest() instead of cancelRequest(). This ensures\n\t\t * that the requests get a sequence number and are temporarily\n\t\t * added to queuedRequests_ so they can be properly completed in\n\t\t * completeRequest().\n\t\t */\n\t\trequest->_d()->cancel();\n\t\tdoQueueRequest(request);\n\t}"}]}, {"from": "check", "to": "end", "label": "지역 큐가 비면 두 큐를 확인합니다. · !waitingRequests.empty() [false]", "label_en": "If the local queue is empty, check both queues. · !waitingRequests.empty() [false]", "evidence": [{"source": "shutdown/stop", "sha256": "108b1bea5a8314ba57213d15c1e3ba01abe2b3f8a9e0e1e1281864b5492c7304", "quote": "/* Cancel and signal as complete all waiting requests. */\n\twhile (!waitingRequests.empty()) {\n\t\tRequest *request = waitingRequests.front();\n\t\twaitingRequests.pop();"}, {"source": "shutdown/stop", "sha256": "108b1bea5a8314ba57213d15c1e3ba01abe2b3f8a9e0e1e1281864b5492c7304", "quote": "/* Make sure no requests are pending. */\n\tASSERT(data->queuedRequests_.empty());\n\tASSERT(data->waitingRequests_.empty());"}]}, {"from": "cancel", "to": "queue", "label": "취소 표시 후 doQueueRequest를 호출합니다.", "label_en": "Call doQueueRequest after marking the request cancelled.", "evidence": [{"source": "shutdown/stop", "sha256": "108b1bea5a8314ba57213d15c1e3ba01abe2b3f8a9e0e1e1281864b5492c7304", "quote": "/*\n\t\t * Cancel all requests by marking them as cancelled and calling\n\t\t * doQueueRequest() instead of cancelRequest(). This ensures\n\t\t * that the requests get a sequence number and are temporarily\n\t\t * added to queuedRequests_ so they can be properly completed in\n\t\t * completeRequest().\n\t\t */\n\t\trequest->_d()->cancel();\n\t\tdoQueueRequest(request);\n\t}"}]}, {"from": "queue", "to": "complete", "label": "취소된 요청을 완료하고 장치 제출을 건너뜁니다. · request->_d()->cancelled_ [true]", "label_en": "Complete cancelled request; skip device submission. · request->_d()->cancelled_ [true]", "evidence": [{"source": "shutdown/cancelled-dispatch", "sha256": "fbd3ed6fe295b1cdd82d6ce420a30695986e43199347f92ac2545fe0e7831da8", "quote": "void PipelineHandler::doQueueRequest(Request *request)\n{\n\tLIBCAMERA_TRACEPOINT(request_device_queue, request);"}, {"source": "shutdown/cancelled-dispatch", "sha256": "fbd3ed6fe295b1cdd82d6ce420a30695986e43199347f92ac2545fe0e7831da8", "quote": "if (request->_d()->cancelled_) {\n\t\tcompleteRequest(request);\n\t\treturn;\n\t}"}, {"source": "shutdown/cancelled-dispatch", "sha256": "fbd3ed6fe295b1cdd82d6ce420a30695986e43199347f92ac2545fe0e7831da8", "quote": "int ret = queueRequestDevice(camera, request);\n\tif (ret)\n\t\tcancelRequest(request);\n}"}]}, {"from": "complete", "to": "check", "label": "completeRequest와 doQueueRequest가 반환하면 다시 확인합니다.", "label_en": "After both calls return, check the local queue again.", "evidence": [{"source": "shutdown/cancelled-dispatch", "sha256": "fbd3ed6fe295b1cdd82d6ce420a30695986e43199347f92ac2545fe0e7831da8", "quote": "void PipelineHandler::doQueueRequest(Request *request)\n{\n\tLIBCAMERA_TRACEPOINT(request_device_queue, request);"}, {"source": "shutdown/cancelled-dispatch", "sha256": "fbd3ed6fe295b1cdd82d6ce420a30695986e43199347f92ac2545fe0e7831da8", "quote": "if (request->_d()->cancelled_) {\n\t\tcompleteRequest(request);\n\t\treturn;\n\t}"}, {"source": "shutdown/stop", "sha256": "108b1bea5a8314ba57213d15c1e3ba01abe2b3f8a9e0e1e1281864b5492c7304", "quote": "/* Cancel and signal as complete all waiting requests. */\n\twhile (!waitingRequests.empty()) {\n\t\tRequest *request = waitingRequests.front();\n\t\twaitingRequests.pop();"}, {"source": "shutdown/stop", "sha256": "108b1bea5a8314ba57213d15c1e3ba01abe2b3f8a9e0e1e1281864b5492c7304", "quote": "/*\n\t\t * Cancel all requests by marking them as cancelled and calling\n\t\t * doQueueRequest() instead of cancelRequest(). This ensures\n\t\t * that the requests get a sequence number and are temporarily\n\t\t * added to queuedRequests_ so they can be properly completed in\n\t\t * completeRequest().\n\t\t */\n\t\trequest->_d()->cancel();\n\t\tdoQueueRequest(request);\n\t}"}]}], "producer": "cli/codex/gpt-6.1-terra"}, "producer": "cli/codex/gpt-6.1-terra", "generation_commit": "293d751a814e0d4c34e85ad457ccd9d5eefd1a61", "reused": false}, "stop-completion-reentry": {"input_fingerprint": "063fbfb8e062f6058945fdf0c94c6c347967c1f96bf4ad67a5727750457b5eb6", "draft": {"nodes": [{"id": "shared", "symbol": "waitingRequests_", "label": "공유 waitingRequests_는 doQueueRequests가 조회하는 큐입니다.", "label_en": "The shared waitingRequests_ is the queue checked by doQueueRequests.", "shape": "box", "quote_ids": ["waiting-dispatch:0"]}, {"id": "local", "symbol": "waitingRequests", "label": "분리한 기존 요청은 지역 waitingRequests에 있어 공유 큐 조회에 포함되지 않습니다.", "label_en": "The separated existing requests are in local waitingRequests, outside the shared queue check.", "shape": "box", "quote_ids": ["stop:0", "waiting-dispatch:0"]}, {"id": "stopdevice", "symbol": "stopDevice", "label": "stopDevice 안에서 completeRequest가 호출될 수 있습니다.", "label_en": "completeRequest may be called inside stopDevice.", "shape": "process", "quote_ids": ["stop:0"]}, {"id": "complete", "symbol": "completeRequest", "label": "completeRequest는 끝에서 doQueueRequests를 호출합니다.", "label_en": "completeRequest calls doQueueRequests at the end.", "shape": "process", "quote_ids": ["completion:1", "completion:6"]}, {"id": "dispatch", "symbol": "doQueueRequests", "label": "doQueueRequests는 공유 waitingRequests_를 조회합니다.", "label_en": "doQueueRequests checks the shared waitingRequests_.", "shape": "process", "quote_ids": ["waiting-dispatch:0"]}], "edges": [{"from": "shared", "to": "local", "label": "swap으로 기존 대기 요청을 지역 큐로 옮깁니다.", "label_en": "swap moves existing waiting requests to the local queue.", "condition_ref": "always", "quote_ids": ["stop:0"]}, {"from": "stopdevice", "to": "complete", "label": "안에서 호출될 수 있습니다.", "label_en": "It may call completeRequest inside stopDevice.", "condition_ref": "always", "quote_ids": ["stop:0"]}, {"from": "complete", "to": "dispatch", "label": "함수 끝에서 호출합니다.", "label_en": "It calls doQueueRequests at the end.", "condition_ref": "always", "quote_ids": ["completion:1", "completion:6"]}, {"from": "dispatch", "to": "shared", "label": "공유 큐를 조회합니다.", "label_en": "It checks the shared queue.", "condition_ref": "always", "quote_ids": ["waiting-dispatch:0"]}]}, "graph": {"id": "stop-completion-reentry", "topic": "shutdown", "kind": "ownership", "title": "완료 처리의 재진입은 분리한 대기 요청을 다시 제출하지 않습니다", "question": "완료 처리의 재진입이 검사하는 공유 큐와 정지가 분리해 보유하는 지역 큐는 어떻게 다릅니까?", "condition_display": "evidence", "nodes": [{"id": "shared", "label": "공유 waitingRequests_는 doQueueRequests가 조회하는 큐입니다.", "label_en": "The shared waitingRequests_ is the queue checked by doQueueRequests.", "shape": "box", "evidence": [{"source": "shutdown/waiting-dispatch", "sha256": "b2d2d134eaa639300cae5e7660d8453da545646bcc100bf640a981fa1371899d", "quote": "void PipelineHandler::doQueueRequests(Camera *camera)\n{\n\tCamera::Private *data = camera->_d();\n\twhile (!data->waitingRequests_.empty()) {\n\t\tif (data->queuedRequests_.size() == maxQueuedRequestsDevice_)\n\t\t\tbreak;"}]}, {"id": "local", "label": "분리한 기존 요청은 지역 waitingRequests에 있어 공유 큐 조회에 포함되지 않습니다.", "label_en": "The separated existing requests are in local waitingRequests, outside the shared queue check.", "shape": "box", "evidence": [{"source": "shutdown/stop", "sha256": "108b1bea5a8314ba57213d15c1e3ba01abe2b3f8a9e0e1e1281864b5492c7304", "quote": "\\brief Stop capturing from all running streams and cancel pending requests\n * \\param[in] camera The camera to stop\n *\n * This function stops capturing and processing requests immediately. All\n * pending requests are cancelled and complete immediately in an error state.\n *\n * \\context This function is called from the CameraManager thread.\n */\nvoid PipelineHandler::stop(Camera *camera)\n{\n\t/*\n\t * Take all waiting requests so that they are not requeued in response\n\t * to completeRequest() being called inside stopDevice(). Cancel them\n\t * after the device to keep them in order.\n\t */\n\tCamera::Private *data = camera->_d();\n\tstd::queue<Request *> waitingRequests;\n\twaitingRequests.swap(data->waitingRequests_);"}, {"source": "shutdown/waiting-dispatch", "sha256": "b2d2d134eaa639300cae5e7660d8453da545646bcc100bf640a981fa1371899d", "quote": "void PipelineHandler::doQueueRequests(Camera *camera)\n{\n\tCamera::Private *data = camera->_d();\n\twhile (!data->waitingRequests_.empty()) {\n\t\tif (data->queuedRequests_.size() == maxQueuedRequestsDevice_)\n\t\t\tbreak;"}]}, {"id": "stopdevice", "label": "stopDevice 안에서 completeRequest가 호출될 수 있습니다.", "label_en": "completeRequest may be called inside stopDevice.", "shape": "box", "evidence": [{"source": "shutdown/stop", "sha256": "108b1bea5a8314ba57213d15c1e3ba01abe2b3f8a9e0e1e1281864b5492c7304", "quote": "\\brief Stop capturing from all running streams and cancel pending requests\n * \\param[in] camera The camera to stop\n *\n * This function stops capturing and processing requests immediately. All\n * pending requests are cancelled and complete immediately in an error state.\n *\n * \\context This function is called from the CameraManager thread.\n */\nvoid PipelineHandler::stop(Camera *camera)\n{\n\t/*\n\t * Take all waiting requests so that they are not requeued in response\n\t * to completeRequest() being called inside stopDevice(). Cancel them\n\t * after the device to keep them in order.\n\t */\n\tCamera::Private *data = camera->_d();\n\tstd::queue<Request *> waitingRequests;\n\twaitingRequests.swap(data->waitingRequests_);"}]}, {"id": "complete", "label": "completeRequest는 끝에서 doQueueRequests를 호출합니다.", "label_en": "completeRequest calls doQueueRequests at the end.", "shape": "box", "evidence": [{"source": "shutdown/completion", "sha256": "514288cc958de9ff5fd19d46393cec3bb3088f4f08486528d4559071138638c9", "quote": "/**\n * \\brief Signal request completion\n * \\param[in] request The request that has completed\n *\n * The pipeline handler shall call this function to notify the \\a camera that\n * the request has completed. The request is no longer managed by the pipeline\n * handler and shall not be accessed once this function returns.\n *\n * This function ensures that requests will be returned to the application in\n * submission order, the pipeline handler may call it on any complete request\n * without any ordering constraint.\n *\n * \\context This function shall be called from the CameraManager thread.\n */\nvoid PipelineHandler::completeRequest(Request *request)\n{\n\tCamera *camera = request->_d()->camera();"}, {"source": "shutdown/completion", "sha256": "514288cc958de9ff5fd19d46393cec3bb3088f4f08486528d4559071138638c9", "quote": "/* Allow any waiting requests to be queued to the pipeline. */\n\tdoQueueRequests(camera);\n}"}]}, {"id": "dispatch", "label": "doQueueRequests는 공유 waitingRequests_를 조회합니다.", "label_en": "doQueueRequests checks the shared waitingRequests_.", "shape": "box", "evidence": [{"source": "shutdown/waiting-dispatch", "sha256": "b2d2d134eaa639300cae5e7660d8453da545646bcc100bf640a981fa1371899d", "quote": "void PipelineHandler::doQueueRequests(Camera *camera)\n{\n\tCamera::Private *data = camera->_d();\n\twhile (!data->waitingRequests_.empty()) {\n\t\tif (data->queuedRequests_.size() == maxQueuedRequestsDevice_)\n\t\t\tbreak;"}]}], "edges": [{"from": "shared", "to": "local", "label": "swap으로 기존 대기 요청을 지역 큐로 옮깁니다.", "label_en": "swap moves existing waiting requests to the local queue.", "evidence": [{"source": "shutdown/stop", "sha256": "108b1bea5a8314ba57213d15c1e3ba01abe2b3f8a9e0e1e1281864b5492c7304", "quote": "\\brief Stop capturing from all running streams and cancel pending requests\n * \\param[in] camera The camera to stop\n *\n * This function stops capturing and processing requests immediately. All\n * pending requests are cancelled and complete immediately in an error state.\n *\n * \\context This function is called from the CameraManager thread.\n */\nvoid PipelineHandler::stop(Camera *camera)\n{\n\t/*\n\t * Take all waiting requests so that they are not requeued in response\n\t * to completeRequest() being called inside stopDevice(). Cancel them\n\t * after the device to keep them in order.\n\t */\n\tCamera::Private *data = camera->_d();\n\tstd::queue<Request *> waitingRequests;\n\twaitingRequests.swap(data->waitingRequests_);"}]}, {"from": "stopdevice", "to": "complete", "label": "안에서 호출될 수 있습니다.", "label_en": "It may call completeRequest inside stopDevice.", "evidence": [{"source": "shutdown/stop", "sha256": "108b1bea5a8314ba57213d15c1e3ba01abe2b3f8a9e0e1e1281864b5492c7304", "quote": "\\brief Stop capturing from all running streams and cancel pending requests\n * \\param[in] camera The camera to stop\n *\n * This function stops capturing and processing requests immediately. All\n * pending requests are cancelled and complete immediately in an error state.\n *\n * \\context This function is called from the CameraManager thread.\n */\nvoid PipelineHandler::stop(Camera *camera)\n{\n\t/*\n\t * Take all waiting requests so that they are not requeued in response\n\t * to completeRequest() being called inside stopDevice(). Cancel them\n\t * after the device to keep them in order.\n\t */\n\tCamera::Private *data = camera->_d();\n\tstd::queue<Request *> waitingRequests;\n\twaitingRequests.swap(data->waitingRequests_);"}]}, {"from": "complete", "to": "dispatch", "label": "함수 끝에서 호출합니다.", "label_en": "It calls doQueueRequests at the end.", "evidence": [{"source": "shutdown/completion", "sha256": "514288cc958de9ff5fd19d46393cec3bb3088f4f08486528d4559071138638c9", "quote": "/**\n * \\brief Signal request completion\n * \\param[in] request The request that has completed\n *\n * The pipeline handler shall call this function to notify the \\a camera that\n * the request has completed. The request is no longer managed by the pipeline\n * handler and shall not be accessed once this function returns.\n *\n * This function ensures that requests will be returned to the application in\n * submission order, the pipeline handler may call it on any complete request\n * without any ordering constraint.\n *\n * \\context This function shall be called from the CameraManager thread.\n */\nvoid PipelineHandler::completeRequest(Request *request)\n{\n\tCamera *camera = request->_d()->camera();"}, {"source": "shutdown/completion", "sha256": "514288cc958de9ff5fd19d46393cec3bb3088f4f08486528d4559071138638c9", "quote": "/* Allow any waiting requests to be queued to the pipeline. */\n\tdoQueueRequests(camera);\n}"}]}, {"from": "dispatch", "to": "shared", "label": "공유 큐를 조회합니다.", "label_en": "It checks the shared queue.", "evidence": [{"source": "shutdown/waiting-dispatch", "sha256": "b2d2d134eaa639300cae5e7660d8453da545646bcc100bf640a981fa1371899d", "quote": "void PipelineHandler::doQueueRequests(Camera *camera)\n{\n\tCamera::Private *data = camera->_d();\n\twhile (!data->waitingRequests_.empty()) {\n\t\tif (data->queuedRequests_.size() == maxQueuedRequestsDevice_)\n\t\t\tbreak;"}]}], "producer": "cli/codex/gpt-6.1-terra"}, "producer": "cli/codex/gpt-6.1-terra", "generation_commit": "293d751a814e0d4c34e85ad457ccd9d5eefd1a61", "reused": true}}, "body_sha256": "a04630c022eb1987324d4d5f925ed06b9ef7aa840a39b0d2d2cb987fb18150b9"}
---

# Pipeline Handler

**파이프라인 구현이 지켜야 하는 구성·요청·완료·종료 계약을 확인하세요.**

| 지금 확인할 내용 | 이동할 절 |
|---|---|
| <a id="요청-준비와-장치-큐"></a>요청 준비와 장치 큐의 조건과 근거를 대조하세요. | [Pipeline 요청 제출과 완료](pipeline-requests.md#요청-준비와-장치-큐) |
| <a id="버퍼-완료와-요청-반환"></a>버퍼 완료와 요청 반환의 조건과 근거를 대조하세요. | [Pipeline 요청 제출과 완료](pipeline-requests.md#버퍼-완료와-요청-반환) |
| <a id="요청이-대기하거나-장치로-가는-조건"></a>“요청이 대기하거나 장치로 가는 조건” 그림을 확인하세요. | [Pipeline 요청 제출과 완료](pipeline-requests.md#요청이-대기하거나-장치로-가는-조건) |
| <a id="버퍼-완료에서-요청-반환까지"></a>“버퍼 완료에서 요청 반환까지” 그림을 확인하세요. | [Pipeline 요청 제출과 완료](pipeline-requests.md#버퍼-완료에서-요청-반환까지) |

## 장치 매칭과 객체 수명

`PipelineHandler`는 `DeviceEnumerator`의 미디어 장치를 지원하는 파이프라인과 대조해 `Camera`를 생성·관리하며, 수동 생성하지 않고 `PipelineHandlerFactoryBase::create()`로 생성해야 하고 `std::shared_ptr`로 참조 계수되며 `std::enable_shared_from_this`를 구현합니다. match()는 한 파이프라인에 필요한 장치를 모두 확보하면 `Camera`를 생성해 내부에 저장하고 `CameraManager`에 등록한 뒤 true를 반환하며, 그렇지 않으면 장치를 확보하지 않거나 확보한 장치를 모두 해제하고 false를 반환합니다. acquireMediaDevice()가 확보한 장치는 호출자가 직접 해제하지 않아야 하며 핸들러 소멸 시 자동 해제됩니다. acquire()는 같은 프로세스에서 재귀적으로 가능하고 성공할 때마다 release()와 짝을 지어야 하며 `Camera`가 호출을 관리합니다. 장치 lock 실패 시 unlockMediaDevices()로 잠금을 풀고 false를 반환하며, acquireDevice() 실패 시에는 useCount가 0이면 잠금을 풀고 false를 반환하고, 여러 카메 `src/libcamera/pipeline_handler.cpp:50`, `src/libcamera/pipeline_handler.cpp:119`

근거 원문: [src/libcamera/pipeline_handler.cpp:50](#source-69bfa9568cf8b5c5) · [src/libcamera/pipeline_handler.cpp:119](#source-a3caf1625bc18d64)

## 구성의 입력과 검증 책임

generateConfiguration()에서 호출자는 기본 구성을 얻고자 하는 사용 사례로 roles를 채워야 하며, 요청한 역할을 충족할 수 있으면 유효한 `CameraConfiguration`을, 그렇지 않으면 null 포인터를 반환합니다. 이 함수는 어느 스레드에서나 호출될 수 있고 스레드 안전해야 하며, 파이프라인 핸들러에서 camera의 상태를 변경해서는 안 됩니다. configure()는 애플리케이션에서 적용할 구성을 받은 `Camera` 클래스가 호출하도록 의도되며, `CameraConfiguration::validate()`로 검증된 구성을 받는 것이 보장되므로 구현은 추가 검증을 수행해서는 안 되고 파생 구성 클래스의 사용자 정의 필드를 신뢰할 수 있습니다. 구현은 각 `StreamConfiguration` 항목에 `StreamConfiguration::setStream()`으로 `Stream` 인스턴스를 연결해야 하며, configure()는 성공 시 0을, 그 외에는 음수 오류 코드를 반환합니다. `src/libcamera/pipeline_handler.cpp:271`

근거 원문: [src/libcamera/pipeline_handler.cpp:271](#source-8cd14a802c5b1782)

## 정지와 미완료 요청

`PipelineHandler::stop`은 `waitingRequests_`의 모든 대기 요청을 로컬 큐와 교환하여 분리합니다. 이는 stopDevice() 내부에서 completeRequest()가 호출될 때 대기 요청이 다시 큐에 들어가지 않도록 하기 위함입니다. 그 직후 장치 정지 함수인 stopDevice(camera)를 호출합니다. stopDevice가 반환하면 분리해 둔 대기 요청을 앞에서부터 하나씩 꺼내 취소 상태로 표시한 뒤 doQueueRequest를 호출하여 완료 처리합니다. `src/libcamera/pipeline_handler.cpp:359`, `src/libcamera/pipeline_handler.cpp:483`

<!-- sdd:visual:stop-waiting-requests -->
### 정지할 때 대기 요청을 분리하고 완료하는 순서

```mermaid
flowchart TB
%% sdd:translations {"completeRequest는 앱에 제출 <br/>순서로 알립니다. 반환 후 <br/>핸들러는 요청을 더 이상 <br/>관리하지 않으며 접근하면 안 <br/>됩니다.": "completeRequest notifies <br/>the app in submission <br/>order; after this call <br/>returns, the handler no <br/>longer manages the request <br/>and no handler access is <br/>allowed.", "completeRequest와 <br/>doQueueRequest가 반환하면 <br/>다시 확인합니다.": "After both calls return, <br/>check the local queue again.", "doQueueRequest는 요청을 <br/>queuedRequests_에 추가한 뒤 <br/>순번을 부여합니다.": "doQueueRequest adds the <br/>request to queuedRequests_, <br/>then assigns a sequence <br/>number.", "stopDevice가 반환하면 지역 <br/>큐를 확인합니다.": "Check the local queue after <br/>stopDevice returns.", "stopDevice는 모든 실행 중인 <br/>스트림의 캡처와 요청 처리를 <br/>즉시 중단하고, 제출된 <br/>요청을 취소해 오류 상태로 <br/>즉시 완료해야 합니다.": "stopDevice must immediately <br/>stop capture on all running <br/>streams and request <br/>processing, and cancel and <br/>immediately complete <br/>submitted requests in error.", "waitingRequests_를 지역 <br/>waitingRequests와 swap해 <br/>대기 요청을 분리합니다.": "Swap waitingRequests_ into <br/>local waitingRequests to <br/>separate the waiting <br/>requests.", "두 큐가 비었는지 ASSERT로 <br/>확인하고 requestSequence_를 <br/>0으로 초기화합니다.": "ASSERT that both queues are <br/>empty, then reset <br/>requestSequence_ to 0.", "요청이 남아 있으면 꺼내 <br/>취소 표시합니다. [true]": "Pop and mark the request <br/>cancelled if one remains. <br/>[true]", "지역 waitingRequests에 <br/>요청이 남았는지 확인합니다.": "Check whether local <br/>waitingRequests has <br/>requests left.", "지역 큐가 비면 두 큐를 <br/>확인합니다. [false]": "If the local queue is <br/>empty, check both queues. <br/>[false]", "지역 큐를 분리한 뒤 장치를 <br/>정지합니다.": "Stop the device after <br/>separating the local queue.", "지역 큐의 앞 요청을 꺼내 <br/>cancel로 취소 표시합니다.": "Pop the front request from <br/>the local queue and mark it <br/>cancelled with cancel.", "취소 표시 후 <br/>doQueueRequest를 호출합니다.": "Call doQueueRequest after <br/>marking the request <br/>cancelled.", "취소된 요청을 완료하고 장치 <br/>제출을 건너뜁니다. [true]": "Complete cancelled request; <br/>skip device submission. <br/>[true]"}
  v_waiting["waitingRequests_를 지역 <br/>waitingRequests와 swap해 <br/>대기 요청을 분리합니다."]
  v_stop["stopDevice는 모든 실행 중인 <br/>스트림의 캡처와 요청 처리를 <br/>즉시 중단하고, 제출된 <br/>요청을 취소해 오류 상태로 <br/>즉시 완료해야 합니다."]
  v_check{"지역 waitingRequests에 <br/>요청이 남았는지 확인합니다."}
  v_cancel["지역 큐의 앞 요청을 꺼내 <br/>cancel로 취소 표시합니다."]
  v_queue["doQueueRequest는 요청을 <br/>queuedRequests_에 추가한 뒤 <br/>순번을 부여합니다."]
  v_complete["completeRequest는 앱에 제출 <br/>순서로 알립니다. 반환 후 <br/>핸들러는 요청을 더 이상 <br/>관리하지 않으며 접근하면 안 <br/>됩니다."]
  v_end["두 큐가 비었는지 ASSERT로 <br/>확인하고 requestSequence_를 <br/>0으로 초기화합니다."]
  v_waiting -->|"지역 큐를 분리한 뒤 장치를 <br/>정지합니다."| v_stop
  v_stop -->|"stopDevice가 반환하면 지역 <br/>큐를 확인합니다."| v_check
  v_check -->|"요청이 남아 있으면 꺼내 <br/>취소 표시합니다. [true]"| v_cancel
  v_check -->|"지역 큐가 비면 두 큐를 <br/>확인합니다. [false]"| v_end
  v_cancel -->|"취소 표시 후 <br/>doQueueRequest를 호출합니다."| v_queue
  v_queue -->|"취소된 요청을 완료하고 장치 <br/>제출을 건너뜁니다. [true]"| v_complete
  v_complete -->|"completeRequest와 <br/>doQueueRequest가 반환하면 <br/>다시 확인합니다."| v_check
```

[Mermaid 원문](pipeline-handler.stop-waiting-requests.mmd)

??? note "그림 근거와 확인 범위"
    정지 함수는 지역 대기 큐의 요청을 어떤 순서로 취소·완료하고 마지막 큐 검사와 순번 초기화를 마칩니까?
    
    소스에 연결한 설계 해석입니다. 자동 연결 검사는 의미 승인이나 기기 실행 검증이 아닙니다.
    
    LLM 그림 초안 · 사람 검토 전
    
    작성 모델: `cli/codex/gpt-6.1-terra`
    
    | 요소·전이 | 소스 근거 |
    |---|---|
    | waitingRequests_를 지역 waitingRequests와 swap해 대기 요청을 분리합니다. | [src/libcamera/pipeline_handler.cpp:359](#source-eefd1bbecb1aad0a) |
    | stopDevice는 모든 실행 중인 스트림의 캡처와 요청 처리를 즉시 중단하고, 제출된 요청을 취소해 오류 상태로 즉시 완료해야 합니다. | [src/libcamera/pipeline_handler.cpp:359](#source-eefd1bbecb1aad0a) |
    | 지역 waitingRequests에 요청이 남았는지 확인합니다. | [src/libcamera/pipeline_handler.cpp:359](#source-eefd1bbecb1aad0a) |
    | 지역 큐의 앞 요청을 꺼내 cancel로 취소 표시합니다. | [src/libcamera/pipeline_handler.cpp:359](#source-eefd1bbecb1aad0a) |
    | doQueueRequest는 요청을 queuedRequests_에 추가한 뒤 순번을 부여합니다. | [src/libcamera/pipeline_handler.cpp:483](#source-7348e9b4af985eb2) |
    | completeRequest는 앱에 제출 순서로 알립니다. 반환 후 핸들러는 요청을 더 이상 관리하지 않으며 접근하면 안 됩니다. | [src/libcamera/pipeline_handler.cpp:547](#source-01ad7c6605c3296a) |
    | 두 큐가 비었는지 ASSERT로 확인하고 requestSequence_를 0으로 초기화합니다. | [src/libcamera/pipeline_handler.cpp:359](#source-eefd1bbecb1aad0a) |
    | 지역 큐를 분리한 뒤 장치를 정지합니다. | [src/libcamera/pipeline_handler.cpp:359](#source-eefd1bbecb1aad0a) |
    | stopDevice가 반환하면 지역 큐를 확인합니다. | [src/libcamera/pipeline_handler.cpp:359](#source-eefd1bbecb1aad0a) |
    | 요청이 남아 있으면 꺼내 취소 표시합니다. · !waitingRequests.empty() [true] | [src/libcamera/pipeline_handler.cpp:359](#source-eefd1bbecb1aad0a) |
    | 지역 큐가 비면 두 큐를 확인합니다. · !waitingRequests.empty() [false] | [src/libcamera/pipeline_handler.cpp:359](#source-eefd1bbecb1aad0a) |
    | 취소 표시 후 doQueueRequest를 호출합니다. | [src/libcamera/pipeline_handler.cpp:359](#source-eefd1bbecb1aad0a) |
    | 취소된 요청을 완료하고 장치 제출을 건너뜁니다. · request-&gt;_d()-&gt;cancelled_ [true] | [src/libcamera/pipeline_handler.cpp:483](#source-7348e9b4af985eb2) |
    | completeRequest와 doQueueRequest가 반환하면 다시 확인합니다. | [src/libcamera/pipeline_handler.cpp:483](#source-7348e9b4af985eb2) · [src/libcamera/pipeline_handler.cpp:359](#source-eefd1bbecb1aad0a) |
<!-- /sdd:visual:stop-waiting-requests -->

<!-- sdd:visual:stop-completion-reentry -->
### 완료 처리의 재진입은 분리한 대기 요청을 다시 제출하지 않습니다

```mermaid
flowchart TB
%% sdd:translations {"completeRequest는 끝에서 <br/>doQueueRequests를 <br/>호출합니다.": "completeRequest calls <br/>doQueueRequests at the end.", "doQueueRequests는 공유 <br/>waitingRequests_를 <br/>조회합니다.": "doQueueRequests checks the <br/>shared waitingRequests_.", "stopDevice 안에서 <br/>completeRequest가 호출될 수 <br/>있습니다.": "completeRequest may be <br/>called inside stopDevice.", "swap으로 기존 대기 요청을 <br/>지역 큐로 옮깁니다.": "swap moves existing waiting <br/>requests to the local queue.", "공유 waitingRequests_는 <br/>doQueueRequests가 조회하는 <br/>큐입니다.": "The shared waitingRequests_ <br/>is the queue checked by <br/>doQueueRequests.", "공유 큐를 조회합니다.": "It checks the shared queue.", "분리한 기존 요청은 지역 <br/>waitingRequests에 있어 공유 <br/>큐 조회에 포함되지 않습니다.": "The separated existing <br/>requests are in local <br/>waitingRequests, outside <br/>the shared queue check.", "안에서 호출될 수 있습니다.": "It may call completeRequest <br/>inside stopDevice.", "함수 끝에서 호출합니다.": "It calls doQueueRequests at <br/>the end."}
  v_shared["공유 waitingRequests_는 <br/>doQueueRequests가 조회하는 <br/>큐입니다."]
  v_local["분리한 기존 요청은 지역 <br/>waitingRequests에 있어 공유 <br/>큐 조회에 포함되지 않습니다."]
  v_stopdevice["stopDevice 안에서 <br/>completeRequest가 호출될 수 <br/>있습니다."]
  v_complete["completeRequest는 끝에서 <br/>doQueueRequests를 <br/>호출합니다."]
  v_dispatch["doQueueRequests는 공유 <br/>waitingRequests_를 <br/>조회합니다."]
  v_shared -->|"swap으로 기존 대기 요청을 <br/>지역 큐로 옮깁니다."| v_local
  v_stopdevice -->|"안에서 호출될 수 있습니다."| v_complete
  v_complete -->|"함수 끝에서 호출합니다."| v_dispatch
  v_dispatch -->|"공유 큐를 조회합니다."| v_shared
```

[Mermaid 원문](pipeline-handler.stop-completion-reentry.mmd)

??? note "그림 근거와 확인 범위"
    완료 처리의 재진입이 검사하는 공유 큐와 정지가 분리해 보유하는 지역 큐는 어떻게 다릅니까?
    
    소스에 연결한 설계 해석입니다. 자동 연결 검사는 의미 승인이나 기기 실행 검증이 아닙니다.
    
    LLM 그림 초안 · 사람 검토 전
    
    작성 모델: `cli/codex/gpt-6.1-terra`
    
    | 요소·전이 | 소스 근거 |
    |---|---|
    | 공유 waitingRequests_는 doQueueRequests가 조회하는 큐입니다. | [src/libcamera/pipeline_handler.cpp:509](#source-d63c9e57bcf862b0) |
    | 분리한 기존 요청은 지역 waitingRequests에 있어 공유 큐 조회에 포함되지 않습니다. | [src/libcamera/pipeline_handler.cpp:359](#source-eefd1bbecb1aad0a) · [src/libcamera/pipeline_handler.cpp:509](#source-d63c9e57bcf862b0) |
    | stopDevice 안에서 completeRequest가 호출될 수 있습니다. | [src/libcamera/pipeline_handler.cpp:359](#source-eefd1bbecb1aad0a) |
    | completeRequest는 끝에서 doQueueRequests를 호출합니다. | [src/libcamera/pipeline_handler.cpp:547](#source-01ad7c6605c3296a) |
    | doQueueRequests는 공유 waitingRequests_를 조회합니다. | [src/libcamera/pipeline_handler.cpp:509](#source-d63c9e57bcf862b0) |
    | swap으로 기존 대기 요청을 지역 큐로 옮깁니다. | [src/libcamera/pipeline_handler.cpp:359](#source-eefd1bbecb1aad0a) |
    | 안에서 호출될 수 있습니다. | [src/libcamera/pipeline_handler.cpp:359](#source-eefd1bbecb1aad0a) |
    | 함수 끝에서 호출합니다. | [src/libcamera/pipeline_handler.cpp:547](#source-01ad7c6605c3296a) |
    | 공유 큐를 조회합니다. | [src/libcamera/pipeline_handler.cpp:509](#source-d63c9e57bcf862b0) |
<!-- /sdd:visual:stop-completion-reentry -->

stopDevice 구현자는 실행 중인 모든 스트림의 캡처와 요청 처리를 즉시 중단하고, 대기 중인 모든 요청을 취소하여 즉시 오류 상태로 완료해야 합니다. stop의 마지막에서 ASSERT는 `queuedRequests_`와 `waitingRequests_`가 각각 비어 있는지 확인합니다. 이후 `requestSequence_`를 0으로 초기화합니다. `src/libcamera/pipeline_handler.cpp:359`

정상 완료 시 completeRequest는 끝에서 doQueueRequests를 호출하며, `waitingRequests_`가 비어 있지 않고 장치에 큐된 요청 수가 한도에 도달하지 않았으며 대기 큐의 맨 앞 요청이 준비된 경우에 해당 요청을 전달합니다. 정지 시 stop은 `waitingRequests_`를 먼저 분리하므로 stopDevice 안에서 완료 처리에 재진입해도 원래 대기 요청이 다시 제출되지 않습니다. `src/libcamera/pipeline_handler.cpp:547`, `src/libcamera/pipeline_handler.cpp:359`, `src/libcamera/pipeline_handler.cpp:509`

근거 원문: [src/libcamera/pipeline_handler.cpp:359](#source-eefd1bbecb1aad0a) · [src/libcamera/pipeline_handler.cpp:547](#source-01ad7c6605c3296a) · [src/libcamera/pipeline_handler.cpp:509](#source-d63c9e57bcf862b0) · [src/libcamera/pipeline_handler.cpp:483](#source-7348e9b4af985eb2)

## IPU3 입력 크기 탐색의 경계

minIfWidth는 입력 너비에서 kIFMaxCropWidth를 뺀 값과 kIFMaxCropWidth 중 큰 값입니다. minIfHeight는 입력 높이에서 kIFMaxCropHeight를 뺀 값과 kIFMaxCropHeight 중 큰 값입니다. `src/libcamera/pipeline/ipu3/imgu.cpp:407`

첫 탐색은 폭을 바깥 반복, 높이를 안쪽 반복으로 두고, 두 번째 탐색은 높이를 바깥 반복, 폭을 안쪽 반복으로 두며, 각각 minIfWidth와 minIfHeight 이상인 동안 반복합니다. 두 번째 탐색 전에 폭과 높이를 alignUp으로 다시 초기화하며, 폭은 kIFAlignWidth만큼, 높이는 kIFAlignHeight만큼 감소합니다. calculateBDSHeight는 입력 포매터 높이에서 최대 kIFMaxCropHeight줄을 자르므로, 높이가 이 값보다 작으면 부호 없는 최소 높이 차감값이 감깁니다. `src/libcamera/pipeline/ipu3/imgu.cpp:407`, `src/libcamera/pipeline/ipu3/imgu.cpp:111`

근거 원문: [src/libcamera/pipeline/ipu3/imgu.cpp:407](#source-2494b74f28e1b200) · [src/libcamera/pipeline/ipu3/imgu.cpp:111](#source-e95802b61093a795)

??? note "설계 질문과 검증 범위"
    질문별 답변과 근거 연결을 검사했습니다. 의미와 실행 결과는 사람 검토가 필요합니다.
    
    | 설계 질문 | 설명 위치 | 확인 범위 |
    |---|---|---|
    | 핸들러는 어떤 객체와 장치를 만들고 관리합니까? | [장치 매칭과 객체 수명](#장치-매칭과-객체-수명) | 코드 근거와 설명 연결 |
    | 기본 구성과 실제 구성에서 호출자와 구현의 책임은 무엇입니까? | [구성의 입력과 검증 책임](#구성의-입력과-검증-책임) | 코드 근거와 설명 연결 |
    | 정지 중 재큐잉을 막고 대기 요청을 반환하는 방법은 무엇입니까? | [정지와 미완료 요청](#정지와-미완료-요청) | 코드 근거와 설명 연결 |
    | IPU3에서 입력 크기를 탐색하는 두 반복문은 최소 폭·높이를 어떻게 계산하며, 높이를 자르는 연산과 unsigned 경계는 어떤 관계입니까? 소스에 있는 식과 조건을 구분하고 기기 동작이나 성능을 보장하지 마세요. | [IPU3 입력 크기 탐색의 경계](#ipu3-입력-크기-탐색의-경계) | 코드 근거와 설명 연결 |

## 소스 근거

같은 발췌는 한 번만 싣습니다. 필요한 원문을 펼쳐 설명과 대조하세요.

<a id="source-69bfa9568cf8b5c5"></a>

??? note "소스 근거: src/libcamera/pipeline_handler.cpp:50"
    `src/libcamera/pipeline_handler.cpp:50`에서 시작하는 발췌입니다. 종료 줄은 119이며, 아래 원문을 설명과 대조할 수 있습니다.
    
    SHA-256: `e05278df0a06cb963fe79f772e62d4560b62df15c1411a6b49e32f7ca84d9e74`
    
    ```text
    \class PipelineHandler
     * \brief Create and manage cameras based on a set of media devices
     *
     * The PipelineHandler matches the media devices provided by a DeviceEnumerator
     * with the pipelines it supports and creates corresponding Camera devices.
     *
     * Pipeline handler instances are reference-counted through std::shared_ptr<>.
     * They implement std::enable_shared_from_this<> in order to create new
     * std::shared_ptr<> in code paths originating from member functions of the
     * PipelineHandler class where only the 'this' pointer is available.
     */
    
    /**
     * \brief Construct a PipelineHandler instance
     * \param[in] manager The camera manager
     * \param[in] maxQueuedRequestsDevice The maximum number of requests queued to
     * the device
     *
     * In order to honour the std::enable_shared_from_this<> contract,
     * PipelineHandler instances shall never be constructed manually, but always
     * through the PipelineHandlerFactoryBase::create() function.
     */
    PipelineHandler::PipelineHandler(CameraManager *manager,
    				 unsigned int maxQueuedRequestsDevice)
    	: manager_(manager), maxQueuedRequestsDevice_(maxQueuedRequestsDevice),
    	  useCount_(0)
    {
    }
    
    PipelineHandler::~PipelineHandler()
    {
    	for (std::shared_ptr<MediaDevice> &media : mediaDevices_)
    		media->release();
    }
    
    /**
     * \fn PipelineHandler::match(DeviceEnumerator *enumerator)
     * \brief Match media devices and create camera instances
     * \param[in] enumerator The enumerator providing all media devices found in the
     * system
     *
     * This function is the main entry point of the pipeline handler. It is called
     * by the camera manager with the \a enumerator passed as an argument. It shall
     * acquire from the \a enumerator all the media devices it needs for a single
     * pipeline, create one or multiple Camera instances and register them with the
     * camera manager.
     *
     * If all media devices needed by the pipeline handler are found, they must all
     * be acquired by a call to MediaDevice::acquire(). This function shall then
     * create the corresponding Camera instances, store them internally, and return
     * true. Otherwise it shall not acquire any media device (or shall release all
     * the media devices is has acquired by calling MediaDevice::release()) and
     * return false.
     *
     * If multiple instances of a pipeline are available in the system, the
     * PipelineHandler class will be instantiated once per instance, and its match()
     * function called for every instance. Each call shall acquire media devices for
     * one pipeline instance, until all compatible media devices are exhausted.
     *
     * If this function returns true, a new instance of the pipeline handler will
     * be created and its match() function called.
     *
     * \context This function is called from the CameraManager thread.
     *
     * \return true if media devices have been acquired and camera instances
     * created, or false otherwise
     */
    
    /**
     * \brief Search and acquire a MediaDevice
    ```

<a id="source-a3caf1625bc18d64"></a>

??? note "소스 근거: src/libcamera/pipeline_handler.cpp:119"
    `src/libcamera/pipeline_handler.cpp:119`에서 시작하는 발췌입니다. 종료 줄은 271이며, 아래 원문을 설명과 대조할 수 있습니다.
    
    SHA-256: `379b17c52a1e97055bf78aaabd964595fb3ec506c568d112e552ed1c29235591`
    
    ```text
    \brief Search and acquire a MediaDevice matching a device pattern
     * \param[in] enumerator Enumerator containing all media devices in the system
     * \param[in] dm Device match pattern
     *
     * Search the device \a enumerator for an available media device matching the
     * device match pattern \a dm. Matching media device that have previously been
     * acquired by MediaDevice::acquire() are not considered. If a match is found,
     * the media device is acquired and returned. The caller shall not release the
     * device explicitly, it will be automatically released when the pipeline
     * handler is destroyed.
     *
     * \context This function shall be called from the CameraManager thread.
     *
     * \return A shared pointer to the matching MediaDevice, or nullptr if no match
     * is found
     */
    std::shared_ptr<MediaDevice>
    PipelineHandler::acquireMediaDevice(DeviceEnumerator *enumerator,
    				    const DeviceMatch &dm)
    {
    	std::shared_ptr<MediaDevice> media = enumerator->search(dm);
    	if (!media)
    		return nullptr;
    
    	if (!media->acquire())
    		return nullptr;
    
    	mediaDevices_.push_back(media);
    
    	return media;
    }
    
    /**
     * \brief Acquire exclusive access to the pipeline handler for the process
     *
     * This function locks all the media devices used by the pipeline to ensure
     * that no other process can access them concurrently.
     *
     * Access to a pipeline handler may be acquired recursively from within the
     * same process. Every successful acquire() call shall be matched with a
     * release() call. This allows concurrent access to the same pipeline handler
     * from different cameras within the same process.
     *
     * Pipeline handlers shall not call this function directly as the Camera class
     * handles access internally.
     *
     * \context This function is called from the CameraManager thread.
     *
     * \return True if the pipeline handler was acquired, false if another process
     * has already acquired it
     * \sa release()
     */
    bool PipelineHandler::acquire(Camera *camera)
    {
    	if (useCount_ == 0) {
    		for (std::shared_ptr<MediaDevice> &media : mediaDevices_) {
    			if (!media->lock()) {
    				unlockMediaDevices();
    				return false;
    			}
    		}
    	}
    
    	if (!acquireDevice(camera)) {
    		if (useCount_ == 0)
    			unlockMediaDevices();
    
    		return false;
    	}
    
    	++useCount_;
    	return true;
    }
    
    /**
     * \brief Release exclusive access to the pipeline handler
     * \param[in] camera The camera for which to release data
     *
     * This function releases access to the pipeline handler previously acquired by
     * a call to acquire(). Every release() call shall match a previous successful
     * acquire() call. Calling this function on a pipeline handler that hasn't been
     * acquired results in undefined behaviour.
     *
     * Pipeline handlers shall not call this function directly as the Camera class
     * handles access internally.
     *
     * \context This function is called from the CameraManager thread.
     *
     * \sa acquire()
     */
    void PipelineHandler::release(Camera *camera)
    {
    	ASSERT(useCount_);
    
    	releaseDevice(camera);
    
    	if (useCount_ == 1)
    		unlockMediaDevices();
    
    	--useCount_;
    }
    
    /**
     * \brief Acquire resources associated with this camera
     * \param[in] camera The camera for which to acquire resources
     *
     * Pipeline handlers may override this in order to get resources such as opening
     * devices and allocating buffers when a camera is acquired.
     *
     * This is used by the uvcvideo pipeline handler to delay opening /dev/video#
     * until the camera is acquired to avoid excess power consumption. The delayed
     * opening of /dev/video# is a special case because the kernel uvcvideo driver
     * powers on the USB device as soon as /dev/video# is opened. This behavior
     * should *not* be copied by other pipeline handlers.
     *
     * \context This function is called from the CameraManager thread.
     *
     * \return True on success, false on failure
     * \sa releaseDevice()
     */
    bool PipelineHandler::acquireDevice([[maybe_unused]] Camera *camera)
    {
    	return true;
    }
    
    /**
     * \brief Release resources associated with this camera
     * \param[in] camera The camera for which to release resources
     *
     * Pipeline handlers may override this in order to perform cleanup operations
     * when a camera is released, such as freeing memory.
     *
     * This is called once for every camera that is released. If there are resources
     * shared by multiple cameras then the pipeline handler must take care to not
     * release them until releaseDevice() has been called for all previously
     * acquired cameras.
     *
     * \context This function is called from the CameraManager thread.
     *
     * \sa acquireDevice()
     */
    void PipelineHandler::releaseDevice([[maybe_unused]] Camera *camera)
    {
    }
    
    void PipelineHandler::unlockMediaDevices()
    {
    	for (std::shared_ptr<MediaDevice> &media : mediaDevices_)
    		media->unlock();
    }
    
    /**
     * \fn PipelineHandler::generateConfiguration()
    ```

<a id="source-8cd14a802c5b1782"></a>

??? note "소스 근거: src/libcamera/pipeline_handler.cpp:271"
    `src/libcamera/pipeline_handler.cpp:271`에서 시작하는 발췌입니다. 종료 줄은 315이며, 아래 원문을 설명과 대조할 수 있습니다.
    
    SHA-256: `56e3a59872a70fc01b1bfdea1601201880929f47ae90d7888c2cf4c080085ea6`
    
    ```text
    \fn PipelineHandler::generateConfiguration()
     * \brief Generate a camera configuration for a specified camera
     * \param[in] camera The camera to generate a default configuration for
     * \param[in] roles A list of stream roles
     *
     * Generate a default configuration for the \a camera for a specified list of
     * stream roles. The caller shall populate the \a roles with the use-cases it
     * wishes to fetch the default configuration for. The returned configuration
     * can then be examined by the caller to learn about the selected streams and
     * their default parameters.
     *
     * The intended companion to this is \a configure() which can be used to change
     * the group of streams parameters.
     *
     * \context This function may be called from any thread and shall be
     * \threadsafe. It shall not modify the state of the \a camera in the pipeline
     * handler.
     *
     * \return A valid CameraConfiguration if the requested roles can be satisfied,
     * or a null pointer otherwise.
     */
    
    /**
     * \fn PipelineHandler::configure()
     * \brief Configure a group of streams for capture
     * \param[in] camera The camera to configure
     * \param[in] config The camera configurations to setup
     *
     * Configure the specified group of streams for \a camera according to the
     * configuration specified in \a config. The intended caller of this interface
     * is the Camera class which will receive configuration to apply from the
     * application.
     *
     * The configuration is guaranteed to have been validated with
     * CameraConfiguration::validate(). The pipeline handler implementation shall
     * not perform further validation and may rely on any custom field stored in its
     * custom CameraConfiguration derived class.
     *
     * When configuring the camera the pipeline handler shall associate a Stream
     * instance to each StreamConfiguration entry in the CameraConfiguration using
     * the StreamConfiguration::setStream() function.
     *
     * \context This function is called from the CameraManager thread.
     *
     * \return 0 on success or a negative error code otherwise
    ```

<a id="source-eefd1bbecb1aad0a"></a>

??? note "소스 근거: src/libcamera/pipeline_handler.cpp:359"
    `src/libcamera/pipeline_handler.cpp:359`에서 시작하는 발췌입니다. 종료 줄은 414이며, 아래 원문을 설명과 대조할 수 있습니다.
    
    SHA-256: `108b1bea5a8314ba57213d15c1e3ba01abe2b3f8a9e0e1e1281864b5492c7304`
    
    ```text
    \brief Stop capturing from all running streams and cancel pending requests
     * \param[in] camera The camera to stop
     *
     * This function stops capturing and processing requests immediately. All
     * pending requests are cancelled and complete immediately in an error state.
     *
     * \context This function is called from the CameraManager thread.
     */
    void PipelineHandler::stop(Camera *camera)
    {
    	/*
    	 * Take all waiting requests so that they are not requeued in response
    	 * to completeRequest() being called inside stopDevice(). Cancel them
    	 * after the device to keep them in order.
    	 */
    	Camera::Private *data = camera->_d();
    	std::queue<Request *> waitingRequests;
    	waitingRequests.swap(data->waitingRequests_);
    
    	/* Stop the pipeline handler and let the queued requests complete. */
    	stopDevice(camera);
    
    	/* Cancel and signal as complete all waiting requests. */
    	while (!waitingRequests.empty()) {
    		Request *request = waitingRequests.front();
    		waitingRequests.pop();
    
    		/*
    		 * Cancel all requests by marking them as cancelled and calling
    		 * doQueueRequest() instead of cancelRequest(). This ensures
    		 * that the requests get a sequence number and are temporarily
    		 * added to queuedRequests_ so they can be properly completed in
    		 * completeRequest().
    		 */
    		request->_d()->cancel();
    		doQueueRequest(request);
    	}
    
    	/* Make sure no requests are pending. */
    	ASSERT(data->queuedRequests_.empty());
    	ASSERT(data->waitingRequests_.empty());
    
    	data->requestSequence_ = 0;
    }
    
    /**
     * \fn PipelineHandler::stopDevice()
     * \brief Stop capturing from all running streams
     * \param[in] camera The camera to stop
     *
     * This function stops capturing and processing requests immediately. All
     * pending requests are cancelled and complete immediately in an error state.
     */
    
    /**
     * \brief Determine if the camera has any requests pending
    ```

<a id="source-01ad7c6605c3296a"></a>

??? note "소스 근거: src/libcamera/pipeline_handler.cpp:547"
    `src/libcamera/pipeline_handler.cpp:547`에서 시작하는 발췌입니다. 종료 줄은 620이며, 아래 원문을 설명과 대조할 수 있습니다.
    
    SHA-256: `514288cc958de9ff5fd19d46393cec3bb3088f4f08486528d4559071138638c9`
    
    ```text
    \brief Complete a buffer for a request
     * \param[in] request The request the buffer belongs to
     * \param[in] buffer The buffer that has completed
     *
     * This function shall be called by pipeline handlers to signal completion of
     * the \a buffer part of the \a request. It notifies applications of buffer
     * completion and updates the request's internal buffer tracking. The request
     * is not completed automatically when the last buffer completes to give
     * pipeline handlers a chance to perform any operation that may still be
     * needed. They shall complete requests explicitly with completeRequest().
     *
     * \context This function shall be called from the CameraManager thread.
     *
     * \return True if all buffers contained in the request have completed, false
     * otherwise
     */
    bool PipelineHandler::completeBuffer(Request *request, FrameBuffer *buffer)
    {
    	Camera *camera = request->_d()->camera();
    	camera->bufferCompleted.emit(request, buffer);
    	return request->_d()->completeBuffer(buffer);
    }
    
    /**
     * \brief Signal request completion
     * \param[in] request The request that has completed
     *
     * The pipeline handler shall call this function to notify the \a camera that
     * the request has completed. The request is no longer managed by the pipeline
     * handler and shall not be accessed once this function returns.
     *
     * This function ensures that requests will be returned to the application in
     * submission order, the pipeline handler may call it on any complete request
     * without any ordering constraint.
     *
     * \context This function shall be called from the CameraManager thread.
     */
    void PipelineHandler::completeRequest(Request *request)
    {
    	Camera *camera = request->_d()->camera();
    
    	request->_d()->complete();
    
    	Camera::Private *data = camera->_d();
    
    	while (!data->queuedRequests_.empty()) {
    		Request *req = data->queuedRequests_.front();
    		if (req->status() == Request::RequestPending)
    			break;
    
    		ASSERT(!req->hasPendingBuffers());
    		data->queuedRequests_.pop_front();
    		camera->requestComplete(req);
    	}
    
    	/* Allow any waiting requests to be queued to the pipeline. */
    	doQueueRequests(camera);
    }
    
    /**
     * \brief Cancel request and signal its completion
     * \param[in] request The request to cancel
     *
     * This function cancels and completes the request. The same rules as for
     * completeRequest() apply.
     */
    void PipelineHandler::cancelRequest(Request *request)
    {
    	request->_d()->cancel();
    	completeRequest(request);
    }
    
    /**
     * \brief Retrieve the absolute path to a platform configuration file
    ```

<a id="source-d63c9e57bcf862b0"></a>

??? note "소스 근거: src/libcamera/pipeline_handler.cpp:509"
    `src/libcamera/pipeline_handler.cpp:509`에서 시작하는 발췌입니다. 종료 줄은 530이며, 아래 원문을 설명과 대조할 수 있습니다.
    
    SHA-256: `b2d2d134eaa639300cae5e7660d8453da545646bcc100bf640a981fa1371899d`
    
    ```text
    void PipelineHandler::doQueueRequests(Camera *camera)
    {
    	Camera::Private *data = camera->_d();
    	while (!data->waitingRequests_.empty()) {
    		if (data->queuedRequests_.size() == maxQueuedRequestsDevice_)
    			break;
    
    		Request *request = data->waitingRequests_.front();
    		if (!request->_d()->prepared_)
    			break;
    
    		/*
    		 * Pop the request first, in case doQueueRequests() is called
    		 * recursively from within doQueueRequest()
    		 */
    		data->waitingRequests_.pop();
    		doQueueRequest(request);
    	}
    }
    
    /**
     * \fn PipelineHandler::queueRequestDevice()
    ```

<a id="source-7348e9b4af985eb2"></a>

??? note "소스 근거: src/libcamera/pipeline_handler.cpp:483"
    `src/libcamera/pipeline_handler.cpp:483`에서 시작하는 발췌입니다. 종료 줄은 501이며, 아래 원문을 설명과 대조할 수 있습니다.
    
    SHA-256: `fbd3ed6fe295b1cdd82d6ce420a30695986e43199347f92ac2545fe0e7831da8`
    
    ```text
    void PipelineHandler::doQueueRequest(Request *request)
    {
    	LIBCAMERA_TRACEPOINT(request_device_queue, request);
    
    	Camera *camera = request->_d()->camera();
    	Camera::Private *data = camera->_d();
    	data->queuedRequests_.push_back(request);
    
    	request->_d()->sequence_ = data->requestSequence_++;
    
    	if (request->_d()->cancelled_) {
    		completeRequest(request);
    		return;
    	}
    
    	int ret = queueRequestDevice(camera, request);
    	if (ret)
    		cancelRequest(request);
    }
    ```

<a id="source-2494b74f28e1b200"></a>

??? note "소스 근거: src/libcamera/pipeline/ipu3/imgu.cpp:407"
    `src/libcamera/pipeline/ipu3/imgu.cpp:407`에서 시작하는 발췌입니다. 종료 줄은 449이며, 아래 원문을 설명과 대조할 수 있습니다.
    
    SHA-256: `dff1dd0c4b791141aa7e60ba45e759e6cb4c6e69877280a629dc9250cf9b42dd`
    
    ```text
    float bdsSF = static_cast<float>(in.width) / gdc.width;
    	float sf = findScaleFactor(bdsSF, bdsScalingFactors, true);
    
    	/*
    	 * Populate the configurations vector by scaling width and height.
    	 *
    	 * calculateBDSHeight() crops up to kIFMaxCropHeight lines from the IF
    	 * height, so don't go below that, or its minimum IF height wraps.
    	 */
    	unsigned int ifWidth = utils::alignUp(in.width, ImgUDevice::kIFAlignWidth);
    	unsigned int ifHeight = utils::alignUp(in.height, ImgUDevice::kIFAlignHeight);
    	unsigned int minIfWidth = std::max(in.width - ImgUDevice::kIFMaxCropWidth,
    					   ImgUDevice::kIFMaxCropWidth);
    	unsigned int minIfHeight = std::max(in.height - ImgUDevice::kIFMaxCropHeight,
    					    ImgUDevice::kIFMaxCropHeight);
    	while (ifWidth >= minIfWidth) {
    		while (ifHeight >= minIfHeight) {
    			Size iif{ ifWidth, ifHeight };
    			calculateBDS(pipe, iif, gdc, sf);
    			ifHeight -= ImgUDevice::kIFAlignHeight;
    		}
    
    		ifWidth -= ImgUDevice::kIFAlignWidth;
    	}
    
    	/* Repeat search by scaling width first. */
    	ifWidth = utils::alignUp(in.width, ImgUDevice::kIFAlignWidth);
    	ifHeight = utils::alignUp(in.height, ImgUDevice::kIFAlignHeight);
    	while (ifHeight >= minIfHeight) {
    		/*
    		 * \todo This procedure is probably broken:
    		 * https://github.com/intel/intel-ipu3-pipecfg/issues/2
    		 */
    		while (ifWidth >= minIfWidth) {
    			Size iif{ ifWidth, ifHeight };
    			calculateBDS(pipe, iif, gdc, sf);
    			ifWidth -= ImgUDevice::kIFAlignWidth;
    		}
    
    		ifHeight -= ImgUDevice::kIFAlignHeight;
    	}
    
    	if (pipeConfigs.size() == 0) {
    ```

<a id="source-e95802b61093a795"></a>

??? note "소스 근거: src/libcamera/pipeline/ipu3/imgu.cpp:111"
    `src/libcamera/pipeline/ipu3/imgu.cpp:111`에서 시작하는 발췌입니다. 종료 줄은 112이며, 아래 원문을 설명과 대조할 수 있습니다.
    
    SHA-256: `095e890fbc9265784421e7c5bffa38c5c482fbea73289f56889e877d24b817c3`
    
    ```text
    unsigned int minIFHeight = iif.height - ImgUDevice::kIFMaxCropHeight;
    	unsigned int minBDSHeight = gdc.height + ImgUDevice::kFilterHeight * 2;
    ```


<!-- sdd:class-diagram -->
## 클래스 관계

화살표의 글자는 추출한 관계를 나타내며, 점선은 상속입니다. 화살표는 참조 대상 또는 기반 클래스를 향합니다. 호출 순서를 뜻하지 않습니다.

```mermaid
flowchart LR
  c0["Object"]:::context
  c1["PipelineHandler"]
  c2["PipelineHandlerFactory"]
  c3["PipelineHandlerFactoryBase"]
  c4["PipelineHandlerIPU3"]
  c5["PipelineHandlerIPU3::IPU3PipeModes"]
  c6["PipelineHandlerISI"]
  c7["PipelineHandlerISI::Pipe"]
  c8["PipelineHandlerMaliC55"]
  c9["PipelineHandlerMaliC55::(unnamed enum at src/libcamera/pipeline/mali-c55/mali-c55.cpp:712:2)"]
  c10["PipelineHandlerMaliC55::MaliC55Pipe"]
  c11["PipelineHandlerPiSP"]
  c12["PipelineHandlerRkISP1"]
  c13["PipelineHandlerUVC"]
  c14["PipelineHandlerVc4"]
  c15["PipelineHandlerVimc"]
  c16["PipelineHandlerVirtual"]
  c17["RPi::PipelineHandlerBase"]:::context
  c1 -.->|상속| c0
  c2 -.->|상속| c3
  c4 -.->|상속| c1
  c6 -.->|상속| c1
  c6 -->|필드 참조| c7
  c8 -.->|상속| c1
  c8 -->|필드 참조| c10
  c11 -.->|상속| c17
  c12 -.->|상속| c1
  c13 -.->|상속| c1
  c14 -.->|상속| c17
  c15 -.->|상속| c1
  c16 -.->|상속| c1
  classDef context fill:#fafafa,stroke:#aaa,stroke-dasharray:4 3,color:#555
```
<!-- /sdd:class-diagram -->



## 관련 클래스

| 클래스 | 선언 위치 | 상속 | 책임 (주석) |
|---|---|---|---|
| `libcamera::PipelineHandler` | `include/libcamera/internal/pipeline_handler.h:34` | `libcamera::Object` | Create and manage cameras based on a set of media devices |
| `libcamera::PipelineHandlerFactory` | `include/libcamera/internal/pipeline_handler.h:144` | `libcamera::PipelineHandlerFactoryBase` | Registration of PipelineHandler classes and creation of instances |
| `libcamera::PipelineHandlerFactoryBase` | `include/libcamera/internal/pipeline_handler.h:121` | – | Base class for pipeline handler factories |
| `libcamera::PipelineHandlerIPU3` | `src/libcamera/pipeline/ipu3/ipu3.cpp:124` | `libcamera::PipelineHandler` | 확인 필요 |
| `libcamera::PipelineHandlerIPU3::IPU3PipeModes` | `src/libcamera/pipeline/ipu3/ipu3.cpp:130` | – | 확인 필요 |
| `libcamera::PipelineHandlerISI` | `src/libcamera/pipeline/imx8-isi/imx8-isi.cpp:102` | `libcamera::PipelineHandler` | 확인 필요 |
| `libcamera::PipelineHandlerISI::Pipe` | `src/libcamera/pipeline/imx8-isi/imx8-isi.cpp:129` | – | 확인 필요 |
| `libcamera::PipelineHandlerMaliC55` | `src/libcamera/pipeline/mali-c55/mali-c55.cpp:676` | `libcamera::PipelineHandler` | 확인 필요 |
| `libcamera::PipelineHandlerMaliC55::(unnamed enum at src/libcamera/pipeline/mali-c55/mali-c55.cpp:712:2)` | `src/libcamera/pipeline/mali-c55/mali-c55.cpp:712` | – | 확인 필요 |
| `libcamera::PipelineHandlerMaliC55::MaliC55Pipe` | `src/libcamera/pipeline/mali-c55/mali-c55.cpp:705` | – | 확인 필요 |
| `libcamera::PipelineHandlerPiSP` | `src/libcamera/pipeline/rpi/pisp/pisp.cpp:852` | `libcamera::RPi::PipelineHandlerBase` | 확인 필요 |
| `libcamera::PipelineHandlerRkISP1` | `src/libcamera/pipeline/rkisp1/rkisp1.cpp:185` | `libcamera::PipelineHandler` | 확인 필요 |
| `libcamera::PipelineHandlerUVC` | `src/libcamera/pipeline/uvcvideo/uvcvideo.cpp:81` | `libcamera::PipelineHandler` | 확인 필요 |
| `libcamera::PipelineHandlerVc4` | `src/libcamera/pipeline/rpi/vc4/vc4.cpp:141` | `libcamera::RPi::PipelineHandlerBase` | 확인 필요 |
| `libcamera::PipelineHandlerVimc` | `src/libcamera/pipeline/vimc/vimc.cpp:84` | `libcamera::PipelineHandler` | 확인 필요 |
| `libcamera::PipelineHandlerVirtual` | `src/libcamera/pipeline/virtual/virtual.cpp:81` | `libcamera::PipelineHandler` | 확인 필요 |

??? note "근거와 검토 정보"
    - 생성 방식: 추출 사실과 LLM 설명
    - 검증 범위: 표·그림은 facts로 만들고 설명은 LLM이 작성합니다. 인용·문장 및 설정된 구조 검사를 적용합니다.
    - 근거 파일: `include/libcamera/internal/pipeline_handler.h`, `src/libcamera/pipeline/imx8-isi/imx8-isi.cpp`, `src/libcamera/pipeline/ipu3/imgu.cpp`, `src/libcamera/pipeline/ipu3/ipu3.cpp`, `src/libcamera/pipeline/mali-c55/mali-c55.cpp`, `src/libcamera/pipeline/rkisp1/rkisp1.cpp`, `src/libcamera/pipeline/rpi/pisp/pisp.cpp`, `src/libcamera/pipeline/rpi/vc4/vc4.cpp`, `src/libcamera/pipeline/uvcvideo/uvcvideo.cpp`, `src/libcamera/pipeline/vimc/vimc.cpp`, `src/libcamera/pipeline/virtual/virtual.cpp`, `src/libcamera/pipeline_handler.cpp`
    - 근거 수준: 코드 확인 (정적 분석, simple_compdb 구성, commit `293d751a81`)
    - 자동 검사 (인용·문장 및 설정된 구조 검사): 통과
    - 검토 상태 기록일: 2026-11-04 · 사람 검토 전

다음 단계: [Pipeline 요청 제출과 완료](pipeline-requests.md)
