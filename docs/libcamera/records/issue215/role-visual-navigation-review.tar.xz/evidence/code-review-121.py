from pathlib import Path
from dataclasses import asdict
import hashlib,json,subprocess
from sdd.config import load
from sdd.cli_agent import command,arguments,build_prompt
from sdd.llm import Agent
from sdd.generation_run import Execution
root=Path.cwd().resolve(); out=root/'build/issue215/code-review-121';assert not out.exists();out.mkdir()
work=root/'build/issue215/role-visuals'
names=['src/sdd/reader_path_visuals.py','src/sdd/reader_path_contract.py','src/sdd/reader_paths.py','src/sdd/export_site.py','src/sdd/site_build.py','tests/test_reader_path_visuals.py','docs/reference/reader-visuals.md','docs/concepts/role-decisions.md','src/sdd/visuals.py','src/sdd/visual_audit.py','src/sdd/site_localization.py']
payload=dict(scope='Latest main1174e60 merged into role feature branch after original common zero-finding review120 and connected182:68 passed. Main274 moves factual scope warnings/detail links before the projected blockquote. The role figure now explicitly skips these to follow the first actual projected explanation, retaining scope-before-timing order. Allowed claim source/topic pairs include its explicit details refs; unrelated other claims or question-only links remain prohibited. First-closing-blockquote-before-figure assertion added. Review the actual merged reader_paths plus this narrow compatibility adaptation. No book, diagram, human or release approval; no new real-reader work is performed here.',code={n:(work/n).read_text(encoding='utf-8') for n in names},sha256={n:hashlib.sha256((work/n).read_bytes()).hexdigest() for n in names},merge_patch=subprocess.check_output(['git','diff','1ccf4b4','--','src/sdd/reader_path_visuals.py','src/sdd/reader_paths.py','src/sdd/site_build.py','tests/test_reader_path_visuals.py'],cwd=work,text=True),constraints=['Check whether latest next-step pretranslation validation and explicit private pending consistency report preserve the role-figure injection/asset/translation pipeline, last-good-site rollback and canonical source pins.','Current branch includes main efbf6cb. The original common role feature has zero remaining actual native review118 findings. Its broad91 tests and final targeted39 passed, including effective claim alias uniqueness, real topic/source binding, quoted procedure preservation and rollback. A new connected premerge/role integration test180 is running; do not assume its result.','Only concrete remaining actionable merge integration defects; no demand to approve current books/diagrams or inherited human status. No tools, edits or delegation.'])

schema=dict(type='object',additionalProperties=False,required=['findings'],properties=dict(findings=dict(type='array',items=dict(type='object',additionalProperties=False,required=['file','line','severity','problem','fix'],properties={k:dict(type='integer' if k=='line' else 'string') for k in ['file','line','severity','problem','fix']}))))
cfg=load(root/'examples/libcamera/validation/issue215/independent-review-profile.yaml');cfg.root=out
system='Independently review this common role-local figure integration. Return only actionable schema JSON findings, not approval of book content or release.';user=json.dumps(payload,ensure_ascii=False);measured=len(build_prompt(system,user,schema));assert measured<1000000;cfg.agent.max_input_chars=max(cfg.agent.max_input_chars,measured)
(out/'inputs.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');(out/'execution-profile.json').write_text(json.dumps(dict(agent=asdict(cfg.agent),argv=command(cfg.agent)+arguments(cfg.agent,schema),cli_version=subprocess.check_output(command(cfg.agent)+['--version'],text=True).strip(),input_chars=measured),indent=2)+'\n',encoding='utf-8')
execution=Execution(cfg,Agent(cfg.agent,out/'prompts'))
try:
    with execution.track('role-visual-integration-code-review'):response=execution.chat(system,user,tag='role-visual-integration-code-review',response_schema=schema)
    (out/'review.json').write_text(response,encoding='utf-8');print(response,flush=True)
finally:execution.persist()
