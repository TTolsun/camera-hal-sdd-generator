from pathlib import Path
import runpy
from sdd.validation_stage import staged
@staged
def run():
    runpy.run_path(str(Path(__file__).with_name('recover_current_receipts.py')),run_name='__main__')
run()
