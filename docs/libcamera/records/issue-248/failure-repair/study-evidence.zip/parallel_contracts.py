"""Bounded native batches; the standard audit must independently enforce all receipts."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
from dataclasses import asdict,replace
import json,time,threading
from sdd.config import load
from sdd.facts.model import KnowledgeModel
from sdd.consistency import groups,request,batches,review_store,validate,SYSTEM,policy_hash
from sdd.cli_checkpoint import Capture
from sdd.llm import Agent
from sdd.validation_stage import staged,current

root=Path(__file__).resolve().parent;out=root/'current-policy-contracts-attempt02';out.mkdir(exist_ok=True)
cfg=load(root/'inherited/workspace/run-05/issue248-review.yaml');model=KnowledgeModel.load(cfg.facts_path)
assert cfg.agent.kind=='cli' and cfg.agent.runner=='codex' and cfg.agent.model=='gpt-6.1-terra'
assert not cfg.publication.get('budget'),'An operation budget needs the standard serial execution ledger.'
prior_path=root/'current-policy-contracts/results.json'
prior=json.loads(prior_path.read_text(encoding='utf-8'))
prior_reserved=prior['new_calls_reserved']
# Conservatively include all elapsed time since the first durable prior record,
# plus one minute for its preflight. This also counts the diagnostic pause.
prior_seconds=max(0,time.time()-prior_path.stat().st_birthtime)+60
started=time.monotonic();mutex=threading.RLock();reserved=prior_reserved
limits={key:getattr(cfg.review,key) for key in ['max_calls','max_seconds','document_max_calls','document_max_seconds']}
report=dict(status='running',concurrency=4,limits=limits,operation_budget='not-configured',operation_id=cfg.publication.get('operation_id'),profile=asdict(cfg.agent),source_commit=model.meta['source_commit'],policy_sha256=policy_hash(),units=[],new_calls_reserved=0,prior_attempt_reserved=prior_reserved,prior_attempt_seconds_conservative=prior_seconds,human_review='pending')
def save():
 (out/'results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def remaining():
 elapsed=time.monotonic()-started+prior_seconds
 ceilings=[value-elapsed for key,value in limits.items() if key.endswith('seconds') and value]
 if ceilings and min(ceilings)<=0:raise RuntimeError('Configured run/document time limit exhausted')
 return min([cfg.agent.timeout_sec,*ceilings])
def unit(task):
 global reserved
 group,index,batch,store,envelope=task;begin=time.monotonic()
 row=dict(group=group,index=index,checkpoint=store.path.name)
 try:
  with mutex:remaining()
  cached=store.read()
  if cached is not None:
   saved,_=cached;checked=validate(batch,saved['raw']);assert checked==saved['statements']
   row.update(status='checkpoint-revalidated',receipts=[])
  else:
   with mutex:
    timeout=remaining()
    for key in ['max_calls','document_max_calls']:
     if limits[key] and reserved>=limits[key]:raise RuntimeError('Configured '+key+' exhausted')
    reserved+=1;report['new_calls_reserved']=reserved-prior_reserved;save()
   dump=cfg.build_dir/'prompts'
   capture=Capture(Agent(replace(cfg.agent,timeout_sec=timeout),dump))
   raw=capture.chat(SYSTEM,envelope['user'],tag=f'contract_{group}_{index}',response_schema=envelope['response_schema'])
   checked=validate(batch,raw);store.write(raw,checked,capture);assert capture.receipts
   row.update(status='new-cli-completed',receipts=[str(p.relative_to(root)) for p in capture.receipts])
  with mutex:remaining()
  row['verdicts']={state:sum(v['status']==state for v in checked) for state in ['compatible','ambiguous','insufficient-evidence','contradiction']}
 except Exception as error:row.update(status='failed',error=str(error))
 row['elapsed_seconds']=round(time.monotonic()-begin,3)
 return row
@staged
def run():
 tasks=[]
 for group in groups(cfg):
  payload=request(cfg,model,group)
  for index,batch in enumerate(batches(payload,max_input_chars=cfg.agent.max_input_chars)):
   store,envelope=review_store(cfg,batch)
   assert len(SYSTEM)+len(envelope['user'])<=cfg.agent.max_input_chars
   tasks.append((group['id'],index,batch,store,envelope))
 report['planned_units']=len(tasks);save()
 with ThreadPoolExecutor(max_workers=4) as pool:
  for f in as_completed([pool.submit(unit,t) for t in tasks]):
   with mutex:
    report['units'].append(f.result());save()
   print(f'Completed {len(report["units"])}/{len(tasks)} native contract units',flush=True)
 current().verify()
 report.update(status='failed' if any(x['status']=='failed' for x in report['units']) else 'completed',elapsed_seconds=round(time.monotonic()-started,3));save()
 assert report['status']=='completed','A native unit failed; original output preserved. No substitute used.'
run()
