from pathlib import Path
import json
from sdd.config import load
from sdd.localization_cli import prepare_catalog
root=Path(__file__).resolve().parent
cfg=load(root/'inherited/workspace/run-05/issue248-candidate.yaml')
report=prepare_catalog(cfg,Path(cfg.site.english_catalog),translate=True)
(root/'translation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
assert report['missing_translations']==0,report
print(json.dumps(report),flush=True)
