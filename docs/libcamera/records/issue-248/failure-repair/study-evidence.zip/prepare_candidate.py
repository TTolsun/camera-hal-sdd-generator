from pathlib import Path
import yaml,json,copy,shutil,hashlib
from sdd.config import load
from sdd.facts.model import KnowledgeModel
from sdd.visual_refresh import refresh
from sdd.trial_workspace import write_snapshot

root=Path(__file__).resolve().parent;repo=root.parents[2]
base=root/'inherited/workspace/run-05';original=load(base/'sdd.yaml')
raw=copy.deepcopy(original.raw)
new=base/'manuscripts-issue248'
shutil.copytree(original.sdd_dir,new,dirs_exist_ok=True)
raw.setdefault('output',{})['sdd_dir']=str(new)
raw['output']['facts_dir']=str(original.facts_dir)
catalog=base/'english-issue248.json';shutil.copyfile(Path(original.site.english_catalog),catalog)
raw['site']['english_catalog']=str(catalog)
example=yaml.safe_load((repo/'examples/libcamera/sdd.yaml').read_text(encoding='utf-8'))
raw['site']['topic_links']=copy.deepcopy(example['site']['topic_links'])
raw['site']['reading_checkpoints']=copy.deepcopy(example['site']['reading_checkpoints'])
previous_visuals=yaml.safe_load(Path(original.visuals.file).read_text(encoding='utf-8'))
addition=json.loads((root/'visual-repair/attempt02/definition.json').read_text(encoding='utf-8'))
found=[i for i,v in enumerate(previous_visuals['sections']['overview']) if v['id']==addition['id']]
assert len(found)==1
previous_visuals['sections']['overview'][found[0]]=addition
vpath=base/'visuals-issue248.yaml';vpath.write_text(yaml.safe_dump(previous_visuals,allow_unicode=True,sort_keys=False),encoding='utf-8',newline='\n')
raw['visuals']['file']=str(vpath)
raw['publication']['baseline_config']=str(base/'sdd.yaml')
raw['publication']['operation_id']='issue248-failed-task-repair'
raw['publication']['allowed_contract_changes']={}
raw['paths']['consistency_review_config']=str(base/'issue248-review.yaml')
raw['paths']['translation_profile']=str(base/'issue248-translation.yaml')
for name in ['issue248-candidate.yaml','issue248-review.yaml','issue248-translation.yaml']:
 (base/name).write_text(yaml.safe_dump(raw,allow_unicode=True,sort_keys=False),encoding='utf-8',newline='\n')
cfg=load(base/'issue248-candidate.yaml');model=KnowledgeModel.load(cfg.facts_path)
old=(original.sdd_dir/'overview.md').read_bytes()
expected=json.loads((root/'baseline/docs/site-manifest.json').read_text(encoding='utf-8'))['outputs']['overview.md']
assert hashlib.sha256(old).hexdigest()==expected
derived=refresh(cfg,model,'overview',old,expected_sha256=expected)
(new/'overview.md').write_bytes(derived)
unchanged=[p.relative_to(original.sdd_dir).as_posix() for p in original.sdd_dir.rglob('*.md') if p.name!='overview.md' and (new/p.relative_to(original.sdd_dir)).read_bytes()==p.read_bytes()]
assert len(unchanged)==28
report=dict(config=str(base/'issue248-candidate.yaml'),original_manuscript_sha256=expected,derived_manuscript_sha256=hashlib.sha256(derived).hexdigest(),unchanged_manuscripts=unchanged,original_prose_outside_managed_visual_preserved=True,new_inference='Three fresh CLI calls including first rejected draft; accepted graph draft and separate review preserved.',human_approval='unchanged',baseline_public='019c8d068f140764bf9f7ed34699ddc67f7b2478')
(root/'candidate.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report),flush=True)
