// Read only the frozen HTTP site in a fresh Chromium context. No answer key.
const {chromium}=require('C:/Users/baboe/.codex/worktrees/cb18/camera-hal-sdd-generator/build/pan-20261105/pw/node_modules/playwright');
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
(async()=>{
 const [role,target='index.html']=process.argv.slice(2);
 if(!/^(new|other|nonauthor)$/.test(role))throw Error('Unknown role');
 const root=__dirname,lock=JSON.parse(fs.readFileSync(path.join(root,'reader-lock.json'),'utf8'));
 const url=new URL(target,lock.start_url),origin=new URL(lock.start_url);
 if(url.origin!==origin.origin||!url.pathname.startsWith(origin.pathname.replace(/index.html$/,'')))throw Error('Only frozen local site allowed');
 const relative=decodeURIComponent(url.pathname.slice(1));
 const manifest=JSON.parse(fs.readFileSync(path.join(root,'site-trial/site-manifest.json'),'utf8'));
 if(!relative.endsWith('.html')||!manifest.outputs[relative])throw Error('Only owned frozen HTML pages allowed');
 const dir=path.join(root,'readers',role,'visits');fs.mkdirSync(dir,{recursive:true});
 const started=new Date().toISOString(),browser=await chromium.launch({channel:'chrome',headless:true});
 const ctx=await browser.newContext({viewport:{width:1280,height:900}}),page=await ctx.newPage();
 await ctx.route('**/*',async route=>{
  const asset=new URL(route.request().url());
  if(asset.origin!==origin.origin)return route.abort();
  const name=decodeURIComponent(asset.pathname.slice(1));
  if(!manifest.outputs[name])return route.abort();
  const file=path.join(root,'site-trial',name);
  const type=name.endsWith('.mjs')?'application/javascript':undefined;
  return route.fulfill({path:file,contentType:type});
 });
 const response=await page.goto(url.href);const sha=crypto.createHash('sha256').update(await response.body()).digest('hex');
 if(sha!==manifest.outputs[relative])throw Error('HTTP response differs from frozen file');
 await page.waitForLoadState('networkidle');
 await page.waitForTimeout(500);
 const result=await page.evaluate(()=>{
  const main=document.querySelector('main');if(!main)throw Error('No main');let scopeNodes=[main];
  const anchor=decodeURIComponent(location.hash.slice(1));let text=main.innerText;
  if(anchor){let first=document.getElementById(anchor);if(!first||!main.contains(first))throw Error('Unknown main anchor');
   if(/^H[1-6]$/.test(first.tagName)){const level=+first.tagName[1],parts=[];scopeNodes=[];let n=first;while(n){if(n!==first&&/^H[1-6]$/.test(n.tagName)&&+n.tagName[1]<=level)break;parts.push(n.innerText||'');scopeNodes.push(n);n=n.nextElementSibling;}text=parts.join('\n');}
   else text=first.innerText||text;
  }
  const visible=n=>!n.closest('details:not([open])')&&getComputedStyle(n).display!=='none';
  return {url:location.href,title:document.title,text:text.slice(0,18000),truncated:text.length>18000,
   headings:[...main.querySelectorAll('h1,h2,h3,h4')].filter(visible).map(n=>({text:n.textContent,id:n.id})),
   links:[...main.querySelectorAll('a[href]')].filter(visible).map(n=>({text:n.textContent,href:n.getAttribute('href')})),
   diagrams:scopeNodes.flatMap(n=>[...n.querySelectorAll('svg')]).filter(visible).map(n=>[...n.querySelectorAll('text,foreignObject')].map(t=>t.textContent).join('\n'))};
 });
 const stamp=Date.now(),prefix=path.join(dir,String(stamp));await page.screenshot({path:prefix+'.png'});
 const record={started,finished:new Date().toISOString(),source_kind:'agent-browser-visit',build_id:lock.build_id,http_sha256:sha,manifest_verified:true,...result};
 fs.writeFileSync(prefix+'.json',JSON.stringify(record,null,2)+'\n');
 console.log(JSON.stringify({...record,screenshot:prefix+'.png',record:prefix+'.json'},null,2));
 await browser.close();
})().catch(e=>{console.error(e.stack);process.exit(1)});
