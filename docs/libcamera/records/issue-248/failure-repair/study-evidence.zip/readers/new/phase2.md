# P01 신입 개발자 관점 자동 독자 재개 기록

고정 빌드 `236846f043d327f50e060de29ac5b8e20ca0e42b6378e23def6d2eae43fe4270`에서 진행했다. R 메모는 2026-11-11T18:37:06.8916858Z에 저장했고, 2026-11-11T18:42:45.6668881Z에 다시 읽기 시작했다. 두 시각의 간격은 338.775초였다. 재개 때 확인한 메모의 SHA-256은 `b0a3d9460015d3b8f539aee46786830ceee86f379a946d402cf06efd9f87e0e1`이다.

## R

조사는 문서에서 확인 순서를 찾은 상태였다. 제보는 완료 알림이 보이지 않는다는 것이고, 앞 카드와 같은 상황이라면 제출은 성공했다고 했다. 메모에 실제 실행 로그가 없으므로 정확한 반환값, 호출 파일과 제출 회차, 장치 제출과 버퍼 처리 여부, 앱 콜백이 실제로 빠졌는지는 아직 확인하지 못했다.

먼저 같은 제출 회차에서 원래 `Camera::queueRequest()`의 반환값과 호출 파일을 기록한다. 값을 얻으려고 다시 제출하지 않는다. 음수면 제출 오류부터 좁힌다. 0이면 비동기로 처리하도록 예약한 상태다. `doQueueRequests()`에서 대기 요청이 있는지와 장치 큐 한도를 확인하고, 여유가 있다면 선두 요청의 `prepared_`를 확인한다. 장치 제출까지 갔다면 `queueRequestDevice()`의 반환값과 취소 분기를 확인한다.

장치 처리가 진행됐다면 같은 회차의 `bufferCompleted`와 기존 `completeBuffer()` 반환값을 대조한다. `false`면 남은 버퍼를 추적하고, `true`면 핸들러가 `completeRequest()`를 호출했는지 확인한다. 호출 기록이 있는데 앱 알림이 없다면 제출 큐 선두의 `RequestPending` 여부, `requestComplete(req)` 호출, 앱의 `requestCompleted` 수신 순서로 본다.

- 시작 화면에서 요청 문제 진단 문서로 가는 경로를 찾았다. [index.html#처음-읽는-개발자의-순서](https://frozen-sdd.test/index.html#%EC%B2%98%EC%9D%8C-%EC%9D%BD%EB%8A%94-%EA%B0%9C%EB%B0%9C%EC%9E%90%EC%9D%98-%EC%88%9C%EC%84%9C)
- 0 반환은 비동기 전달 예약을 뜻하며, 명시적인 completeRequest 호출과 제출 순서에 따른 반환을 설명한다. [request-lifecycle.html#제출에서-완료까지](https://frozen-sdd.test/request-lifecycle.html#%EC%A0%9C%EC%B6%9C%EC%97%90%EC%84%9C-%EC%99%84%EB%A3%8C%EA%B9%8C%EC%A7%80)
- 원래 호출 반환값·호출 파일 기록, 장치 큐·준비 조건, 장치 제출과 취소, 버퍼 반환값 및 큐 선두 상태를 확인할 순서가 나온다. [request-diagnosis.html#실패-위치별-확인-순서](https://frozen-sdd.test/request-diagnosis.html#%EC%8B%A4%ED%8C%A8-%EC%9C%84%EC%B9%98%EB%B3%84-%ED%99%95%EC%9D%B8-%EC%88%9C%EC%84%9C)

- 방문 경로는 `index.html` → `request-lifecycle.html` → `request-diagnosis.html#실패-위치별-확인-순서`였다. 되돌아간 페이지는 없었다.
- 재개는 2026-11-11T18:42:45.6668881Z, 첫 방문은 2026-11-11T18:42:50.450Z, 근거를 다시 찾은 시각은 2026-11-11T18:43:14.192Z, 원답을 기록한 시각은 2026-11-11T18:43:43.6275476Z였다. 재개에서 근거까지 28.525초, 첫 방문에서 근거까지 23.742초, 재개에서 원답까지 57.961초였다.
- 「구성과 요청 오류 조사」라는 이름의 링크가 여러 개 있어 메모에 적은 절 주소와 대조했다. 실행 로그가 없어 어느 분기에서 멈췄는지는 판정할 수 없었다.
- 도움을 요청하지 않았다.

## X

이 제출 회차에서 두 버퍼 중 하나의 `bufferCompleted` 알림을 봤다는 사실만 확정할 수 있다. 알림은 내부 추적을 갱신하기 전에 나올 수 있고, 취소 경로에서도 나올 수 있다. 다른 버퍼가 아직 처리 중인지, 이미 끝났는데 알림을 관측하지 못했는지, 요청 자체가 정상 완료됐는지 또는 취소됐는지는 이 기록만으로 확인할 수 없다.

우선 같은 제출 회차의 요청과 두 버퍼를 각각 구분해서 두 번째 버퍼의 처리·취소·알림 기록을 찾고, 기존 `completeBuffer()`의 반환값을 확인한다. `false`면 그 호출의 갱신 시점에 남은 버퍼가 있다. `true`면 모든 버퍼가 완료된 상태까지 확인한 것이다. 요청 자체의 결과를 알려면 `completeRequest()` 또는 그 앞의 취소 경로를 관찰하고, `RequestComplete`와 `RequestCancelled` 중 어떤 상태인지 확인한다.

요청 완료 통지가 보이지 않으면 제출 큐 선두가 `RequestPending`이라 반환을 막고 있는지, `requestComplete(req)`까지 호출됐는지, 앱이 `requestCompleted`를 수신했는지 확인한다. 앱의 요청 완료 콜백을 확인할 때까지 버퍼는 유효하게 유지한다.

- 그림에서 기존 completeBuffer()의 false·true와 별도 completeRequest() 호출을 구분한다. [request-diagnosis.html#버퍼-완료와-명시적-요청-완료의-경계](https://frozen-sdd.test/request-diagnosis.html#%EB%B2%84%ED%8D%BC-%EC%99%84%EB%A3%8C%EC%99%80-%EB%AA%85%EC%8B%9C%EC%A0%81-%EC%9A%94%EC%B2%AD-%EC%99%84%EB%A3%8C%EC%9D%98-%EA%B2%BD%EA%B3%84)
- bufferCompleted 발행이 내부 추적 갱신보다 먼저라는 점과 기존 호출의 반환값, 명시적 완료, 앱 콜백을 별도로 관찰할 순서가 나온다. [request-lifecycle.html#정상-완료와-다음-요청-준비](https://frozen-sdd.test/request-lifecycle.html#%EC%A0%95%EC%83%81-%EC%99%84%EB%A3%8C%EC%99%80-%EB%8B%A4%EC%9D%8C-%EC%9A%94%EC%B2%AD-%EC%A4%80%EB%B9%84)
- 취소 중에도 버퍼 알림이 발행될 수 있고, 정상·취소 완료 모두 앞선 요청이 대기 중이면 반환이 늦어질 수 있다. 요청 완료 콜백까지 버퍼 유효성을 유지한다. [request-lifecycle.html#알림-순서와-취소가-달라질-때](https://frozen-sdd.test/request-lifecycle.html#%EC%95%8C%EB%A6%BC-%EC%88%9C%EC%84%9C%EC%99%80-%EC%B7%A8%EC%86%8C%EA%B0%80-%EB%8B%AC%EB%9D%BC%EC%A7%88-%EB%95%8C)

- 방문 경로는 `request-diagnosis.html#버퍼-완료와-명시적-요청-완료의-경계` → `request-lifecycle.html` → `request-lifecycle.html#정상-완료와-다음-요청-준비` → `request-lifecycle.html#알림-순서와-취소가-달라질-때`였다.
- 진단 그림에서 반환값 분기를 확인한 뒤 「이전 요청 처리와 문제 진단」으로 돌아가 알림 순서와 취소 때의 동작을 확인했다.
- 과업 시작은 2026-11-11T18:43:49.4648363Z, 첫 방문은 2026-11-11T18:43:50.308Z, 마지막 근거 확인은 2026-11-11T18:44:23.006Z, 원답 기록은 2026-11-11T18:45:17.2738426Z였다. 시작에서 마지막 근거까지 33.542초, 원답까지 87.809초였다.
- 버퍼 하나의 알림 관측만 주어졌다. 두 번째 버퍼나 요청 자체의 상태를 확인할 실행 기록은 없었다.
- 도움을 요청하지 않았다.
