# P02 타팀 개발자 관점의 R 재개와 X 과업 기록

고정 빌드는 `236846f043d327f50e060de29ac5b8e20ca0e42b6378e23def6d2eae43fe4270`입니다. 자동 에이전트가 수행했습니다. [시작 페이지](https://frozen-sdd.test/index.html)

중단 직전 메모는 2026-11-11T18:39:25.1006191Z에 저장했고 2026-11-11T18:44:51.9340722Z에 원본 메모의 해시를 확인하며 R을 재개했습니다. 두 시각 사이에는 326.8초가 지났습니다. SHA-256은 `a6cb1eab8585b00731f0dfeff0533154d688e14aade606a8bd6f091586e6af77`입니다. [중단 직전 원본 메모](pre-interrupt-note.md)

## R

중단 직전 메모만 들고 시작 페이지로 돌아와 조사 상태, 다음 행동과 근거를 다시 찾으세요.

메모에서 복원한 관측값은 Camera::queueRequest()의 0 반환과 requestCompleted 미관측이다. 0은 핸들러에 비동기 전달을 예약했다는 뜻이다. 같은 제출 회차의 장치 큐 진입, 반환값, 버퍼별 완료, 명시적 요청 완료, 제출 큐의 선두 상태는 모두 미확인이다. 먼저 요청이 유효할 때 확보한 제출 회차 식별 기록으로 해당 요청과 먼저 들어온 요청을 연결하고, 장치 큐 진입과 queueRequestDevice() 반환값을 확인하겠다. 장치 함수에 닿지 않았다면 대기 큐 선두의 prepared_ 상태와 fence 신호, 장치 큐 한도를 조사한다. 장치 제출에서 오류가 관측되면 취소 경로를 확인한다. 장치 제출이 성공했다면 버퍼별 completeBuffer()와 마지막 버퍼에서의 true 반환, 핸들러의 completeRequest() 진입, camera->requestComplete(req) 호출을 각각 확인한다. 내부 완료 뒤에 앱으로 반환되지 않았다면 앞 요청이 RequestPending인지 확인한다. 앱으로 통지하는 호출까지 기록됐다면 같은 회차의 requestCompleted 연결과 콜백 진입 시각을 대조한다.

- 접수 성공의 의미, 선두의 준비 상태와 장치 큐 한도, 장치 제출 오류 시 취소, 버퍼별 완료와 명시적 요청 완료까지의 단계가 나온다. [request-lifecycle.html#제출에서-완료까지](https://frozen-sdd.test/request-lifecycle.html#%EC%A0%9C%EC%B6%9C%EC%97%90%EC%84%9C-%EC%99%84%EB%A3%8C%EA%B9%8C%EC%A7%80)
- 현재 요청의 내부 상태를 갱신한 뒤 제출 큐 선두가 Pending이면 반환 루프를 멈추는 흐름이 나온다. [request-lifecycle.html#완료-상태와-애플리케이션-반환의-차이](https://frozen-sdd.test/request-lifecycle.html#%EC%99%84%EB%A3%8C-%EC%83%81%ED%83%9C%EC%99%80-%EC%95%A0%ED%94%8C%EB%A6%AC%EC%BC%80%EC%9D%B4%EC%85%98-%EB%B0%98%ED%99%98%EC%9D%98-%EC%B0%A8%EC%9D%B4)
- 요청이 유효할 때 논리적 제출 회차를 식별하고 completeRequest() 진입과 requestComplete(req) 통지를 별도로 기록하는 방법이 나온다. 문서가 제안하는 관찰 지점이며, 실제 앱의 연결 방식과 수신 스레드는 아직 검증되지 않았다고 적혀 있다. [request-lifecycle.html#제출-회차별-완료-기록의-비교-계획](https://frozen-sdd.test/request-lifecycle.html#%EC%A0%9C%EC%B6%9C-%ED%9A%8C%EC%B0%A8%EB%B3%84-%EC%99%84%EB%A3%8C-%EA%B8%B0%EB%A1%9D%EC%9D%98-%EB%B9%84%EA%B5%90-%EA%B3%84%ED%9A%8D)

2026-11-11T18:44:51.9340722Z부터 2026-11-11T18:46:06.8953735Z까지 75초가 걸렸습니다. 실행 로그와 회차 식별값이 주어지지 않아 어디에서 요청 처리가 지연되었는지 확정하지 못했다. 도움을 요청하지 않았습니다.

- 방문 경로는 `index.html` → `request-lifecycle.html` → `request-lifecycle.html#제출에서-완료까지` → `request-lifecycle.html#완료-상태와-애플리케이션-반환의-차이` → `request-lifecycle.html#제출-회차별-완료-기록의-비교-계획`입니다.
- 메모로 복원한 경로는 `index.html` → `request-lifecycle.html` → `request-lifecycle.html#제출에서-완료까지`입니다.

## X

같은 요청에 버퍼가 둘 있는데 하나의 버퍼 완료만 관측했습니다. 무엇을 단정할 수 있고 무엇을 더 조사해야 하는지 문서 근거와 함께 답하세요.

확인한 사실은 그 요청의 버퍼 하나에 대한 완료 알림을 관측했다는 것이다. 두 번째 버퍼의 실제 처리 상태와 알림 상태, 요청 전체가 앱에 반환됐는지는 이 관측만으로 알 수 없다. 문서에 따르면 completeBuffer()는 개별 버퍼를 알리고 내부 추적을 갱신한다. 핸들러가 두 버퍼 중 첫 번째만 완료 처리한 시점이라면 false가 반환된다. 둘 다 완료 처리되면 true가 반환되고, 핸들러는 별도로 CameraManager 스레드에서 completeRequest()를 호출한다. 먼저 같은 요청 회차에서 두 버퍼를 각각 식별하고 두 번째 버퍼의 장치 처리와 completeBuffer() 호출·반환값, 앱의 버퍼 알림 관측을 대조하겠다. 두 버퍼가 모두 완료된 기록이 있으면 completeRequest() 호출과 실행 스레드를 확인한다. 내부 완료 뒤에도 requestCompleted가 보이지 않으면 앞선 요청이 제출 큐에서 Pending인지 확인하고, 해당 회차의 앱 반환 및 콜백 관측을 대조한다.

- completeBuffer()는 개별 버퍼를 통지하고 내부 추적을 갱신한다. 모든 버퍼가 끝났는지 반환하며 마지막 버퍼 이후에도 핸들러가 명시적으로 완료해야 한다. [overview.html#버퍼-완료와-요청-완료](https://frozen-sdd.test/overview.html#%EB%B2%84%ED%8D%BC-%EC%99%84%EB%A3%8C%EC%99%80-%EC%9A%94%EC%B2%AD-%EC%99%84%EB%A3%8C)
- 파이프라인 핸들러가 CameraManager 스레드에서 completeRequest()를 호출할 의무가 있다. [overview.html#스레드-경계와-동기화](https://frozen-sdd.test/overview.html#%EC%8A%A4%EB%A0%88%EB%93%9C-%EA%B2%BD%EA%B3%84%EC%99%80-%EB%8F%99%EA%B8%B0%ED%99%94)
- 카메라가 requestCompleted 신호로 요청 전체의 완료를 알린다. [overview.html#요청-제출과-완료](https://frozen-sdd.test/overview.html#%EC%9A%94%EC%B2%AD-%EC%A0%9C%EC%B6%9C%EA%B3%BC-%EC%99%84%EB%A3%8C)
- 요청 상태를 완료로 갱신한 뒤 제출 큐 선두가 Pending이면 앱 반환을 보류한다. [request-lifecycle.html#제출-큐의-선두-상태와-반환-순서](https://frozen-sdd.test/request-lifecycle.html#%EC%A0%9C%EC%B6%9C-%ED%81%90%EC%9D%98-%EC%84%A0%EB%91%90-%EC%83%81%ED%83%9C%EC%99%80-%EB%B0%98%ED%99%98-%EC%88%9C%EC%84%9C)

2026-11-11T18:46:11.076Z부터 2026-11-11T18:47:20.3270682Z까지 69.3초가 걸렸습니다. 주어진 관측은 버퍼 하나의 완료뿐이다. 두 번째 버퍼, 핸들러 호출, 앱 신호의 실제 기록은 주어지지 않았다. 도움을 요청하지 않았습니다.

- 방문 경로는 `index.html` → `overview.html#요청-제출과-완료` → `overview.html#버퍼-완료와-요청-완료` → `overview.html#스레드-경계와-동기화` → `index.html` → `request-lifecycle.html#제출-큐의-선두-상태와-반환-순서`입니다.
- 되돌아간 경로는 `overview.html#스레드-경계와-동기화` → `index.html`입니다.
