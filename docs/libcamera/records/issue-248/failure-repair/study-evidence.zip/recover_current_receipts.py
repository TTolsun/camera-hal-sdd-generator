"""Recover this attempt's genuine completed calls after a storage path error.

Original bytes and execution times stay intact; this is not a new execution or
a replacement for unavailable CLI work. Standard cache and audit gates remain.
"""
from pathlib import Path
import json,shutil,hashlib
from types import SimpleNamespace
from sdd.config import load
from sdd.facts.model import KnowledgeModel
from sdd.consistency import groups,request,batches,review_store,validate
from sdd.call_records import load_record,canonical_request_hash
from sdd.cli_provenance import verify_cli_receipt
root=Path(__file__).resolve().parent
cfg=load(root/'inherited/workspace/run-05/issue248-review.yaml');model=KnowledgeModel.load(cfg.facts_path)
target=cfg.build_dir/'prompts';target.mkdir(exist_ok=True)
expected={}
for group in groups(cfg):
 for index,batch in enumerate(batches(request(cfg,model,group),max_input_chars=cfg.agent.max_input_chars)):
  store,envelope=review_store(cfg,batch)
  expected[canonical_request_hash(envelope)]=(group['id'],index,batch,store)
rows=[]
for receipt in sorted((root/'current-policy-contracts').glob('*/prompts/calls/*/*.receipt.json')):
 calls=receipt.parent.parent;dump=calls.parent
 record=load_record(receipt,root=calls)
 verify_cli_receipt(record.request,record.raw,record.receipt,calls,cfg.agent)
 assert record.receipt['request_sha256'] in expected
 group,index,batch,store=expected[record.receipt['request_sha256']]
 for path in dump.rglob('*'):
  if not path.is_file():continue
  rel=path.relative_to(dump)
  if rel.parts[0] not in ['calls','cli']:continue
  dest=target/rel;dest.parent.mkdir(parents=True,exist_ok=True)
  if dest.exists():assert dest.read_bytes()==path.read_bytes()
  else:shutil.copyfile(path,dest)
 new_receipt=target/receipt.relative_to(dump)
 assert new_receipt.read_bytes()==receipt.read_bytes()
 checked=validate(batch,record.raw)
 store.write(record.raw,checked,SimpleNamespace(receipts=[new_receipt]))
 assert store.read() is not None
 rows.append(dict(group=group,index=index,original_receipt=str(receipt.relative_to(root)),receipt_sha256=hashlib.sha256(receipt.read_bytes()).hexdigest(),original_completed_at=record.receipt['completed_at'],status='same-attempt-completed-call-recovered',new_execution=False))
(root/'receipt-recovery.json').write_text(json.dumps(dict(status='verified',scope='Only original genuine calls from this current failed storage attempt',recovered=len(rows),rows=rows,new_executions=0),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(f'Recovered and verified {len(rows)} original current-attempt CLI calls; new executions 0.',flush=True)
