from pathlib import Path
from datetime import datetime
import hashlib
import json
import statistics

root = Path(__file__).resolve().parent
lock = json.loads((root / 'reader-lock.json').read_text(encoding='utf-8'))
study = json.loads((root / 'protocol.json').read_text(encoding='utf-8'))
assert hashlib.sha256((root / 'grade.py').read_bytes()).hexdigest() == study['preregistered_grader_sha256']
assert hashlib.sha256((root / 'protocol.json').read_bytes()).hexdigest() == lock['protocol_sha256']
for name, expected in study['participant_input_hashes'].items():
    assert hashlib.sha256((root / 'participant-inputs' / name).read_bytes()).hexdigest() == expected

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def time(value):
    return datetime.fromisoformat(value.replace('Z', '+00:00'))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

counts = {key: {'aligned': 0, 'assigned': 0} for key in ('base', 'S', 'R', 'X')}
ratings = []
rows = []
for role in ('new', 'other', 'nonauthor'):
    directory = root / 'readers' / role
    before = read(directory / 'phase1.json')
    after = read(directory / 'phase2.json')
    assert before['build_id'] == after['build_id'] == lock['build_id']
    assert before['source_kind'] == after['source_kind'] == 'agent'
    note = sha(directory / 'pre-interrupt-note.md')
    assert before['r_note_sha256'] == after['r_note_sha256'] == note
    ready = time(before['r_ready_at_utc'])
    resume = time(after['r_resumed_at_utc'])
    interval = (resume - ready).total_seconds()
    assert interval >= 300
    visits = [read(path) for path in (directory / 'visits').glob('*.json')]
    assert visits and all(v['build_id'] == lock['build_id'] and v['manifest_verified'] for v in visits)
    assert not any(ready < time(v['started']) < resume for v in visits)
    resumed_visits = [v for v in sorted(visits, key=lambda v: v['started']) if time(v['started']) >= resume]
    assert resumed_visits[0]['url'] == lock['start_url']
    original_s = before['tasks']['S']
    saved = next(original_s[key] for key in ('answer_saved_at_utc', 'before_reopen_at_utc', 'before_reopen_saved_at_utc') if key in original_s)
    reopened = min((v for v in visits if time(v['started']) > time(saved)), key=lambda v: v['started'])
    assert (directory / 's-before-reopen.md').read_text(encoding='utf-8-sig').strip()
    grades = []
    for phase, expected in (('phase1', {'B1', 'B2', 'S'}), ('phase2', {'R', 'X'})):
        result = read(root / 'independent-grading' / role / phase / 'assessment.json')
        assert result['human_completion'] == 'not-established'
        assert {task['task_id'] for task in result['tasks']} == expected
        for task in result['tasks']:
            kind = 'base' if task['task_id'].startswith('B') else task['task_id']
            counts[kind]['assigned'] += 1
            counts[kind]['aligned'] += task['semantic_verdict'] == 'aligned'
            grades.append(task)
    for key in ('B1', 'B2'):
        task = before['tasks'][key]
        assert task['help_requested'] in (False, 'none', 'no', None)
        ratings.append(dict(role=role, task=key, **{f'{field}_{suffix}': task[f'{field}_{suffix}']
                            for field in ('reading_ease', 'interest', 'naturalness') for suffix in ('1_to_5', 'reason')}))
    rows.append(dict(role=role, grades=grades, r_ready_at=before['r_ready_at_utc'],
                     r_resumed_at=after['r_resumed_at_utc'], pause_seconds=round(interval, 3),
                     memo_sha256=note, browser_visits=len(visits), no_visit_recorded_during_pause=True,
                     s_before_reopen_sha256=sha(directory / 's-before-reopen.md'),
                     s_saved_at=saved, first_later_browser_visit_at=reopened['started']))
medians = {name: statistics.median(row[name + '_1_to_5'] for row in ratings)
           for name in ('reading_ease', 'interest', 'naturalness')}
result = dict(source_kind='agent', actual_human_participants=0, build_id=lock['build_id'], counts=counts,
              first_native_verdicts_preserved=True, ratings=ratings, rating_medians=medians,
              reader_rows=rows, human_review='pending')
(root / 'trial-summary.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(counts=counts, rating_medians=medians, pauses=[r['pause_seconds'] for r in rows]), ensure_ascii=False))
