import json
import shutil
from pathlib import Path
import yaml
from sdd.config import load
from sdd.localization_cli import prepare_catalog
area=Path(__file__).resolve().parent/'final-readers'
root=area/'inherited-249';base=root/'integration';assets=root/'evidence/inputs'
source=area/'source-be7'
profiles={}
for directory in (assets/'profiles').iterdir():
    original=next(directory.glob('*.yaml'))
    raw=yaml.safe_load(original.read_text(encoding='utf-8'))
    target=base/('restored-'+directory.name+'.yaml')
    target.write_text(yaml.safe_dump(dict(agent=raw['agent'],paths={'style':str(directory/'style')}),allow_unicode=True,sort_keys=False),encoding='utf-8',newline='\n')
    profiles[directory.name]=str(target)
for name in ['sdd.yaml','publication-repair.yaml','independent-review.yaml','translation-repair.yaml']:
    path=base/name
    raw=yaml.safe_load(path.read_text(encoding='utf-8'))
    raw['source'].update(root=str(source),compile_commands=str(root/'compile_commands.json'))
    for key in ['style','prompts','templates']:
        raw['paths'][key]=str(assets/'paths'/key)
    raw['site']['manuscript_profiles']=profiles
    path.write_text(yaml.safe_dump(raw,allow_unicode=True,sort_keys=False),encoding='utf-8',newline='\n')
cfg=load(base/'publication-repair.yaml')
assert json.loads(cfg.facts_path.read_text(encoding='utf-8'))['meta']['source_commit']=='be7e83e91348250c015aad6d6f59f1468555bae8'
import subprocess
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()=='be7e83e91348250c015aad6d6f59f1468555bae8'
report=prepare_catalog(cfg,Path(cfg.site.english_catalog),translate=True)
(area/'guide-repair/translation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
assert report['missing_translations']==0,report
print(json.dumps(report),flush=True)
