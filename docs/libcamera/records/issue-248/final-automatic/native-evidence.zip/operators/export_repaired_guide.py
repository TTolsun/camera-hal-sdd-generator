import hashlib
import json
from pathlib import Path
from sdd.config import load
from sdd.trial_workspace import write_snapshot
from sdd.site_localization import source_hash
from sdd.export_site import export_site
area=Path(__file__).resolve().parent/'final-readers';base=area/'inherited-249/integration'
path=base/'publication-repair.yaml';cfg=load(path)
report=base/'build/consistency-review.json'
value=json.loads(report.read_text(encoding='utf-8'));assert value['status']=='passed'
for entry in cfg.raw['publication']['reports']:
    if str(entry['path']).replace('\\','/').endswith('/consistency-review.json'):
        entry['path']=str(report);entry['sha256']=hashlib.sha256(report.read_bytes()).hexdigest()
bilingual=area/'guide-repair/english-review/assessment.json'
assert json.loads(bilingual.read_text(encoding='utf-8'))['verdict']=='faithful'
if not any(entry['path']==str(bilingual) for entry in cfg.raw['publication']['reports']):
    cfg.raw['publication']['reports'].append(dict(path=str(bilingual),sha256=hashlib.sha256(bilingual.read_bytes()).hexdigest(),
        producer='independent-codex-cli-guide-review',gate='before-export',bindings={'verdict':'faithful'}))
write_snapshot(cfg,path)
cfg=load(path)
first=export_site(cfg,area/'site-after')
second=export_site(cfg,area/'site-after-repeat')
raw=(first/'site-manifest.json').read_bytes()
assert raw==(second/'site-manifest.json').read_bytes()
from sdd.site_build import verify_site
manifest=json.loads(raw)
before=json.loads((area/'site/site-manifest.json').read_text(encoding='utf-8'))
md=[name for name in manifest['outputs'] if name.endswith('.md')]
assert all((first/name).read_bytes()==(area/'site'/name).read_bytes() for name in md)
changed=[name for name in manifest['outputs'] if before['outputs'].get(name)!=manifest['outputs'][name]]
assert set(changed)<={'overview.html','en/overview.html','contract-consistency.json'},changed
result=dict(schema=1,build_id=manifest['build_id'],manifest_sha256=hashlib.sha256(raw).hexdigest(),
    outputs=len(manifest['outputs']),quality=verify_site(first),repeat_quality=verify_site(second),
    repeated_manifest_identical=True,changed_outputs=changed,unchanged_manuscripts=len(md),
    before_build_id=before['build_id'],contract_fresh_batches=value['fresh_batches'],
    contract_revalidated_batches=value['reused_batches'],inherited_unresolved=len(value['unresolved']),
    source_commit='be7e83e91348250c015aad6d6f59f1468555bae8',
    source_kind='agent',human_approval='unchanged')
(area/'guide-repair/site-verification.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(result),flush=True)
