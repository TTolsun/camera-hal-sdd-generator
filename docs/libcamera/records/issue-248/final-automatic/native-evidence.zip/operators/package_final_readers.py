import hashlib
import json
import shutil
import zipfile
from datetime import datetime
from pathlib import Path
from sdd.call_records import load_record
from sdd.cli_provenance import verify_cli_receipt
from sdd.config import AgentConfig

area=Path(__file__).resolve().parent
trial=area/'final-readers'
out=area/'automatic-results-release/docs/libcamera/records/issue-248/final-automatic'
out.mkdir(parents=True,exist_ok=True)
def copy(source,relative):
    target=out/relative;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target)

for reader in ['reader-new','reader-other','reader-nonauthor']:
    for path in (trial/reader).iterdir():
        if path.suffix in {'.md','.json','.log'}:copy(path,reader+'/'+path.name)
for name in ['protocol.json','experience-estimates.json','pause-ledger.json','regression-final.log','regression-sandbox-temp-error.log']:
    copy(trial/name,name)
copy(trial/'site/site-manifest.json','before-site-manifest.json')
copy(trial/'site-after/site-manifest.json','after-site-manifest.json')
shutil.copytree(trial/'participant-inputs',out/'participant-inputs',dirs_exist_ok=True)
old=area/'release/publication/issue248/study-candidate'
for name in ['protocol.md','facilitator.md','rubric-163.md']:
    # This verbatim historical protocol contains links relative to its original
    # directory. Keep it as text data and link the canonical document separately.
    copy(old/name,'rubrics/'+(name+'.txt' if name=='protocol.md' else name))
(out/'rubrics/protocol.md').unlink(missing_ok=True)
for path in (trial/'independent-grading').rglob('assessment.json'):
    copy(path,'assessments/'+path.relative_to(trial/'independent-grading').as_posix())
for name in ['binding.json','binding-v1.json','translation.json','translation-v2.json','site-verification.json','labels.json']:
    copy(trial/'guide-repair'/name,'guide-repair/'+name)
for name in ['scope-review','scope-review-v1','english-review','english-review-v1']:
    copy(trial/'guide-repair'/name/'assessment.json','guide-repair/'+name+'.json')
for name in ['ui-auto','ui-after']:
    shutil.copytree(trial/name,out/name,dirs_exist_ok=True)

ledger=json.loads((trial/'pause-ledger.json').read_text(encoding='utf-8'))
ready=ledger['readers']
keys={'reader-new':'resume_clock_utc','reader-other':'r_resume_utc','reader-nonauthor':'resume_utc'}
for reader,key in keys.items():
    raw=json.loads((trial/reader/'phase2.json').read_text(encoding='utf-8'))
    interval=(datetime.fromisoformat(raw[key].replace('Z','+00:00'))-datetime.fromisoformat(ready[reader]['ready_utc'])).total_seconds()
    assert interval>=300
    ready[reader].update(actual_resume_utc=raw[key],actual_interval_seconds=interval,
        memo_byte_sha256=hashlib.sha256((trial/reader/'pre-interrupt-note.md').read_bytes()).hexdigest())
    preserved=raw.get('preserved_files_sha256_after',raw.get('preserved_existing_files',raw.get('immutable_files_after',{})))
    for name,sha in preserved.items():
        if name.endswith(('.md','.json')):assert hashlib.sha256((trial/reader/name).read_bytes()).hexdigest()==sha,(reader,name)
(out/'pause-ledger.json').write_text(json.dumps(ledger,indent=2)+'\n',encoding='utf-8',newline='\n')

expected=AgentConfig(kind='cli',runner='codex',command=[shutil.which('codex')],model='gpt-6.1-terra',args=['-c','model_reasoning_effort="high"'])
folders=[trial/'independent-grading',trial/'guide-repair/scope-review',trial/'guide-repair/english-review']
original_index=json.loads(__import__('subprocess').check_output(['git','show','origin/main:publication/issue249/archive-index.json'],cwd=area/'public'))
translation=trial/'inherited-249/integration/build/translation-prompts'
receipts=[path for folder in folders for path in folder.rglob('*.receipt.json')]
receipts.extend(path for path in translation.rglob('*.receipt.json')
    if original_index.get(path.relative_to(trial/'inherited-249').as_posix())!=hashlib.sha256(path.read_bytes()).hexdigest())
records=[];unique=set();files={}
for path in receipts:
    key=hashlib.sha256(path.read_bytes()).hexdigest()
    if key in unique:continue
    unique.add(key)
    record=load_record(path)
    calls=path.parent.parent
    verified=verify_cli_receipt(record.request,record.raw,record.receipt,calls,expected)
    records.append(dict(path=path.relative_to(trial).as_posix(),sha256=key,model=record.receipt['model'],
        cli_call=record.receipt['cli_call'],verified=verified))
    for item in [path,record.request_path,record.response_path,calls.parent/record.receipt['provider']['stdout_path']]:
        files[item.relative_to(trial).as_posix()]=item
assert len(records)==13,len(records)
for folder in folders:
    for path in folder.rglob('*'):
        if path.is_file() and '__pycache__' not in path.parts:files[path.relative_to(trial).as_posix()]=path
archive=out/'native-evidence.zip'
operators=['freeze_final_readers.py','final_readers_grade.py','final_readers_grade-v1.py',
    'adjudicate_reader_S.py','adjudicate_reader_phase2.py','prepare_guide_repair.py','run_guide_repair.py',
    'restore_reader_assets.py','repair_guide_scope.py','review_repaired_english.py','export_repaired_guide.py',
    'make_overview_browser.py','package_final_readers.py']
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as zipped:
    for name,path in sorted(files.items()):zipped.writestr(name,path.read_bytes())
    for name in operators:zipped.writestr('operators/'+name,(area/name).read_bytes())
    for name in ['check-overview.cjs','check-overview-v1.cjs']:
        zipped.writestr('operators/'+name,(trial/name).read_bytes())
    for name in ['prepare-guide-repair.log','run-guide-repair.log','restore-reader-assets.log','translation-repaired-guide.log',
                 'translation-guide-v2.log','english-guide-review.log','english-guide-review-v2.log','export-repaired-guide.log']:
        zipped.writestr('operators/logs/'+name,(trial/name).read_bytes())
verification=dict(schema=1,source_kind='agent',unique_new_native_calls=len(records),
    runner='codex',model='gpt-6.1-terra',args=['-c','model_reasoning_effort="high"'],
    calls=records,archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
    contract_new_calls=0,contract_revalidated_units=90,inherited_unresolved=8,
    human_approval='unchanged',actual_human_participants=0)
(out/'native-verification.json').write_text(json.dumps(verification,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
summary=dict(schema=1,source_kind='agent',fresh_reader_agents=3,base_aligned=5,base_assigned=6,
    self_explanation_aligned=2,self_explanation_assigned=3,resumption_aligned=2,resumption_assigned=3,
    transfer_aligned=3,transfer_assigned=3,first_S_aligned=1,first_R_aligned=0,first_X_aligned=0,
    verdict_basis='Original fixed minimum; raw answers and first native verdicts retained alongside explicit adjudications.',
    actual_human_participants=0,human_approval='unchanged',overall_goal_completion='not-established')
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8',newline='\n')
attributes=area/'automatic-results-release/.gitattributes'
text=attributes.read_text(encoding='utf-8');rule='docs/libcamera/records/issue-248/final-automatic/** -text -whitespace'
if rule not in text:attributes.write_text(text+'\n# Preserve measured agent records and native provenance bytes.\n'+rule+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(packet=str(out),new_native_calls=len(records),archive_bytes=archive.stat().st_size)))
