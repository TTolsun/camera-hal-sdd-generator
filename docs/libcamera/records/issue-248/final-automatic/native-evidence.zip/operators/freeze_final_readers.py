import hashlib
import json
import shutil
import subprocess
import tarfile
from datetime import datetime, timezone
from pathlib import Path
from sdd.site_build import verify_site
area=Path(__file__).resolve().parent/'final-readers'
repo=area.parent/'public'
live=(area/'live-manifest-before.json').read_bytes()
expected=json.loads(live)
commits=subprocess.check_output(['git','rev-list','-n','12','origin/main','--','docs/site-manifest.json'],cwd=repo,text=True).split()
selected=None
for commit in commits:
    raw=subprocess.check_output(['git','show',commit+':docs/site-manifest.json'],cwd=repo)
    if raw==live:selected=commit;break
assert selected,'No exact public commit matches the captured live manifest.'
site=area/'site';site.mkdir(exist_ok=False)
archive=area/'frozen-docs.tar'
with archive.open('wb') as out:subprocess.run(['git','archive','--format=tar',selected,'docs'],cwd=repo,stdout=out,check=True)
with tarfile.open(archive) as source:
    for member in source:
        if member.isdir():continue
        assert member.isfile(),member.name
        parts=Path(member.name).parts
        assert parts[0]=='docs' and '..' not in parts
        target=site.joinpath(*parts[1:]);target.parent.mkdir(parents=True,exist_ok=True)
        with source.extractfile(member) as stream:target.write_bytes(stream.read())
assert (site/'site-manifest.json').read_bytes()==live
quality=verify_site(site)
old=area.parent/'release/publication/issue248/study-candidate'
inputs=area/'participant-inputs';inputs.mkdir()
for name in ['P01-tasks.md','P02-tasks.md','P03-tasks.md','participant.md']:
    shutil.copyfile(old/name,inputs/name)
protocol=dict(schema=1,source_kind='agent',frozen_at=datetime.now(timezone.utc).isoformat(),
    public_commit=selected,build_id=expected['build_id'],manifest_sha256=hashlib.sha256(live).hexdigest(),
    input_artifacts={name:hashlib.sha256((inputs/name).read_bytes()).hexdigest() for name in ['P01-tasks.md','P02-tasks.md','P03-tasks.md','participant.md']},
    base_tasks=['index','overview','vendor_overview','vendor_assurance','vendor_integration','queue_request'],
    task_success_rubric='Original issue163 rubric plus issue248 S/R/X essential meanings, unchanged; not shown to reader agents.',
    rubric_sha256={name:hashlib.sha256((old/name).read_bytes()).hexdigest() for name in ['rubric-163.md','facilitator.md']},
    evaluation='Fresh role agents; each two assigned base tasks, no-reference own-word explanation, a measured 300-second interval before resumption, separate transfer task.',
    experience='Agent estimates with literal reasons; not human subjective data.',
    pause_limit='An elapsed interval does not cause model forgetting; retained context and prior model knowledge remain limitations. No human five-minute resumption claim.',
    human_participants=0,human_approval='unchanged',issue_completion='not-decided',quality=quality)
(area/'protocol.json').write_text(json.dumps(protocol,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(protocol,ensure_ascii=False),flush=True)
