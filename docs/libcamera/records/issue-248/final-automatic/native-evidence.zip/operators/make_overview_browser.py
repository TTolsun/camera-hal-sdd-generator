import json
from pathlib import Path
area=Path(__file__).resolve().parent/'final-readers'
binding=json.loads((area/'guide-repair/binding.json').read_text(encoding='utf-8'))
catalog=json.loads((area/'inherited-249/integration/english.json').read_text(encoding='utf-8'))
(area/'guide-repair/labels.json').write_text(json.dumps({'ko':binding['reader_label'],'en':catalog['strings'][binding['reader_label']]},ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
script=(area.parent/'browser.cjs').read_text(encoding='utf-8')
script=script.replace('scenarios/queue_request.html','overview.html')
script=script.replace("assert(text.includes('queueRequest'));",
    "const labels=JSON.parse(await fs.readFile(path.resolve('build/issue248/final-readers/guide-repair/labels.json'),'utf8')); assert(text.includes(labels[lang]));")
script=script.replace("assert((await page.locator('main').innerText()).includes('ConnectionTypeQueued'));",
    "const whole=await page.locator('main').innerText(); assert(whole.includes('CameraManager')); assert(whole.includes('Request::reuse'));")
(area/'check-overview.cjs').write_text(script,encoding='utf-8',newline='\n')
print(catalog['strings'][binding['reader_label']])
