"""Relocate published #249 inputs; repair only an observed authoring label."""
import copy
import hashlib
import json
import re
import shutil
import subprocess
import tarfile
from pathlib import Path
import yaml
from sdd.config import load
from sdd.trial_workspace import write_snapshot

area=Path(__file__).resolve().parent
trial=area/'final-readers'
repo=area/'public'
archive=trial/'issue249-inputs.tar.xz'
package=json.loads(subprocess.check_output(['git','show','origin/main:publication/issue249/package.json'],cwd=repo))
assert hashlib.sha256(archive.read_bytes()).hexdigest()==package['archive_sha256']
index=json.loads(subprocess.check_output(['git','show','origin/main:publication/issue249/archive-index.json'],cwd=repo))
base=trial/'inherited-249';base.mkdir(exist_ok=False)
with tarfile.open(archive) as source:
    for member in source:
        assert member.isfile() and '..' not in Path(member.name).parts and not Path(member.name).is_absolute()
        raw=source.extractfile(member).read()
        assert hashlib.sha256(raw).hexdigest()==index[member.name],member.name
        target=base/member.name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)

out=trial/'guide-repair';out.mkdir()
original=json.loads((trial/'protocol.json').read_text(encoding='utf-8'))
source='C:\\Users\\baboe\\.codex\\worktrees\\304e\\camera-hal-sdd-generator\\build\\issue249'
def relocate(value):
    if isinstance(value,str):return value.replace(source,str(base))
    if isinstance(value,list):return [relocate(item) for item in value]
    if isinstance(value,dict):return {key:relocate(item) for key,item in value.items()}
    return value

# Native requests, receipts and stdout remain untouched. Only effective config
# snapshots are relocated, with their original bytes preserved alongside them.
for path in (base/'integration').glob('*.yaml'):
    raw=path.read_bytes();data=yaml.safe_load(raw)
    if not isinstance(data,dict):continue
    target=relocate(data)
    if target!=data:
        path.with_suffix('.original.yaml').write_bytes(raw)
        path.write_text(yaml.safe_dump(target,allow_unicode=True,sort_keys=False),encoding='utf-8',newline='\n')

raw=yaml.safe_load(subprocess.check_output(['git','show','origin/main:publication/issue249/publication.yaml'],cwd=repo))
raw=relocate(raw)
raw['source']['root']=str(area/'render/source-unused') if False else 'C:/Users/baboe/.codex/worktrees/cb18/camera-hal-sdd-generator/build/libcamera-source-issue211'
raw['source']['compile_commands']='C:/Users/baboe/.codex/worktrees/b199/camera-hal-sdd-generator/build/issue214/fixture/base/latest293/compile_commands.json'
cfg_path=base/'integration/publication-repair.yaml'
cfg_path.write_text(yaml.safe_dump(raw,allow_unicode=True,sort_keys=False),encoding='utf-8',newline='\n')
cfg=load(cfg_path)
manifest=json.loads((trial/'site/site-manifest.json').read_text(encoding='utf-8'))
for name,sha in manifest['outputs'].items():
    if name.endswith('.md'):assert hashlib.sha256((cfg.sdd_dir/name).read_bytes()).hexdigest()==sha,name

# The source HTML is read only; changes go through the generator configuration.
html=(trial/'site/overview.html').read_text(encoding='utf-8')
questions=[q for note in re.findall(r'<ul class="coverage-links">(.*?)</ul>',html,re.S)
           for q in re.findall(r'<li><p>(.*?)</p>',note,re.S)]
selected=[q for q in questions if 'behavior' in q and 'Camera::start()' in q]
assert len(selected)==1
question=selected[0];digest=hashlib.sha256(question.encode()).hexdigest()
label='Camera::start()의 허용 상태·오류 반환과 시작 타이밍 문서화의 한계는 무엇입니까?'
cfg.raw['site'].setdefault('coverage_question_edits',{}).setdefault('overview.md',{})[digest]={'label':label}
cfg.raw['publication']['operation_id']='issue248-fresh-agent-overview-guide'
cfg.raw['publication']['baseline_config']=str(base/'integration/sdd.yaml')
cfg.paths['consistency_review_config']=base/'integration/independent-review.yaml'
cfg.paths['translation_profile']=base/'integration/translation-repair.yaml'
translation=copy.deepcopy(cfg)
translation.agent.command=[shutil.which('codex')]
assert translation.agent.runner=='codex' and translation.agent.model=='gpt-6.1-terra'
assert translation.agent.args==['-c','model_reasoning_effort="high"']
write_snapshot(translation,base/'integration/translation-repair.yaml')
write_snapshot(cfg,cfg_path)

example=area/'automatic-results-release/examples/libcamera/sdd.yaml'
text=example.read_text(encoding='utf-8')
start=text.index('  coverage_question_edits:\n');end=text.index('  overview_visual:',start)
mapping=yaml.safe_load(text)['site']['coverage_question_edits']
mapping.setdefault('overview.md',{})[digest]={'label':label}
block=yaml.safe_dump(dict(coverage_question_edits=mapping),allow_unicode=True,sort_keys=False)
example.write_text(text[:start]+''.join('  '+line+'\n' for line in block.splitlines())+text[end:],encoding='utf-8',newline='\n')
record=dict(schema=1,observed_by='fresh reader-new phase1 B1 naturalness estimate',
    frozen_before_build=original['build_id'],source_question_html=question,source_sha256=digest,
    reader_label=label,configuration=str(cfg_path),
    inherited_archive_sha256=package['archive_sha256'],inherited_native_files=len(index),
    original_manuscripts_preserved=True,human_approval='unchanged',source_kind='agent')
(out/'binding.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(record,ensure_ascii=False),flush=True)
