import json
import shutil
from pathlib import Path
import yaml
from sdd.config import load
from sdd.localization_cli import prepare_catalog
area=Path(__file__).resolve().parent/'final-readers';out=area/'guide-repair'
shutil.copytree(out/'english-review',out/'english-review-v1')
shutil.copytree(out/'scope-review',out/'scope-review-v1')
binding=json.loads((out/'binding.json').read_text(encoding='utf-8'))
(out/'binding-v1.json').write_bytes((out/'binding.json').read_bytes())
label='Camera::start()는 어떤 상태에서 호출할 수 있고, 상태 검사 실패 시 무엇을 반환합니까? 시작 타이밍 문서에는 어떤 TODO가 남아 있습니까?'
binding['reader_label']=label
binding['revision_reason']='Independent English review found modifier-scope ambiguity; separate state/return and timing-documentation questions. Preserve first rejected translation.'
(out/'binding.json').write_text(json.dumps(binding,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
for path in [area/'inherited-249/integration/publication-repair.yaml',
             area.parent/'automatic-results-release/examples/libcamera/sdd.yaml']:
    raw=yaml.safe_load(path.read_text(encoding='utf-8'))
    raw['site']['coverage_question_edits']['overview.md'][binding['source_sha256']]={'label':label}
    if path.name=='sdd.yaml':
        text=path.read_text(encoding='utf-8');start=text.index('  coverage_question_edits:\n');end=text.index('  overview_visual:',start)
        block=yaml.safe_dump(dict(coverage_question_edits=raw['site']['coverage_question_edits']),allow_unicode=True,sort_keys=False)
        path.write_text(text[:start]+''.join('  '+line+'\n' for line in block.splitlines())+text[end:],encoding='utf-8',newline='\n')
    else:path.write_text(yaml.safe_dump(raw,allow_unicode=True,sort_keys=False),encoding='utf-8',newline='\n')
cfg=load(area/'inherited-249/integration/publication-repair.yaml')
catalog=Path(cfg.site.english_catalog)
shutil.copyfile(catalog,out/'english-v1-rejected.json')
report=prepare_catalog(cfg,catalog,translate=True)
(out/'translation-v2.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n')
assert report['missing_translations']==0,report
print(json.dumps(report),flush=True)
