---
generated_at: 2026-10-29T19:18:41+00:00
source_commit: 212c689fcf2450bbfbaab25c7472895ac277b5d6
status: ok
section: scenarios
entry: CameraManager::start()
scenario_id: manager_start
scenario_fingerprint: f25548f4d6797a2cb115d519065f3f3f4db6ca2b4085cb81090e3c15ab0c3f6b
generation_method: extracted-scenario
---

# 카메라 탐색 (CameraManager::start)

**`CameraManager::start()` 의 주요 호출과 추적 경계를 확인한 뒤 필요한 상세 기록을 펼쳐 보세요.**

| 지금 확인할 내용 | 이동할 절 |
|---|---|
| `CameraManager::start()`에서 시작한 정적 탐색으로 호출 기록 33개를 수집했습니다. | [이 흐름에서 확인할 것](#이-흐름에서-확인할-것) |
| 아래 항목은 추출한 호출에서 고른 코드 탐색 지점입니다. | [주요 확인 지점](#주요-확인-지점) |
| 화살표는 호출 측과 대상을 연결합니다. | [주요 호출 관계](#주요-호출-관계) |
| facts에 기록된 호출은 33개이며, 요약의 hide 규칙에 해당하는 호출은 17개입니다. | [추적 범위와 경계](#추적-범위와-경계) |
| 아래 구간을 펼치면 요약에서 제외된 호출까지 확인할 수 있습니다. | [전체 추적 기록](#전체-추적-기록) |

## 이 흐름에서 확인할 것

`CameraManager::start()`에서 시작한 정적 탐색으로 호출 기록 33개를 수집했습니다. 주요 확인 지점 1개를 아래 표와 관계도에 표시합니다. 선택한 지점의 근거를 먼저 확인하고, 필요한 호출은 전체 추적 기록에서 찾아보세요.

가상 호출 후보·예약 대상 등 확인이 필요한 경계 기록이 2개 있습니다. 추적 범위와 경계 표에서 후보를 구분한 뒤 실제 객체와 연결 방식을 확인해야 합니다.

## 주요 확인 지점

아래 항목은 추출한 호출에서 고른 코드 탐색 지점입니다. 나열 순서는 실행 순서가 아닙니다.

| 확인할 내용 | 호출 측과 대상 | 구분 | 근거 |
|---|---|---|---|
| 관리자 시작 | `CameraManager` → `Private::start()` | 정적 호출 지점입니다. | `src/libcamera/camera_manager.cpp:342` |

## 주요 호출 관계

화살표는 호출 측과 대상을 연결합니다. 시간 순서나 모든 경로의 실행을 뜻하지 않습니다. 점선에는 가상 호출 후보·예약 대상 등 확인이 필요한 관계를 표시합니다.

```mermaid
flowchart LR
  p0["CameraManager"]
  p1["Private"]
  p0 -->|"start()"| p1
```

## 추적 범위와 경계

facts에 기록된 호출은 33개이며, 요약의 hide 규칙에 해당하는 호출은 17개입니다. 전체 추적 기록에는 해당 호출도 모두 보존합니다. 기록 번호는 정적 탐색의 식별자이며 실행 순번이 아닙니다.

조건 분기, 반복 횟수와 실제 실행 스레드는 이 호출 목록만으로 확정할 수 없습니다. 가상 호출 후보는 실제 객체에 따라 선택됩니다. 예약 표시는 인자로 전달한 메서드 대상을 뜻하며, 비동기 실행을 보증하지 않습니다. 호출부의 연결 방식과 동기화 계약을 확인해야 합니다.

| 호출 지점 | 후보 또는 예약 대상 | 확인할 경계 | 근거 |
|---|---|---|---|
| `Thread` | `Thread::startThread()` | 메서드 전달 대상이며 동기·비동기 여부는 호출부에서 확인해야 합니다. | `src/libcamera/base/thread.cpp:264` |
| `Thread` | `EventDispatcherPoll::interrupt()` | 동적 디스패치 후보이며 실제 대상은 확인이 필요합니다. | `src/libcamera/base/thread.cpp:386` |

추출 통계: 미해결 호출 0개, 예약된 호출 1개입니다.

## 전체 추적 기록

아래 구간을 펼치면 요약에서 제외된 호출까지 확인할 수 있습니다. 이 목록은 추출 깊이 안에서 수집한 기록이며, 소스의 모든 실행 경로를 포함한다는 뜻은 아닙니다.

??? note "추적 기록 1–25 / 33개"

    | 기록 | 호출 측 | 대상 | 구분 | 근거 |
    |---|---|---|---|---|
    | 1 | `CameraManager` | `log::isLogSeverityEnabled()` | 정적 호출 지점입니다. | `src/libcamera/camera_manager.cpp:340` |
    | 2 | `CameraManager` | `LogMessageAbortGuard::LogMessageAbortGuard()` | 정적 호출 지점입니다. | `src/libcamera/camera_manager.cpp:340` |
    | 3 | `CameraManager` | `LogMessage::stream()` | 정적 호출 지점입니다. | `src/libcamera/camera_manager.cpp:340` |
    | 4 | `CameraManager` | `log::_log()` | 정적 호출 지점입니다. | `src/libcamera/camera_manager.cpp:340` |
    | 5 | `log` | `LogMessage::LogMessage()` | 정적 호출 지점입니다. | `src/libcamera/base/log.cpp:990` |
    | 6 | `LogMessage` | `utils::basename()` | 정적 호출 지점입니다. | `src/libcamera/base/log.cpp:858` |
    | 7 | `CameraManager` | `Private::start()` | 정적 호출 지점입니다. | `src/libcamera/camera_manager.cpp:342` |
    | 8 | `Private` | `Thread::start()` | 정적 호출 지점입니다. | `src/libcamera/camera_manager.cpp:51` |
    | 9 | `Thread` | `MutexLocker::MutexLocker()` | 정적 호출 지점입니다. | `src/libcamera/base/thread.cpp:255` |
    | 10 | `Thread` | `Thread::startThread()` | 메서드 전달 대상이며 동기·비동기 여부는 호출부에서 확인해야 합니다. | `src/libcamera/base/thread.cpp:264` |
    | 11 | `Thread` | `Thread::setThreadAffinityInternal()` | 정적 호출 지점입니다. | `src/libcamera/base/thread.cpp:266` |
    | 12 | `Private` | `MutexLocker::MutexLocker()` | 정적 호출 지점입니다. | `src/libcamera/camera_manager.cpp:54` |
    | 13 | `Private` | `ConditionVariable::wait()` | 정적 호출 지점입니다. | `src/libcamera/camera_manager.cpp:55` |
    | 14 | `Private` | `Thread::exit()` | 정적 호출 지점입니다. | `src/libcamera/camera_manager.cpp:63` |
    | 15 | `Thread` | `EventDispatcherPoll::interrupt()` | 동적 디스패치 후보이며 실제 대상은 확인이 필요합니다. | `src/libcamera/base/thread.cpp:386` |
    | 16 | `EventDispatcherPoll` | `UniqueFD::get()` | 정적 호출 지점입니다. | `src/libcamera/base/event_dispatcher_poll.cpp:177` |
    | 17 | `EventDispatcherPoll` | `log::isLogSeverityEnabled()` | 정적 호출 지점입니다. | `src/libcamera/base/event_dispatcher_poll.cpp:181` |
    | 18 | `EventDispatcherPoll` | `LogMessageAbortGuard::LogMessageAbortGuard()` | 정적 호출 지점입니다. | `src/libcamera/base/event_dispatcher_poll.cpp:181` |
    | 19 | `EventDispatcherPoll` | `LogMessage::stream()` | 정적 호출 지점입니다. | `src/libcamera/base/event_dispatcher_poll.cpp:181` |
    | 20 | `EventDispatcherPoll` | `log::_log()` | 정적 호출 지점입니다. | `src/libcamera/base/event_dispatcher_poll.cpp:181` |
    | 21 | `Private` | `Thread::wait()` | 정적 호출 지점입니다. | `src/libcamera/camera_manager.cpp:64` |
    | 22 | `Thread` | `MutexLocker::MutexLocker()` | 정적 호출 지점입니다. | `src/libcamera/base/thread.cpp:407` |
    | 23 | `Thread` | `ConditionVariable::wait()` | 정적 호출 지점입니다. | `src/libcamera/base/thread.cpp:414` |
    | 24 | `Thread` | `(lambda at src/libcamera/base/thread.cpp:409:21)::(lambda at src/libcamera/base/thread.cpp:409:21)()` | 정적 호출 지점입니다. | `src/libcamera/base/thread.cpp:414` |
    | 25 | `Thread` | `ConditionVariable::wait_for()` | 정적 호출 지점입니다. | `src/libcamera/base/thread.cpp:416` |

??? note "추적 기록 26–33 / 33개"

    | 기록 | 호출 측 | 대상 | 구분 | 근거 |
    |---|---|---|---|---|
    | 26 | `Thread` | `(lambda at src/libcamera/base/thread.cpp:409:21)::(lambda at src/libcamera/base/thread.cpp:409:21)()` | 정적 호출 지점입니다. | `src/libcamera/base/thread.cpp:417` |
    | 27 | `CameraManager` | `CameraManager::_d()` | 정적 호출 지점입니다. | `src/libcamera/camera_manager.cpp:342` |
    | 28 | `CameraManager` | `log::isLogSeverityEnabled()` | 정적 호출 지점입니다. | `src/libcamera/camera_manager.cpp:344` |
    | 29 | `CameraManager` | `LogMessageAbortGuard::LogMessageAbortGuard()` | 정적 호출 지점입니다. | `src/libcamera/camera_manager.cpp:344` |
    | 30 | `CameraManager` | `LogMessage::stream()` | 정적 호출 지점입니다. | `src/libcamera/camera_manager.cpp:344` |
    | 31 | `CameraManager` | `log::_log()` | 정적 호출 지점입니다. | `src/libcamera/camera_manager.cpp:344` |
    | 32 | `log` | `LogMessage::LogMessage()` | 정적 호출 지점입니다. | `src/libcamera/base/log.cpp:990` |
    | 33 | `LogMessage` | `utils::basename()` | 정적 호출 지점입니다. | `src/libcamera/base/log.cpp:858` |

??? note "근거와 검토 정보"
    - 생성 방식: 추출 호출로 만든 시나리오
    - 검증 범위: 주요 호출과 경계를 facts에서 구성하고 전체 추적 기록을 보존합니다. 실행 순서를 추정하지 않습니다.
    - 근거 파일: `src/libcamera/base/event_dispatcher_poll.cpp`, `src/libcamera/base/log.cpp`, `src/libcamera/base/thread.cpp`, `src/libcamera/camera_manager.cpp`
    - 근거 수준: 코드 확인 (정적 분석, simple_compdb 구성, commit `212c689fcf`)
    - 자동 검사 (인용·문장 및 설정된 구조 검사): 통과
    - 검토 상태 기록일: 2026-10-30 · 사람 검토 전

다음 단계: [스트림 구성 (Camera::configure)](configure.md)
