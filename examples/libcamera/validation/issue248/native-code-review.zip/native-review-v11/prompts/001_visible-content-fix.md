<!-- system -->
Review the fix to the prior finding: a configured removal must not leave a reader question with only markup. The design explicitly binds complete original question HTML hashes to reviewed removal sentences; default does no removal, code/markup/quotes are protected, stale/ambiguous bindings fail, original manuscripts remain intact. Other modules were reviewed in prior iterations and are unchanged. Verify this specific fix and new regressions only. Do not claim human approval. Return JSON verdict pass/revise and findings.

<!-- user -->
def compact_tables(document: str, *, question_edits=None) -> str:
    """Only recognized coverage blocks and one-row call tables change form."""
    intro = '질문별 답변과 근거 연결을 검사했습니다. 의미와 실행 결과는 사람 검토가 필요합니다.'
    common = '코드 근거와 설명 연결'

    # Project-specific, reviewed removals bind the COMPLETE original question.
    # There is no default phrase classifier: the same sentence may be a real
    # requirement in another question. Historical manuscripts remain intact.
    specifications = question_edits if question_edits is not None else {}
    if not isinstance(specifications, dict) or any(
            not re.fullmatch(r'[0-9a-f]{64}', key) or not isinstance(values, list) or not values
            or any(not isinstance(value, str) or not value.strip() for value in values)
            or len(values) != len(set(values)) for key, values in specifications.items()):
        raise ValueError('Question edits require complete-question SHA-256 keys and unique nonempty sentences.')
    seen = set()

    def reader_question(question):
        key = hashlib.sha256(question.encode('utf-8')).hexdigest()
        if key not in specifications:
            return question
        if key in seen:
            raise ValueError('Configured question edit matches more than one requirement.')
        seen.add(key)
        editorial_directions = specifications[key]
        if any(question.count(direction) != 1 for direction in editorial_directions):
            raise ValueError('Configured editorial sentence is missing or ambiguous.')
        # Match whole plain sentences only; code and linked text stay intact.
        offsets, total = [], 0
        for line in question.splitlines(keepends=True):
            offsets.append(total)
            total += len(line)
        edits = []
        visible = []

        class Text(HTMLParser):
            void = {'area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'meta', 'param', 'source', 'track', 'wbr'}

            def __init__(self):
                super().__init__(convert_charrefs=False)
                self.stack = []
                self.invisible = set()

            def handle_starttag(self, tag, attrs):
                if tag not in self.void:
                    self.stack.append(tag)
                    attributes = dict(attrs)
                    if (tag in ('script', 'style', 'template', 'noscript', 'head', 'title') or 'hidden' in attributes
                            or re.search(r'(?:display\s*:\s*none|visibility\s*:\s*hidden)', attributes.get('style') or '', re.I)):
                        self.invisible.add(len(self.stack))

            def handle_endtag(self, tag):
                if tag not in self.void and tag in self.stack:
                    index = len(self.stack) - 1 - self.stack[::-1].index(tag)
                    del self.stack[index:]
                    self.invisible = {depth for depth in self.invisible if depth <= index}

            def handle_entityref(self, name):
                if not self.invisible:
                    visible.append(html.unescape('&' + name + ';'))

            def handle_charref(self, name):
                if not self.invisible:
                    visible.append(html.unescape('&#' + name + ';'))

            def handle_data(self, data):
                # Quoted text can itself be a requirement or example. Prefer
                # retaining a direction over deleting any quoted content.
                if self.stack or any(mark in data for mark in ('"', "'", '“', '”', '‘', '’', '«', '»')):
                    if not self.invisible:
                        visible.append(data)
                    return
                updated = data
                for direction in editorial_directions:
                    updated = re.sub(r'(^\s*|(?<=[.!?])\s+)' + re.escape(direction) + r'(?=\s|$)',
                                     lambda match: match[1], updated)
                visible.append(updated)
                if updated != data:
                    line, column = self.getpos()
                    edits.append((offsets[line - 1] + column, len(data), updated))

        Text().feed(question)
        for start, length, updated in reversed(edits):
            question = question[:start] + updated + question[start + length:]
        if any(direction in question for direction in editorial_directions) or not ''.join(visible).strip():
            raise ValueError('Configured edit would change protected content or empty a question.')
        return question.strip()

    def coverage(match):
        prefix, table, suffix = match.groups()
        if not simple_table(table) or re.search(r'\bid=', table):
            return match[0]
        if cells(table, 'th') != ('설계 질문', '설명 위치', '확인 범위'):
            return match[0]
        # Validate the whole table before applying/acknowledging any edit.
        # A later custom row must not roll back an earlier configured edit
        # while leaving its fingerprint marked as successfully applied.
        rows = [cells(row) for row in re.findall(r'<tr>(.*?)</tr>', table, re.S)]
        if any(len(row) != 3 or row[2] not in (common, common + ' · 실행 확인 항목 별도')
               for row in rows if row):
            return match[0]
        items = []
        for row in re.findall(r'<tr>(.*?)</tr>', table, re.S):
            values = cells(row)
            if not values:
                continue
            if len(values) != 3 or values[2] not in (common, common + ' · 실행 확인 항목 별도'):
                return match[0]
            question, links, scope = values
            question = reader_question(question)
            if not question:
                # No reader-facing question remains; retain the original rather
                # than silently dropping a requirement or inventing a label.
                return match[0]
            qualifier = '<p>실행 확인 항목 별도</p>' if scope != common else ''
            items.append('<li><p>' + question + '</p><p>' + links + '</p>' + qualifier + '</li>')
        if not items or re.search(r'\bid=', table):
            return match[0]
        return (prefix + '<ul class="coverage-links">' + ''.join(items) + '</ul>'
                + '<p><span>확인 범위</span>: <span>' + common + '</span></p>' + suffix)

    # Full generated context keeps unrelated/custom tables untouched.
    coverage_pattern = (r'(<details class="note">\s*<summary>설계 질문과 검증 범위</summary>\s*<p>'
                        + re.escape(intro) + r'</p>\s*)(<table>.*?</table>)(\s*</details>)')
    headers = {('확인할 내용', '호출 측과 대상', '구분', '근거'),
               ('호출 지점', '후보 또는 예약 대상', '확인할 경계', '근거')}
    converted = set()

    def single_call(match):
        table = match[0]
        if not simple_table(table):
            return table
        labels = cells(table, 'th')
        rows = [cells(row) for row in re.findall(r'<tr>(.*?)</tr>', table, re.S)]
        rows = [row for row in rows if row]
        if labels not in headers or len(rows) != 1 or len(rows[0]) != len(labels) or re.search(r'\bid=', table):
            return table
        converted.add(labels[0])
        return '<dl class="call-checkpoint">' + ''.join('<dt>' + key + '</dt><dd>' + value + '</dd>'
                                                       for key, value in zip(labels, rows[0])) + '</dl>'

    chunks = re.split(r'(<pre\b[^>]*>.*?</pre>)', document, flags=re.S)
    chunks = [chunk if i % 2 else re.sub(r'<table>.*?</table>', single_call,
                                        re.sub(coverage_pattern, coverage, chunk, flags=re.S), flags=re.S)
              for i, chunk in enumerate(chunks)]
    for i in range(0, len(chunks), 2):
        if '확인할 내용' in converted:
            chunks[i] = chunks[i].replace('주요 확인 지점 1개를 아래 표와 관계도에 표시합니다.',
                                          '주요 확인 지점 1개를 아래 목록과 관계도에 표시합니다.')
        if '호출 지점' in converted:
            chunks[i] = chunks[i].replace('추적 범위와 경계 표에서 후보를 구분한 뒤',
                                          '추적 범위와 경계 항목에서 후보를 구분한 뒤')
    if set(specifications) != seen:
        raise ValueError('Configured question changed or is absent; review the complete question again.')
    return ''.join(chunks)


