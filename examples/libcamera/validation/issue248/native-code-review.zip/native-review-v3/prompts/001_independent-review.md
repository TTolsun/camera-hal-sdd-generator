<!-- system -->
You are an independent code and evaluation-protocol reviewer. Review only supplied files. Review newly added/modified behavior only, not preexisting transformations. Report actionable defects, not speculative improvements. Focus: no agent can count as a human, missing/failed assignments remain denominator, frozen build and protocol, 3 humans/6 base tasks/5 unassisted successes/ease median>=4, all explain and resume, experience separate, no clinical claim. Reading cleanup removes only four exact editorial sentences inside recognized generated coverage guides; must preserve technical obligations, code, citations, scope, unrelated content and old manuscripts. New tasks were fixed before observations. Do not infer a human result or approve technical prose. Return JSON verdict pass or revise, findings with file and explanation, limitations.

<!-- user -->
FILE src/sdd/reader_study.py
"""Summarize recorded reader studies; never infer human responses from agents.

python -m sdd.reader_study --protocol protocol.json --results human-results.csv
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import statistics
from pathlib import Path


def validate_protocol(protocol: dict, artifact_hashes: dict) -> None:
    participants = protocol['participants']
    ids = [p['id'] for p in participants]
    base = protocol['base_tasks']
    if (len(ids) < 3 or len(set(ids)) != len(ids) or len(base) < 6 or len(set(base)) != len(base)
            or not {'new_developer', 'other_team'} <= {p['perspective'] for p in participants}
            or protocol['minimum_base_successes'] != 5 or protocol['minimum_ease_median'] != 4
            or protocol['task_timeout_seconds'] != 600 or protocol['interruption_seconds'] != 300):
        raise ValueError('Protocol changes the fixed participant, task or acceptance criteria.')
    assigned = []
    for participant in participants:
        tasks = participant['tasks']
        if (len(tasks) != len(set(tasks)) or not {'S', 'R', 'X'} <= set(tasks)
                or len(set(tasks) & set(base)) != 2 or set(tasks) - set(base) - {'S', 'R', 'X'}):
            raise ValueError('Every participant needs two base tasks plus S, R and X.')
        assigned.extend(task for task in tasks if task in base)
    if set(assigned) != set(base) or len(assigned) != len(base):
        raise ValueError('Every declared base assignment must occur exactly once.')
    artifacts = protocol['artifacts']
    if not {'instructions', 'participant', 'rubric', 'baseline', 'legacy_rubric'} <= set(artifacts):
        raise ValueError('Protocol must bind instructions, participant packet, rubrics and baseline.')
    if any(artifact_hashes.get(key) != entry['sha256'] for key, entry in artifacts.items()):
        raise ValueError('Frozen instructions, rubric or baseline changed; do not mix observations.')


def summarize(protocol: dict, rows: list[dict], *, protocol_sha256: str, artifact_hashes: dict) -> dict:
    """Check provenance/completeness before aggregating manual task judgments.

    `correct` is an assessor's judgment, not a semantic classifier. Participant
    provenance remains a declaration to be checked by the study facilitator.
    """
    validate_protocol(protocol, artifact_hashes)
    expected = {(p['id'], task): p for p in protocol['participants'] for task in p['tasks']}
    seen = {}
    for row in rows:
        key = row['participant_id'], row['task_id']
        if key not in expected or key in seen:
            raise ValueError(f'Unexpected or duplicate assignment: {key}')
        if row.get('source_kind') != 'human':
            raise ValueError('Agent/synthetic records cannot enter the human study.')
        if row.get('build_id') != protocol['build_id']:
            raise ValueError(f'Mixed or missing build_id: {key}')
        if row.get('protocol_sha256') != protocol_sha256:
            raise ValueError(f'Stale or missing protocol fingerprint: {key}')
        if row.get('perspective') != expected[key]['perspective']:
            raise ValueError(f'Changed participant perspective: {key}')
        seen[key] = row

    pending, outcomes, ease, interest, naturalness = [], {}, [], [], []
    for key in expected:
        row = seen.get(key, {})
        task = key[1]
        required = ['answer', 'page_anchor', 'evidence_url', 'started_at', 'ended_at',
                    'elapsed_seconds', 'visited_urls', 'author_help', 'correct',
                    'completed_without_help', 'is_non_author', 'assessor']
        if task in protocol['base_tasks']:
            required += ['reading_ease_1_to_5', 'interest_1_to_5',
                         'naturalness_1_to_5', 'subjective_reason']
        elif task == 'S':
            required += ['explanation_without_document', 'closed_document']
        elif task == 'R':
            required += ['interruption_seconds', 'closed_document', 'resumed_from_start',
                         'pre_interrupt_note', 'resumed_state', 'next_action', 'next_branch',
                         'backtrack_urls']
        missing = [field for field in required if not str(row.get(field, '')).strip()]
        if missing:
            pending.append({'participant_id': key[0], 'task_id': task, 'missing': missing})
        # Missing assignments remain in the denominator, never counted as success.
        for field in ['author_help', 'correct', 'completed_without_help', 'is_non_author',
                      'closed_document', 'resumed_from_start', 'explanation_without_document']:
            if row.get(field, '') not in ('', 'true', 'false'):
                raise ValueError(f'Expected true/false for {field}: {key}')
        for field in ['elapsed_seconds', 'interruption_seconds']:
            if row.get(field, ''):
                try:
                    value = float(row[field])
                except ValueError as exc:
                    raise ValueError(f'Invalid {field}: {key}') from exc
                if not 0 <= value < float('inf'):
                    raise ValueError(f'Invalid {field}: {key}')
        for field, target in [('reading_ease_1_to_5', ease), ('interest_1_to_5', interest),
                              ('naturalness_1_to_5', naturalness)]:
            if row.get(field, ''):
                if row[field] not in ('1', '2', '3', '4', '5'):
                    raise ValueError(f'Invalid {field}: {key}')
                if task in protocol['base_tasks']:
                    target.append(int(row[field]))
        success = (not missing and row['is_non_author'] == 'true' and row['correct'] == 'true'
                   and row['completed_without_help'] == 'true' and row['author_help'] == 'false'
                   and float(row['elapsed_seconds']) <= protocol['task_timeout_seconds'])
        if task == 'S':
            success = success and row.get('explanation_without_document') == 'true' and row.get('closed_document') == 'true'
        if task == 'R':
            success = (success and row.get('closed_document') == 'true'
                       and row.get('resumed_from_start') == 'true'
                       and float(row.get('interruption_seconds') or 0) >= protocol['interruption_seconds'])
        outcomes[key] = bool(success)

    base = [ok for (_, task), ok in outcomes.items() if task in protocol['base_tasks']]
    core = {task: all(ok for (_, t), ok in outcomes.items() if t == task) for task in ['S', 'R']}
    median = statistics.median(ease) if ease else None
    passed = (not pending and sum(base) >= protocol['minimum_base_successes']
              and median is not None and median >= protocol['minimum_ease_median'] and all(core.values()))
    return {
        'schema': 1, 'source_kind': 'human', 'provenance': 'facilitator-declared; not independently authenticated',
        'status': 'pending' if pending else 'passed' if passed else 'needs-improvement',
        'build_id': protocol['build_id'], 'protocol_sha256': protocol_sha256,
        'assigned_base_tasks': len(base), 'unassisted_base_successes': sum(base),
        'reading_ease_median': median, 'self_explanation_all': core['S'], 'resumption_all': core['R'],
        'transfer': [{'participant_id': p, 'success': ok} for (p, t), ok in outcomes.items() if t == 'X'],
        'subjective': {'interest': interest, 'naturalness': naturalness,
                       'note': 'Separate responses; no combined accuracy/experience score.'},
        'pending': pending, 'human_approval': 'unchanged', 'issue_completion': 'not-decided',
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--protocol', type=Path, required=True)
    parser.add_argument('--results', type=Path, required=True)
    args = parser.parse_args()
    try:
        raw = args.protocol.read_bytes()
        protocol = json.loads(raw)
        hashes = {key: hashlib.sha256((args.protocol.parent / entry['path']).read_bytes()).hexdigest()
                  for key, entry in protocol['artifacts'].items()}
        with args.results.open(encoding='utf-8-sig', newline='') as source:
            result = summarize(protocol, list(csv.DictReader(source)),
                               protocol_sha256=hashlib.sha256(raw).hexdigest(), artifact_hashes=hashes)
    except (ValueError, KeyError) as exc:
        parser.error(str(exc))
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result['status'] == 'passed' else 1


if __name__ == '__main__':
    raise SystemExit(main())


FILE tests/test_reader_study.py
import copy

import pytest

from sdd.reader_study import summarize


@pytest.fixture
def study():
    protocol = dict(build_id='frozen', base_tasks=['a0', 'b0', 'a1', 'b1', 'a2', 'b2'],
                    participants=[dict(id=f'P{i}', perspective=role, tasks=[f'a{i}', f'b{i}', 'S', 'R', 'X'])
                                  for i, role in enumerate(['new_developer', 'other_team', 'non_author'])],
                    minimum_base_successes=5, minimum_ease_median=4,
                    task_timeout_seconds=600, interruption_seconds=300,
                    artifacts={key: dict(path=key, sha256='frozen-artifact') for key in
                               ['instructions', 'participant', 'rubric', 'baseline', 'legacy_rubric']})
    rows = []
    for participant in protocol['participants']:
        for task in participant['tasks']:
            rows.append(dict(participant_id=participant['id'], perspective=participant['perspective'], task_id=task,
                             build_id='frozen', protocol_sha256='hash', source_kind='human',
                             answer='Recorded answer', page_anchor='page#answer', evidence_url='page#evidence',
                             started_at='observed start', ended_at='observed end', elapsed_seconds='50',
                             visited_urls='page', backtrack_urls='none', author_help='false', correct='true',
                             completed_without_help='true', is_non_author='true', assessor='assessor',
                             reading_ease_1_to_5='4', interest_1_to_5='2', naturalness_1_to_5='3',
                             subjective_reason='Actual comment', explanation_without_document='true',
                             closed_document='true', resumed_from_start='true', interruption_seconds='300',
                             pre_interrupt_note='note', resumed_state='state', next_action='inspect', next_branch='branch'))
    return protocol, rows


def report(study):
    return summarize(*study, protocol_sha256='hash', artifact_hashes={key: 'frozen-artifact' for key in study[0]['artifacts']})


def test_completed_study_keeps_experience_separate_and_never_closes_issue(study):
    result = report(study)
    assert result['status'] == 'passed'
    assert result['assigned_base_tasks'] == 6
    assert result['subjective']['interest'] == [2] * 6
    assert result['issue_completion'] == 'not-decided'
    assert result['human_approval'] == 'unchanged'


def test_empty_missing_and_helped_tasks_stay_in_denominator(study):
    protocol, rows = study
    empty = report((protocol, []))
    assert empty['status'] == 'pending' and empty['assigned_base_tasks'] == 6
    rows.pop(0)
    rows[0]['author_help'] = 'true'
    result = report(study)
    assert result['status'] == 'pending' and result['unassisted_base_successes'] == 4


@pytest.mark.parametrize('field,value', [('source_kind', 'agent'), ('build_id', 'other'),
                                        ('protocol_sha256', 'old'), ('perspective', 'other_team'),
                                        ('correct', 'yes'), ('elapsed_seconds', 'nan'),
                                        ('reading_ease_1_to_5', '6')])
def test_provenance_mixing_and_invalid_observations_are_rejected(study, field, value):
    study[1][0][field] = value
    with pytest.raises(ValueError):
        report(study)


def test_duplicate_or_unassigned_response_is_rejected(study):
    study[1].append(copy.deepcopy(study[1][0]))
    with pytest.raises(ValueError):
        report(study)


@pytest.mark.parametrize('task,field,value', [('S', 'closed_document', 'false'),
                                           ('R', 'interruption_seconds', '299'),
                                           ('R', 'resumed_from_start', 'false'),
                                           ('R', 'next_branch', '')])
def test_every_participant_must_explain_and_resume(study, task, field, value):
    next(row for row in study[1] if row['task_id'] == task)[field] = value
    result = report(study)
    assert result['status'] != 'passed'


def test_transfer_does_not_inflate_base_success(study):
    for row in study[1]:
        if row['task_id'].startswith('a'):
            row['correct'] = 'false'
    result = report(study)
    assert result['status'] == 'needs-improvement'
    assert result['unassisted_base_successes'] == 3


@pytest.mark.parametrize('change', ['omit-core', 'duplicate-person', 'lower-threshold', 'lose-perspective', 'omit-base'])
def test_protocol_cannot_weaken_precommitted_design(study, change):
    protocol = study[0]
    if change == 'omit-core':
        protocol['participants'][0]['tasks'].remove('S')
    elif change == 'duplicate-person':
        protocol['participants'][1]['id'] = protocol['participants'][0]['id']
    elif change == 'lower-threshold':
        protocol['minimum_base_successes'] = 1
    elif change == 'lose-perspective':
        protocol['participants'][0]['perspective'] = 'non_author'
    else:
        protocol['participants'][0]['tasks'].remove('a0')
    with pytest.raises(ValueError):
        report(study)


def test_changed_rubric_cannot_reuse_prior_result_fingerprint(study):
    with pytest.raises(ValueError, match='Frozen'):
        summarize(*study, protocol_sha256='hash', artifact_hashes={})


FILE tests/test_reading_cleanup.py
import re

import pytest

from sdd.reading_cleanup import compact_tables, class_targets, link_related_classes, merge_next_step, promote_coverage


def table(headers, rows):
    return ('<table><thead><tr>' + ''.join('<th>' + h + '</th>' for h in headers)
            + '</tr></thead><tbody>' + ''.join('<tr>' + ''.join('<td>' + c + '</td>' for c in row) + '</tr>' for row in rows)
            + '</tbody></table>')


def coverage(scope='코드 근거와 설명 연결'):
    return ('<details class="note"><summary>설계 질문과 검증 범위</summary>'
            '<p>질문별 답변과 근거 연결을 검사했습니다. 의미와 실행 결과는 사람 검토가 필요합니다.</p>'
            + table(['설계 질문', '설명 위치', '확인 범위'], [
                ['<code>Request</code>의 수명은?', '<a href="#life">수명</a>', scope],
                ['실행 검증은?', '<a href="#verify">검증</a>', '코드 근거와 설명 연결 · 실행 확인 항목 별도']]) + '</details>')


def test_coverage_list_keeps_questions_links_scope_and_human_review_boundary():
    source = coverage()
    result = compact_tables(source)
    assert '<table' not in result and '<ul class="coverage-links">' in result
    assert '<code>Request</code>의 수명은?' in result and '실행 검증은?' in result
    assert re.findall(r'href="([^"]+)"', result) == re.findall(r'href="([^"]+)"', source)
    assert result.count('코드 근거와 설명 연결') == 1
    assert '실행 확인 항목 별도' in result and '의미와 실행 결과는 사람 검토가 필요합니다.' in result
    assert compact_tables(result) == result


def test_custom_coverage_scope_and_example_html_stay_intact():
    source = coverage('사용자 정의 검증 조건')
    assert compact_tables(source) == source
    source = coverage().replace('<td>', '<td title="context">', 1)
    assert compact_tables(source) == source
    source = '<pre>' + coverage() + '</pre>'
    assert compact_tables(source) == source


def test_observed_writer_directions_are_not_reader_questions():
    technical = ('Running 상태와 -ENODEV/-EACCES를 설명하세요. '
                 '반환값 0과 requestCompleted를 구분하세요.')
    directions = ('세 문단 이내로 작성하세요. '
                  '각 문단은 한 가지 독자 과업을 설명하고, 같은 결과나 반환값을 다시 풀어 쓰지 마세요. '
                  '소스 한 줄마다 문단을 만들지 마세요. '
                  '아래 절에서 설명하는 내부 구현을 미확인 한계로 반복하지 마세요.')
    source = coverage().replace('<code>Request</code>의 수명은?', technical + ' ' + directions)
    result = compact_tables(source)
    assert technical in result
    assert '세 문단' not in result and '소스 한 줄마다' not in result
    assert re.findall(r'href="([^"]+)"', source) == re.findall(r'href="([^"]+)"', result)
    assert compact_tables(result) == result
    # Contract imperatives, code literals, custom notes and empty-only rows
    # must never be generalized into the editorial-removal rule.
    assert compact_tables(source.replace(technical + ' ' + directions, directions)) == source.replace(technical + ' ' + directions, directions)
    code = source.replace(technical + ' ' + directions, '<code>세 문단 이내로 작성하세요.</code> 호출 의무를 유지하세요.')
    assert '<code>세 문단 이내로 작성하세요.</code> 호출 의무를 유지하세요.' in compact_tables(code)
    for protected in ['<code> 세 문단 이내로 작성하세요. </code>', '<a href="#life"> 세 문단 이내로 작성하세요. </a>']:
        example = coverage().replace('<code>Request</code>의 수명은?', protected + ' 계약을 확인하세요.')
        assert protected in compact_tables(example)
    markup = '<span title=" 세 문단 이내로 작성하세요. > ">기술 조건</span>'
    assert markup in compact_tables(coverage().replace('<code>Request</code>의 수명은?', markup + ' 세 문단 이내로 작성하세요.'))


def test_question_guide_follows_lead_before_terms_with_content_and_links_intact():
    lead = '<p><strong>도입할 범위를 판단하세요.</strong></p>'
    terms = '<details class="page-terms"><summary>용어</summary><p>Camera</p></details>'
    body = '<h2 id="life">수명</h2><p>본문</p><h2 id="verify">검증</h2>'
    guide = compact_tables(coverage())
    result = promote_coverage(lead + terms + body + guide)
    assert result == lead + guide + terms + body
    assert promote_coverage(result) == result
    assert ' open' not in result


def test_question_guide_without_lead_precedes_body_but_examples_and_custom_notes_stay():
    guide = compact_tables(coverage())
    body = '<h2 id="life">수명</h2>'
    assert promote_coverage(body + guide) == guide + body
    for source in ('<pre>' + guide + '</pre>', coverage('사용자 정의 검증 조건'),
                   body + guide + guide):
        assert promote_coverage(source) == source


def test_manuscript_review_records_deduplicate_exact_values_but_keep_history():
    from sdd.reading_cleanup import collect_manuscript_records
    note = ('<details class="note"><summary>근거와 검토 정보</summary><ul>'
            '<li>생성 방식: 추출 사실과 LLM 설명</li><li>검증 범위: 과거 범위</li>'
            '<li>근거 수준: commit <code>old</code></li><li>검토 상태 기록일: 과거 날짜</li>'
            '<li><a href="record.json">기록</a></li></ul></details>')
    current = {'생성 방식': '추출 사실과 LLM 설명', '검증 범위': '현재 범위'}
    content, record = collect_manuscript_records('<p>본문</p>' + note, current)
    assert content == '<p>본문</p>'
    assert '생성 방식:' not in record
    for value in ('과거 범위', '<code>old</code>', '과거 날짜', 'href="record.json"'):
        assert value in record
    assert '원고 작성 당시 기록' in record
    assert collect_manuscript_records(content, current) == (content, '')
    assert collect_manuscript_records('<pre>' + note + '</pre>', current) == ('<pre>' + note + '</pre>', '')
    scoped = note.replace('근거와 검토 정보</summary>', '근거와 검토 정보: package</summary>')
    assert '생성 방식:' in collect_manuscript_records(scoped, current)[1]


def test_single_call_becomes_labeled_record_without_losing_boundary_or_citations():
    headers = ['호출 지점', '후보 또는 예약 대상', '확인할 경계', '근거']
    row = ['Camera', '<code>Pipe::queue()</code>', '메서드 전달이며 비동기 보장이 아닙니다.', '<a href="code#L9">src/a.cpp:9</a>']
    result = compact_tables(table(headers, [row]))
    assert '<table' not in result and '<dl class="call-checkpoint">' in result
    assert all('<dt>' + header + '</dt>' in result for header in headers)
    assert all('<dd>' + cell + '</dd>' in result for cell in row)
    source = table(headers, [row, row])
    assert compact_tables(source) == source


def test_one_row_code_index_and_anchored_table_are_not_changed():
    source = table(['클래스', '선언 위치', '상속', '책임 (주석)'], [['Camera', 'a.h:1', 'Base', 'Camera']])
    assert compact_tables(source) == source
    for tag in ('th', 'td', 'tr'):
        custom = source.replace('<' + tag + '>', '<' + tag + ' aria-label="context">', 1)
        assert compact_tables(custom) == custom
    source = table(['확인할 내용', '호출 측과 대상', '구분', '근거'], [['<a id="keep"></a>check', 'call', 'note', 'a:1']])
    assert compact_tables(source) == source


CLASS_HEADERS = ['클래스', '선언 위치', '상속', '책임 (주석)']
ROW = ['<code>Camera</code>', '<a href="https://host/blob/hash/a.h#L1"><code>a.h:1</code></a>', '<code>Base</code>', 'A camera']


def index(row=ROW, anchor='symbol-1111111111111111'):
    return table(CLASS_HEADERS, [row]).replace('<tbody><tr>', '<tbody><tr id="' + anchor + '" tabindex="-1" data-symbol-kind="class">')


def related(row=ROW):
    return ('<h2 id="관련-클래스">관련 클래스</h2>\n'
            '<div class="table-scroll stack" tabindex="0" role="region" aria-label="표">'
            + table(CLASS_HEADERS, [row]) + '</div>')


def test_reference_links_require_exact_unique_full_row_and_use_relative_destination():
    targets = class_targets({'reference/index.html': index()})
    result = link_related_classes(related(), 'guides/camera.html', targets)
    assert '<table' not in result and 'id="관련-클래스"' in result
    assert '<a href="../reference/index.html#symbol-1111111111111111"><code>Camera</code></a>' in result
    assert link_related_classes(related([*ROW[:3], 'Different responsibility']), 'camera.html', targets) == related([*ROW[:3], 'Different responsibility'])
    assert link_related_classes(related(), 'camera.html', class_targets({'a.html': index(), 'b.html': index()})) == related()
    assert link_related_classes(related(), 'camera.html', {}) == related()


def test_partial_reference_matches_do_not_drop_unmatched_rows():
    source = related().replace('</tbody>', '<tr><td>Missing</td><td>m.h:2</td><td>–</td><td>Unique</td></tr></tbody>')
    assert link_related_classes(source, 'camera.html', class_targets({'index.html': index()})) == source


def test_custom_reference_attributes_and_linked_names_remain_intact():
    for tag in ('th', 'td', 'tr'):
        source = related().replace('<' + tag + '>', '<' + tag + ' title="context">', 1)
        assert link_related_classes(source, 'camera.html', class_targets({'index.html': index()})) == source
    row = ['<a href="other.html">Camera</a>', *ROW[1:]]
    assert link_related_classes(related(row), 'camera.html', class_targets({'index.html': index(row)})) == related(row)
    assert class_targets({'index.html': index().replace('<td>', '<td title="context">', 1)}) != class_targets({'index.html': index()})


@pytest.mark.parametrize('extra', ['<caption>Important conditions</caption>', '<tfoot><tr><td>Exception</td></tr></tfoot>', 'Additional instructions'])
def test_custom_table_content_outside_cells_is_never_discarded(extra):
    sources = [coverage(), table(['확인할 내용', '호출 측과 대상', '구분', '근거'], [['point', 'call', 'note', 'source']])]
    for source in sources:
        custom = source.replace('<table>', '<table>' + extra, 1)
        assert compact_tables(custom) == custom
    custom = related().replace('<table>', '<table>' + extra, 1)
    assert link_related_classes(custom, 'camera.html', class_targets({'index.html': index()})) == custom


def test_call_form_guidance_changes_only_for_converted_records_and_not_code_examples():
    instruction = '주요 확인 지점 1개를 아래 표와 관계도에 표시합니다.'
    source = '<p>' + instruction + '</p>' + table(['확인할 내용', '호출 측과 대상', '구분', '근거'], [['point', 'call', 'note', 'source']])
    result = compact_tables(source + '<pre>' + instruction + '</pre>')
    assert '<p>주요 확인 지점 1개를 아래 목록과 관계도에 표시합니다.</p>' in result
    assert '<pre>' + instruction + '</pre>' in result
    assert compact_tables('<p>' + instruction + '</p>') == '<p>' + instruction + '</p>'


def test_matching_next_link_is_one_control_and_distinct_hint_survives():
    control = '<a class="next" href="request.html#life"><small>다음</small>요청 수명 →</a>'
    source = '<h2 id="keep">내용</h2><p>다음 단계: <a href="request.html#life">요청 수명</a></p>'
    content, result = merge_next_step(source, control)
    assert content == '<h2 id="keep">내용</h2>' and result == control
    content, result = merge_next_step(source.replace('>요청 수명</a>', '>실패 후 복구 확인</a>'), control)
    assert content == '<h2 id="keep">내용</h2>'
    assert '실패 후 복구 확인' in result and '요청 수명' in result and result.count('href=') == 1


@pytest.mark.parametrize('tail', [
    '<p>다음 단계: <a href="request.html#different">요청 수명</a></p>',
    '<p>다음 단계: <a id="legacy" href="request.html#life">요청 수명</a></p>',
    '<pre><p>다음 단계: <a href="request.html#life">요청 수명</a></p></pre>',
    '<p>다음 단계: <a href="request.html#life">요청 수명</a>과 추가 지시</p>',
])
def test_distinct_targets_custom_attributes_examples_and_extra_instructions_are_retained(tail):
    control = '<a class="next" href="request.html#life"><small>다음</small>요청 수명 →</a>'
    assert merge_next_step(tail, control) == (tail, control)


def test_generated_status_groups_preserve_all_pages_and_nonpassing_states(tmp_cfg, sample_model):
    from test_export_site import prepare
    from sdd.export_site import export_site
    prepare(tmp_cfg, sample_model)
    path = tmp_cfg.sdd_dir / 'nested/detail.md'
    path.write_text(path.read_text(encoding='utf-8').replace('needs-review', 'ok'), encoding='utf-8')
    out = export_site(tmp_cfg)
    page = (out / 'index.html').read_text(encoding='utf-8')
    assert '<h2 id="문서-목록">문서 검증 현황</h2>' in page
    assert '<th>검사 결과</th>' not in page
    assert '<span>인용 검사 확인 필요</span>' in page and '<span>인용 검사 통과</span>' in page
    assert page.count('<span>사람 검토 전</span>') >= 2
    assert 'href="device.html"' in page and 'href="nested/detail.html"' in page


def test_pagination_merges_same_destination_into_the_requested_next_step():
    from sdd.export_site import _pagination_html
    entries = [('', '지원 범위와 검증', 'assurance.md'), ('', '연동', 'integration.md'), ('', '상세', 'detail.md')]
    links = _pagination_html(entries, {'integration.md': {'next': {'link': 'assurance.md'}}},
                             1, 'integration.md', 'integration.html')
    assert links == ['<a class="next" href="assurance.html"><small>다음</small>지원 범위와 검증 →</a>']


@pytest.mark.parametrize('destination', ['assurance.md#scope', 'detail.md'])
def test_pagination_keeps_distinct_page_or_fragment_destinations(destination):
    from sdd.export_site import _pagination_html
    entries = [('', '같은 제목', 'assurance.md'), ('', '연동', 'integration.md'), ('', '같은 제목', 'detail.md')]
    links = _pagination_html(entries, {'integration.md': {'next': {'link': destination}}},
                             1, 'integration.md', 'integration.html')
    assert len(links) == 2
    assert links[0].startswith('<a class="previous" href="assurance.html">')
    assert ('href="' + destination.replace('.md', '.html') + '"') in links[1]


FILE docs/libcamera/records/issue-248/protocol.md
# 고정 기준본으로 독자 평가를 진행하세요

이 절차는 2026-11-05에 결과 관측 전에 고정했습니다. [#163의 절차](../goal-162-163/reader-protocol.md), [진행자 채점 기준](../goal-162-163/facilitator-rubric.md), 빈 실제 결과를 재사용합니다. 과거 자동 평가와 해결된 탐색·그림 문제를 새 사람 관측으로 계산하지 않습니다. 최종 대상은 사내 Camera HAL이며 이 시험은 공개 libcamera 문서에 한정됩니다.

## 기준과 선정 범위

공개 URL은 https://ttolsun.github.io/libcamera-sdd/ 입니다. 기준 build_id는 `10b23c926b880b542f12e88ef22352f75b5cb7271cdb52f3bb5020eb4e0e4a93`, 공개 저장소 커밋은 `f7f82444a5d93fcd49b7fd388e52e55582d4f2fa`, 생성기 main은 `25f65afa160878db732e9739db5043d753ba3bfb`입니다. 원본 manifest와 페이지 해시는 `baseline.json`에 고정합니다. 분석 소스와 upstream mirror는 별도로 기록합니다. 평가 직전과 직후 manifest를 비교하고, 다른 빌드는 섞어 채점하지 않습니다. 고정 커밋의 `docs/` 사본으로 재현할 수 있습니다.

기존 여섯 경로는 소개→기술 채택→연동→코드 탐색을 대표하므로 유지합니다. 중단 후 조사 재개를 위해 `request-diagnosis.html`과 연결된 `request-lifecycle.html`을 추가합니다. 전체 사이트·전체 시각화(#215)·실기기·사내 HAL·임상적 ADHD 이해 검증은 제외합니다.

## 참가자에게 전달할 과업

비작성자 최소 3명에게 각각 아래 두 기본 과업과 S·R·X를 수행하게 합니다. 신입 관점과 타팀 관점을 각각 한 명 이상 포함합니다. 참가자에게는 시작 URL, 배정 과업과 기록 양식만 주고 이 절차의 채점 기준은 주지 않습니다.

| 참가자 관점 | 기본 과업 1 | 기본 과업 2 |
|---|---|---|
| 신입 | index에서 처음 열 문서와 요청을 따라갈 다음 문서·절을 찾고 선택 이유를 설명하세요. | overview에서 요청의 소유자·삭제 책임과 재사용 전 절차를 근거와 함께 찾으세요. 연결된 상세 문서로 이동해도 됩니다. |
| 타팀 | vendor-overview에서 공통 계층과 장치 구현의 책임·지원 한계를 찾으세요. | vendor-assurance에서 내장 벤치마크에 포함·제외되는 처리를 찾으세요. |
| 비작성자 | vendor-integration에서 마지막 버퍼 완료와 요청 완료의 차이, 명시 호출자·스레드를 찾으세요. | scenarios/queue_request에서 요청 전달 대상과 예약된 호출 표기, 정적 추적의 한계를 찾으세요. |

1. **S 자기 설명:** 제출 함수가 성공을 반환했지만 완료 알림이 없습니다. 성공 반환과 완료가 무엇이 다른지 문서를 닫은 상태에서 자기 말로 설명하세요. 이어 문서를 열고 자신의 설명을 뒷받침하는 위치를 찾으세요.
2. **R 중단 후 복귀:** 완료 누락 조사를 시작하고 확인한 단계·관측값·아직 모르는 점·근거·다음 분기를 자유 형식 메모로 남기세요. 문서를 닫고 5분 동안 무관한 일을 하세요. 같은 시작 URL로 재진입하여 자기 메모만 이용해 조사 상태, 다음 행동과 근거를 다시 찾으세요. 중단 전·후 URL, 돌아간 경로, 재탐색 시간과 막힌 이유를 따로 기록하세요. 기억만으로 답하거나 실제로 닫지 않았다면 복귀 성공으로 세지 않습니다.
3. **X 새로운 조건:** 같은 요청에 버퍼가 둘 있습니다. 하나의 버퍼 완료만 관측했습니다. 무엇을 완료로 단정할 수 있고, 무엇을 더 조사해야 합니까? 문서 근거를 제시하세요. 기본 과업의 전후 비교 점수에는 합산하지 않습니다.

기본 과업은 각각 10분, S·X는 각각 10분, R의 복귀 탐색은 10분을 상한으로 사용합니다. 상한을 넘거나 도움을 받거나 중단해도 원래 분모에 남깁니다. 소요 시간은 관측한 값만 기록합니다. 자동 에이전트는 사람의 망각·주의 중단을 재현할 수 없으므로 R을 탐색 절차 시험으로만 기록합니다.

## 사전 고정 성공 조건

기본 여섯 과업은 #163의 채점 기준을 그대로 적용합니다. 세 사람에게서 최소 6과업 중 5개 이상이 정확한 답과 유효한 근거를 작성자의 설명 없이 찾아야 합니다. 읽기 부담 척도는 1=매우 부담됨, 5=부담이 매우 낮음이며 모든 배정 기본 과업의 중앙값이 4 이상이어야 합니다. 누락 점수는 좋은 점수로 보충하지 않고 평가 미완료로 처리합니다. 참가자를 추가하면 결과를 모두 포함하고, 각 사람에게 두 과업을 배정합니다.

S는 세 사람 각각 (a) 성공 반환은 요청 접수/전달 성공이며 완료 증명이 아님, (b) 비동기 처리 후 별도 요청 완료 통지를 확인함, (c) 버퍼 완료와 요청 전체 완료를 구분함을 자기 말로 설명하고 해당 근거를 다시 찾아야 합니다. 문서 문장 복사는 자기 설명으로 인정하지 않습니다.

R은 세 사람 각각 중단 전 조사 상태를 복원하고, 실제 함수·값을 확인하는 다음 행동과 그 결과에 따른 다음 분기를 유효한 근거로 찾아야 합니다. 아직 관측하지 않은 상태를 실행 사실로 단정하거나 상태 변경 함수를 관측 목적으로 재호출하는 계획은 실패입니다. 진행자는 중단·재진입을 확인하고 원문 메모와 방문 기록을 남깁니다. 최소 의미를 모두 충족해야 성공이며 속도만으로 채점하지 않습니다.

X는 남은 버퍼·요청의 완료 여부를 단정하지 않고 추가 완료 상태와 요청 완료 통지 조건을 조사해야 합니다. 기준 근거는 `vendor-integration`의 요청 반환, `request-lifecycle`의 버퍼/요청 완료와 `request-diagnosis`의 완료 누락 분기입니다. 실제 페이지·발췌 링크는 기준본에서 확인해 `facilitator.md`에 고정합니다.

쉬움, 흥미, 문장의 자연스러움은 각기 1~5점과 이유 원문을 받습니다. 1=매우 어려움/흥미 없음/매우 부자연스러움, 5=매우 쉬움/매우 흥미로움/매우 자연스러움입니다. 흥미·자연스러움에는 합격 최저점을 새로 만들지 않으며 정확성·부담 점수와 합산하지 않습니다. 낮은 응답을 삭제하거나 긍정 답변을 유도하지 않습니다.

## 기록·비교·공개

`human-results.csv`는 실제 사람만, `agent-results/`는 자동 시험만 보관합니다. 각 기록에는 참가자 ID·관점·비작성 여부·build_id·과업·답변 원문·URL/앵커·근거·시작/종료 시각·실측 초·방문/되돌아간 경로·도움·정확성·막힌 이유를 남깁니다. S에는 문서를 닫았는지, R에는 중단 전 메모·중단/재진입 관측·복원 상태·다음 행동/분기를 추가합니다. 미발견과 미측정을 그대로 남깁니다.

원본은 로컬 비공개로 수집합니다. 공개 가능 여부가 확인되기 전에는 원문을 커밋하지 않으며 공개 저장소에는 익명 집계만 올립니다. 에이전트 결과는 출처를 표시한 자동 시험으로 공개할 수 있습니다. 작성자가 참가자에게 임의로 연락하지 않습니다.

병목별로 관측 위치→원인 가설→설명 소유 위치→수정→동일 과업 재평가를 기록합니다. 설명 순서·용어·그림·상세 연결은 관측 근거에 맞춰 생성 경로에서 수정합니다. 새 분량·그림 수는 성과 지표가 아닙니다. 같은 참가자의 전후 결과는 학습 효과가 있으므로 새 조건 X 및 처음 읽는 새 참가자의 결과와 구분합니다. 소표본의 성공률을 일반 사용자 전체로 확대하지 않습니다. 결과를 본 뒤 채점 기준을 낮추지 않으며 범위·기준 변경은 이유·시점·재평가 필요성을 기록합니다.

다음 단계는 참가자에게 `participant.md`와 해당 과업의 빈 기록 행을 전달하는 것입니다. 실제 사람 평가가 남으면 #163·#248과 Goal 전체를 완료 처리하지 않습니다.


FILE docs/libcamera/records/issue-248/facilitator.md
# 근거와 필수 의미를 대조하세요

참가자에게 과업 전에 이 파일을 주지 마세요. 기본 여섯 과업은 [#163 채점 기준](../goal-162-163/facilitator-rubric.md)을 그대로 사용합니다. 다음 주소는 고정 `baseline.json`의 배포 사본에서 확인했습니다. 답의 문구가 같을 필요는 없으며 주체·조건·시점과 근거가 맞아야 합니다.

| 추가 과업 | 필수 의미 | 기준 근거 |
|---|---|---|
| S | API 성공 반환은 입력 검사 후 호출 예약/접수의 결과이며 장치 처리 성공·요청 완료의 증명이 아닙니다. 별도 requestCompleted를 확인하며 버퍼 완료와 요청 전체 완료도 구분해야 합니다. | [접수 반환과 완료 알림](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#접수-반환과-완료-알림), [queueRequest 발췌](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#source-28d007de6ad1a8a5), [버퍼/요청 완료](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#버퍼-완료와-명시적-요청-완료의-경계) |
| R | 주어진 사실은 제출 성공/완료 미통지뿐입니다. 실행 관측과 조사 계획을 구분하고, 자신의 중단 전 상태·미확인값을 복원해야 합니다. 동일 요청 식별자로 실제 함수·값을 관찰하는 다음 행동과 조건별 다음 분기를 근거와 함께 찾아야 합니다. 대기/준비·장치 전달·완료·반환 순서 중 자신의 조사 상태에 맞는 분기를 찾으면 되며 모든 내부 함수를 암기할 필요는 없습니다. | [진단 순서](https://ttolsun.github.io/libcamera-sdd/request-diagnosis.html#실패-위치별-확인-순서), [준비·전달](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#선두-요청을-전달하거나-반복을-멈추는-조건), [제출 큐 선두](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html#제출-큐의-선두-상태와-반환-순서) |
| X | 하나의 완료 관측으로 다른 버퍼 상태·요청 완료·영상 성공을 단정하면 안 됩니다. 둘째 버퍼가 실제 미완료라면 모든 버퍼 완료 조건이 충족되지 않습니다. 모든 버퍼가 끝나도 명시적 completeRequest가 필요합니다. 같은 요청·버퍼의 상태/관측 위치, 요청 완료와 반환 조건을 추가로 확인해야 합니다. | [완료 발췌](https://ttolsun.github.io/libcamera-sdd/request-diagnosis.html#source-01ad7c6605c3296a), [버퍼/요청 완료](https://ttolsun.github.io/libcamera-sdd/request-diagnosis.html#버퍼-완료와-명시적-요청-완료의-경계) |

S는 문서를 실제로 닫은 뒤 자기 말로 설명했는지 관찰하세요. R은 5분 중단과 시작 주소 재진입을 관찰하고 메모 원문·전후 경로를 남기세요. 자동 에이전트의 문맥 유지나 짧은 도구 조회 중단은 사람의 조건을 충족하지 않습니다. 도움을 주면 도움 유무를 반드시 기록하며 실패·미응답을 삭제하지 않습니다.

채점자는 `correct`를 직접 판정합니다. 집계 도구는 의미 채점이나 사람 여부 인증을 수행하지 않습니다. 입력 선언의 진실성, 실제 시간·URL·메모, 비작성 여부는 진행자가 확인해야 합니다. 사람 평가 결과는 승인 장부와 별개입니다.

빈 양식의 기본 열은 #163과 같습니다. `source_kind=human`에는 실제 사람만 기록하세요. 예/아니오는 `true`/`false`, 1~5점은 정수로 적습니다. 미측정 값은 비워 두고 이유를 기록합니다. 단계별 추가 과업도 각각 별도 행을 사용합니다. 원본은 비공개 사본에 작성하고 공개 동의 전에는 저장소에 커밋하지 않습니다.

다음 명령은 빈 양식에서 `pending`과 종료 코드 1을 반환해야 합니다. 사람 결과가 없다는 뜻이며 구현 실패가 아닙니다. 에이전트·혼합 build_id·다른 프로토콜·중복 배정 행은 오류로 거절합니다. 같은 기준의 후보 평가는 별도 프로토콜 사본에 후보 build_id와 기준본 연결을 먼저 고정하고 새 양식으로 시작하세요. 원래 기록을 덮어쓰지 마세요.

```powershell
python -m sdd.reader_study --protocol docs/libcamera/records/issue-248/protocol.json --results docs/libcamera/records/issue-248/human-results.csv
```

기본 과업의 부담·흥미·자연스러움을 별도로 집계하고 원문 이유를 비공개 보관하세요. 추가 X는 전이 과제로 따로 보고하며 같은 과업의 학습 효과와 구분합니다. 관측된 실패를 보완한 뒤 같은 성공 조건으로 재평가하세요.

DELTA reading_cleanup.py (all unchanged behavior is outside this review)
diff --git a/src/sdd/reading_cleanup.py b/src/sdd/reading_cleanup.py
index f42981c..ecd23f7 100644
--- a/src/sdd/reading_cleanup.py
+++ b/src/sdd/reading_cleanup.py
@@ -4,6 +4,7 @@ from __future__ import annotations
 import html
 import posixpath
 import re
+from html.parser import HTMLParser
 from urllib.parse import quote
 
 
@@ -73,6 +74,52 @@ def compact_tables(document: str) -> str:
     intro = '질문별 답변과 근거 연결을 검사했습니다. 의미와 실행 결과는 사람 검토가 필요합니다.'
     common = '코드 근거와 설명 연결'
 
+    # These exact, content-free writing directions are stored in the audited
+    # manuscript. They are not reader questions or technical constraints. Do
+    # not strip arbitrary imperatives: many express required API contracts.
+    editorial_directions = (
+        '세 문단 이내로 작성하세요.',
+        '각 문단은 한 가지 독자 과업을 설명하고, 같은 결과나 반환값을 다시 풀어 쓰지 마세요.',
+        '소스 한 줄마다 문단을 만들지 마세요.',
+        '아래 절에서 설명하는 내부 구현을 미확인 한계로 반복하지 마세요.',
+    )
+
+    def reader_question(question):
+        # Match whole plain sentences only; code and linked text stay intact.
+        offsets, total = [], 0
+        for line in question.splitlines(keepends=True):
+            offsets.append(total)
+            total += len(line)
+        edits = []
+
+        class Text(HTMLParser):
+            def __init__(self):
+                super().__init__(convert_charrefs=False)
+                self.protected = 0
+
+            def handle_starttag(self, tag, attrs):
+                if tag in ('code', 'a', 'pre'):
+                    self.protected += 1
+
+            def handle_endtag(self, tag):
+                if tag in ('code', 'a', 'pre'):
+                    self.protected = max(0, self.protected - 1)
+
+            def handle_data(self, data):
+                if self.protected:
+                    return
+                updated = data
+                for direction in editorial_directions:
+                    updated = re.sub(r'(?<!\S)' + re.escape(direction) + r'(?=\s|$)', '', updated)
+                if updated != data:
+                    line, column = self.getpos()
+                    edits.append((offsets[line - 1] + column, len(data), updated))
+
+        Text().feed(question)
+        for start, length, updated in reversed(edits):
+            question = question[:start] + updated + question[start + length:]
+        return question.strip()
+
     def coverage(match):
         prefix, table, suffix = match.groups()
         if not simple_table(table):
@@ -87,6 +134,11 @@ def compact_tables(document: str) -> str:
             if len(values) != 3 or values[2] not in (common, common + ' · 실행 확인 항목 별도'):
                 return match[0]
             question, links, scope = values
+            question = reader_question(question)
+            if not question:
+                # No reader-facing question remains; retain the original rather
+                # than silently dropping a requirement or inventing a label.
+                return match[0]
             qualifier = '<p>실행 확인 항목 별도</p>' if scope != common else ''
             items.append('<li><p>' + question + '</p><p>' + links + '</p>' + qualifier + '</li>')
         if not items or re.search(r'\bid=', table):

